@echo off
rem CT54.A1.CombinedSwarms -- Windows launcher: starts the local frame server and opens the browser
title CT54.A1.CombinedSwarms server
cd /d "%~dp0"
where py >nul 2>nul && (py -3 CT54.A1.CombinedSwarms_server.py %* & goto :end)
where python >nul 2>nul && (python CT54.A1.CombinedSwarms_server.py %* & goto :end)
echo [CT54.A1.CombinedSwarms] Python 3 was not found. Install it from https://www.python.org/downloads/ and run this again.
:end
pause
