// =============================================================================
//  CT54.A1.CombinedSwarms  --  deterministic swarm simulation core (no rendering here)
//
//  CT54.A1: ONE ENGINE, FIVE OPTIONS. CT39.C8 (the cluster hangs under the arbor) and CT52.A2 (the queen hovers in
//     the open and the bees fly in a ball around her) are merged into this one file. The option is chosen with
//     opts.option (1-5) -- see OPTIONS below:
//       1 beard (mild & calm)  2 compact (cool)  3 broad (hot)  4 swaying (windy)   -- CT39: the bees LAND and HANG
//       5 hovering ball                                                             -- CT52: nobody lands (P.hover)
//     Everything CT52 added is gated on P.hover, so options 1-4 run the CT39.C8 code unchanged (same hashes) and
//     option 5 runs the CT52.A2 code. Option 5 was seen by the user in the wild; it is NOT described in the literature.
//
//  CT52.A2 (option 5): THE QUEEN MOVES ON COMMAND. requestMove() records an event at the next step: her station
//     switches between A and B (moveDX ft to the right), next to a 10-ft measuring pole, and she flies there slowly
//     (moveSpeed). Events (this.moves) live outside the state; replay, rewind and movies reproduce them.
//  CT52.A1 (option 5): THE FLYING BALL. After milling for queenSettle s the queen flies to a point in the open (the
//     STATION, 4 ft in front of the arbor, 7 ft up) and hovers. Nobody lands. MILLING (mode 0) -> ATTRACTED (mode 1:
//     up the scent gradient, straight at her once within visRange) -> IN THE BALL (mode 3, _ballStep: pull toward the
//     queen, personal space from a fine bee-density grid, own erratic flight and slow speed). The ball's size is not
//     set anywhere. A share (scentFrac) of the ball bees scent in flight. A bee that loses the scent goes back to
//     milling; ball bees make short excursions.
//
//  C7: THE SHELL AND THE CONDITIONS (see SCIENCE.md 6.7).
//   * SHELL (mantle). Settled bees within ~3 bee-widths of the cluster's surface form a dense outer layer: they pack
//     tighter than the core (shellPack) and are held to a smooth outer surface, the ENVELOPE, so the hanging chains
//     are inside it, not dangling outside (Heinrich 1981; Peleg et al. 2018).
//   * ENVELOPE. A shape of revolution hanging from the support, its volume = the settled bees' volume at the
//     temperature's packing. Its proportions come from the conditions (_envelope(), CONDITIONS): long and pointed
//     (a beard) when warm and calm on a thin branch; near-round when cool; short and broad when windy or on a flat
//     beam. Bees outside it are drawn in each pass (like a skin's tension); inside it, gravity, grips and packing act
//     as before. In the wind the envelope leans with the gusts, so the cluster sways. The shape is therefore given
//     to the model (from observed shapes), not derived from the bees' mechanics -- see SCIENCE.md 6.7.
//   * SUPPORT. 'branch': a thin dead vine stem slung under the arbor's front beam (a cylinder; the bees grip its
//     lower half). 'beam': the broad flat underside of the beam itself (as C1-C6).
//   * ATTACHMENT AREA. New grips on the support are taken only within the envelope's top radius of the queen.
//   * WEATHER presets (CONDITIONS below): warm & calm / cool / windy set the air temperature (packing) and the
//     envelope; 'windy' also drifts the milling fliers.
//
//  A7: SETTLED BEES HANG FROM ONE ANOTHER. A bee that lands grips up to 3 holds -- the branch, or settled
//     bees above it. Gravity pulls every settled bee down; its grips are leg-length links that stop it, so
//     the cluster is a hanging network of chains whose weight runs up through the grips to the branch.
//     Each bee's LOAD (bee-weights it holds up) is computed through that network; bees re-grip toward
//     higher, less-loaded holds and climb onto the branch when they can reach it (load sharing,
//     Shishkov et al. 2022). A bee whose holds are all gone falls and flies back. See SCIENCE.md 6.4.
//  A6: the cluster is no longer scripted. Nothing tells a bee where to go:
//   * SCENT. The queen, and later the settled bees that fan Nasonov scent, release pheromone into a 3-D
//     air grid that diffuses and decays (finite differences). Settled fanners blow their scent outward,
//     away from the queen (Nguyen et al. 2021).
//   * EACH BEE decides for itself: when the scent it smells passes its own threshold it becomes
//     "attracted" and flies up the scent gradient; it also reacts to its neighbours (keeps clear of
//     close neighbours, is drawn toward where other bees are, i.e. local density) and keeps its own
//     erratic flight noise.
//   * LANDING. An attracted bee lands where it touches the queen, the branch next to her, or a bee that
//     has already settled. Settled bees crawl toward the queen, sag under gravity and push apart to
//     their packing distance, so the hanging beard SHAPE and SIZE emerge.
//  See CT54.A1.CombinedSwarms_SCIENCE.md (section 6) for the model and the sources.
//
//  Units: feet, seconds. World: +Y up. Attachment (C1): the underside of the front beam of an old wooden arbor,
//  lowest (sagging) point at (siteX, attachY), z = siteZ.  (B1-B3: the stone soffit of a ruined arch.)
//
//  Determinism (as A1-A5): fixed step, integer PRNG, only + - * / and sqrt, fixed iteration order.
//  Checkpoints copy the bee state AND the scent field, so seeking backwards is exact.
//
//  Per-bee state (STRIDE doubles)
//    0..2 position   3..5 heading (unit)   6 speed   7 body length (ft)
//    8..10 wander turn-rate (OU)           11 target speed (OU)
//    12 own scent threshold                13 fanning (1/0)   14 time it landed / when flying: earliest time it may land   15 contact radius (ft)
//    16 mode: 0 milling, 1 attracted (flying to the scent), 2 settled in the cluster
//    17 caste: 0 worker, 1 drone, 2 queen
//    18..20 A7 grips: -1 none, -2 the branch, else the index of the settled bee it holds on to
//    21 load it holds up (bee-weights, below it in the network; updated at 15 Hz)   22 grip strength (bee-weights it can hold, 35 +- 14; Shishkov et al. 2022)
// =============================================================================
(function () {
'use strict';

const LABEL = 'CT54.A1.CombinedSwarms';
const STRIDE = 23;
const DT = 1 / 120;                     // flight step (s)
const SUB = 4;                          // scent field runs every SUB steps (30 Hz)
const RELAX_EVERY = 16;                 // cluster physics every 16 steps (7.5 Hz)
const CHECKPOINT_EVERY = 600;           // 5 s
const FT_PER_MM = 1 / 304.8;

const DEFAULTS = {
  siteX: 0, siteY: 8.0, siteZ: -40.0,   // siteY is recomputed = expected cluster centroid
  // C1: an OLD WOODEN ARBOR (a pergola) on a high place above the sea. Two long beams run along X, carried on four
  // posts; rafters lie across them (along Z) and a few slats across the rafters; some are missing. The bees hang
  // from the UNDERSIDE of the FRONT beam (z = siteZ): a flat, rough timber face beamD wide. The beam is old and
  // sags: its underside is lowest (attachY) at mid-span, x = siteX, and beamSag higher at the posts (a parabola).
  // Every solid part is an axis-aligned box (arborBoxes()); flying bees are kept out of all of them, and the
  // renderer draws exactly these boxes (weathered), so what the bees touch is what is seen.
  // (B1-B3: the curved soffit of a stone arch; A5-A10: a branch, an iron bead, a wire.)
  attachY: 9.0, branchRadius: 0,
  arborHalf: 4.3, postW: 0.5, beamD: 0.55, beamH: 0.75, beamSag: 0.18, arborBack: 5.5,
  rafterW: 0.22, rafterH: 0.5, rafterOver: 1.1, slatW: 0.32, slatH: 0.12,
  rafterX: [-4.0, -2.6, 1.15, 2.55, 3.95],   // (two are gone: the arbor is in bad shape)
  slatZ: [-0.4, -1.5, -3.3, -4.6],            // slats along X on top of the rafters, measured from siteZ
  climbReach: 1.6,                      // B1: a bee within 1.6 body lengths of free timber (B: stone) can step up onto it (A7-A10: 1.0)
  // packing (as A5): bee volume / cluster volume; 0.6 at 15 C -> 0.3 at 30 C (Ocko & Mahadevan 2014; Heinrich 1981)
  ambientC: 20,
  widthRatio: [4.2 / 12.8, 5.5 / 16, 4.8 / 19],          // body width / length per caste
  // airborne cloud (Seeley 2010: 10-20 m across)
  cloudRadiusH: 20.0, cloudRadiusV: 7.0, outerWall: 30.0,
  // staying with the swarm: beyond 70 % of the cloud radius (measured from the flying bees' centroid) a bee turns back.
  // The radius scales with cbrt(flying bees / all bees): the cloud keeps its density as it empties.
  cloudWallStart: 0.7, cloudWallGain: 9.0,
  // flight (Wenner 1963: cruising 7.5 m/s = 24.6 ft/s)
  speedMean: 13.0, speedSigma: 9.0, speedTheta: 1.2, speedMin: 4.0, speedMax: 24.6, speedResponse: 5.0,
  wanderTheta: 2.0, wanderSigma: 22.0, groundClear: 1.0,
  // neighbours
  sepRadius: 0.25,  sepGain: 40.0,      // keep clear of bees closer than 3 in
  cohesionGain: 8.0,                    // turn toward where more bees are (seen within a few feet; 4-ft density cells)
  coarse: 4,                            // ft per cell of the 'bees I can see' density grid
  // scent field: 3-D grid, 1 ft cells, effective (turbulent) diffusivity, decay
  gridX: 64, gridY: 28, gridZ: 64, cell: 1.0,
  diffusion: 2.0,                       // ft^2/s
  decay: 0.08,                          // 1/s (breakdown, dilution by breeze)
  queenFlyingEmit: 0.35,                // scent units/s while the queen is airborne
  queenEmit: 1.0,                       // after she settles
  fanEmit: 0.03,                        // per fanning (Nasonov) bee
  fanOutward: 1.0,                      // ft: fanners blow their scent this far out from the cluster
  fanSurfaceRatio: 0.7,                 // a settled bee with fewer than 0.7 x the average neighbour count is on the surface
  fanFraction: 0.35,                    // share of surface bees that fan
  threshold: 0.05, thresholdSpread: 5.7,    // own threshold = threshold * (0.3 + spread*u^2), u uniform: most bees sensitive, a long tail of reluctant ones
  scentGain: 9.0,                       // turn rate toward the scent gradient (rad/s)
  nearField: 1.5,                       // ft from the cluster: fly at what you see
  // the queen
  queenSettle: 12.0,                    // s: she leaves the cloud and alights on the branch (option 5: 20 s, see OPTIONS)
  // ---- CT54: option 5 (CT52.A2), used only when hover is on
  hover: false,
  stationDX: 0.0, stationY: 7.0, stationDZ: 4.0,   // the STATION where she hovers (from siteX / ground / siteZ)
  queenCruise: 6.0,                     // ft/s: her speed on the way to the station
  queenDrift: 0.08,                     // ft: her slow wandering about the station (rms)
  moveDX: 10.0, moveDZ: 0.0,            // ft: station B = station A + (moveDX, 0, moveDZ)
  follow: 'sight',                      // 'sight' | 'scent': how a bee keeps with her (CT52.A2)
  scentDrift: 5.0,                      // ft/s^2: drift up her pheromone gradient for a ball bee ('scent')
  moveSpeed: 0.8,                       // ft/s: her speed between stations
  poleDX: 0.0, poleDZ: -1.25, poleR: 1 / 24, poleH: 10.0,   // the measuring pole (offset from station B), 1 in across, 10 ft
  visRange: 6.0,                        // ft: an attracted bee this close to the queen flies straight at her
  ballJoin: 1.6, ballLeave: 5.0,        // ft: join the ball / flung further than this -> attracted again
  ballPull: 24.0, ballEdge: 0.35, ballPullOut: 80.0,   // ft/s^2 toward the queen; + ballPullOut per ft beyond ballEdge
  ballSpacing: 1.35,                    // body lengths: personal space in the ball (centre to centre)
  ballPress: 2.2,                       // ft^2/s^2: how hard crowding pushes
  ballSpeed: 1.6, ballSpeedMin: 0.7, ballSpeedMax: 4.0, ballResponse: 8.0,
  ballWander: 0.55, ballDrag: 3.0, ballExcursion: 0.004,
  ballCell: 0.12, ballGrid: 40,         // bee-density grid (follows the queen)
  scentFrac: 0.2, flightScentEmit: 0.015, loseScent: 0.5,
  // cluster physics (settled bees) -- A7: HANGING CHAINS (see SCIENCE.md 6.4)
  //  * a settled bee holds on with up to maxGrips grips: the underside of the bark, or settled bees ABOVE it
  //    (a hold must be at least -holdBelow x link length higher than the bee). It never holds a bee below it.
  //  * a grip is a link: a bee hangs by its legs from another, so their centres are at most linkBody x the mean
  //    body length apart (~13 mm for workers, twice the compact-sphere contact distance); holds are taken up
  //    to gripReach x that length away. A bee can be held by at most maxHeldBy others.
  //  * gravity lowers every hanging bee by 'sag' ft per tick (7.5 Hz) until its grips go taut; bees never
  //    overlap; bark-holders and the queen stay put.
  //  * bark: only the lower half of the branch (up to barkBand x radius above its underside; 1 = the axis),
  //    one bee per spot; new bark is taken only while the cluster is founding (< foundingBees) or
  //    next to bark-holders that hold > barkComfort x their grip strength.
  //  * re-grip: each tick a bee has a 'regrip' chance to replace a hold that is over its grip strength (or
  //    fill an empty grip slot) with a reachable hold above; climbRatio > 0 would also move bees to lighter
  //    holds (load sharing; makes the cluster creep up into a sleeve along the branch, so off by default).
  //  * letGoBelow: a hold that has ended up this far below the bee is released (100 = never; small values
  //    release whole chains in cascades).
  sag: 0.016, linkBody: 1.0, gripReach: 1.0, regrip: 0.02, maxGrips: 3, maxHeldBy: 4,
  holdBelow: -0.1, letGoBelow: 100, climbRatio: 0,
  barkBand: 1.0, barkComfort: 0.25, foundingBees: 40,
  gripMean: 35, gripSD: 14, gripMin: 8, gripMax: 80,         // bee-weights one bee can hold (Shishkov et al. 2022)
  crawlH: 0.1, crawlMax: 0.02, relaxIters: 2, relaxEvery: RELAX_EVERY,                // slow sideways crawl toward the queen; overlap passes per tick
  retakeoff: 0.0004,                    // chance per relaxation tick (1/15 s) that a surface bee takes off again
  // castes (as A3-A5)
  workerMean: 12.8, workerSD: 1.1, workerMin: 10.0, workerMax: 15.0,
  droneFrac: 0.03, droneMin: 15.0, droneMax: 17.0, queenLen: 19.0,
  // C7: what the cluster hangs from
  support: 'branch',                    // 'branch' (thin vine stem under the beam) | 'beam' (the beam's flat underside)
  stemR: 0.075,                         // ft: the stem's radius (1.8 in across)
  stemDrop: 0.42,                       // ft: how far its lowest point (mid-span) hangs below the beam
  stemHalf: 2.6,                        // ft: half the length of its loop under the beam
  // C7: the shell (mantle) and the envelope
  shell: 1,                             // 1 on, 0 off (C6 behaviour: no shell, no envelope)
  shellThick: 2.2,                      // contact distances: how deep below the surface counts as shell (~3 bees)
  shellPack: 0.62,                      // packing of the shell (core: from the temperature)
  envAspect: 1.7,                       // envelope length / greatest width
  envTop: 0.42,                         // radius where it meets the support / greatest radius
  envWidest: 0.32,                      // where it is widest, as a share of its length from the top
  envTaper: 0.45,                       // lower part: 0 = rounded (half an ellipse); up to ~0.6 = drawn to a point
  envFill: 0.85,                        // envelope volume / the settled bees. volume (a little under: the bees fill it to the top)
  envPull: 0.5, envPullMax: 0.004,      // per pass: share of the way back to the envelope (ft at most)
  gripSoft: 0,                          // C7, shell on: a stretched grip pulls back this share per pass (0: grips record
                                        // who holds whom and carry the load figures, but the envelope holds the shape)
  sagShell: 0.0005,                     // C7, shell on: gravity per tick (ft) (the bees settle into the envelope)
  overlapExtra: 3,
  stretch: 1.1,                         // C7: a grip stretched past this x its length is re-taken                      // C7: extra packing passes at the end of each tick (shell on)

  // C7: wind (0 = calm)
  wind: 0, windLean: 0.6,               // the envelope leans downwind by windLean x gust x depth
  windPush: 0.004,                      // ft per tick a full gust pushes a hanging bee (more the lower it hangs)
  windDrift: 1.2, gustPeriod: 1.7,      // ft/s drift of the fliers at full gust; s between gust changes
};
// C7: the Weather presets. Applied under any explicit option.
// (Peleg et al. 2018: at rest, an elongated pendant cone; shaken sideways, it spreads into a flatter cone with a
// broader base. Heinrich 1981 and J. Exp. Biol. 2022: in the cold it contracts, dense and conical, less surface; when
// hot it nearly doubles in volume, widens its attachment and flattens.) The shapes are given, not derived (SCIENCE 6.7).
const CONDITIONS = {
  mild:  { ambientC: 22, wind: 0, envAspect: 1.7,  envTop: 0.58, envWidest: 0.3,  envTaper: 0.45, label: 'mild & calm (22 °C)' },
  cool:  { ambientC: 11, wind: 0, envAspect: 1.0,  envTop: 0.55, envWidest: 0.42, envTaper: 0.25, label: 'cool (11 °C)' },
  hot:   { ambientC: 32, wind: 0, envAspect: 0.8,  envTop: 0.85, envWidest: 0.28, envTaper: 0.1,  label: 'hot (32 °C)' },
  windy: { ambientC: 18, wind: 1, envAspect: 0.62, envTop: 0.85, envWidest: 0.2,  envTaper: 0.1,  label: 'windy (18 °C)' },
};
// on the flat beam the cluster spreads along the wood and is no longer than it is wide (applied on top of the weather)
const BEAM_SHAPE = { envTopMin: 0.72, envAspectMax: 1.0, envAspectX: 0.9 };
const SUPPORTS = { branch: 'thin branch (vine stem)', beam: 'flat beam' };
// CT54: the five options. 1-4 are the CT39 hanging cluster under four weathers (documented shapes); 5 is the CT52
// hovering ball (seen by the user, NOT documented). 'documented' is shown in the page and the HUD.
const OPTIONS = {
  1: { key: 'beard',   weather: 'mild',  hover: false, documented: true,  name: 'Beard',         short: 'hangs as a long beard',            label: '1 · Beard — mild & calm, hangs from a branch' },
  2: { key: 'compact', weather: 'cool',  hover: false, documented: true,  name: 'Compact',       short: 'hangs as a tight, rounded cluster', label: '2 · Compact — cool, hangs from a branch' },
  3: { key: 'broad',   weather: 'hot',   hover: false, documented: true,  name: 'Broad',         short: 'hangs short, broad and loose',     label: '3 · Broad — hot, hangs from a branch' },
  4: { key: 'windy',   weather: 'windy', hover: false, documented: true,  name: 'Swaying',       short: 'hangs short and broad, sways',     label: '4 · Swaying — windy, hangs from a branch' },
  5: { key: 'hover',   weather: 'mild',  hover: true,  documented: false, name: 'Hovering ball', short: 'flies in a ball around a hovering queen', label: '5 · Hovering ball — observed, NOT in the literature' },
};
const OPTION_KEYS = { beard: 1, mild: 1, compact: 2, cool: 2, broad: 3, hot: 3, windy: 4, swaying: 4, hover: 5, ball: 5 };
function optionOf(v) { if (OPTIONS[v]) return +v; const k = OPTION_KEYS[String(v || '').toLowerCase()]; return k || 1; }
function hash01(k) {                    // integer hash -> [0, 1) (deterministic, no trig)
  let h = Math.imul((k | 0) ^ 0x9e3779b9, 0x85ebca6b); h ^= h >>> 13; h = Math.imul(h, 0xc2b2ae35); h ^= h >>> 16;
  return (h >>> 0) / 4294967296;
}

class Rng {
  constructor(seed) { this.s = seed >>> 0; }
  next() {
    let t = (this.s = (this.s + 0x6D2B79F5) >>> 0);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }
  gauss() { return (this.next() + this.next() + this.next() + this.next() - 2) * 1.7320508075688772; }
}
function cbrt(v) {                      // Newton; + - * / only (Math.cbrt is not guaranteed bit-identical)
  if (v <= 0) return 0;
  let x = v > 1 ? v / 3 : 1;
  for (let i = 0; i < 100; i++) { const nx = (2 * x + v / (x * x)) / 3; if (nx === x) break; x = nx; }
  return x;
}

class Swarm {
  static RING = (() => {                     // B1: (0,0), then 6 points at radius 1 and 12 at radius 2 (unit = step)
    const o = [0, 0];
    // C1: built with + - * / and sqrt only (Math.cos / Math.sin differ between JavaScript engines, which made the
    // browser's run differ from Node's in B1-B3): 60 / 30 degree steps from exact values, the 0.26 rad twist from literals
    const h3 = Math.sqrt(3) / 2, C6 = [1, 0.5, -0.5, -1, -0.5, 0.5], S6 = [0, h3, h3, 0, -h3, -h3];
    const C12 = [1, h3, 0.5, 0, -0.5, -h3, -1, -h3, -0.5, 0, 0.5, h3], S12 = [0, 0.5, h3, 1, h3, 0.5, 0, -0.5, -h3, -1, -h3, -0.5];
    const ct = 0.9663899781345132, st = 0.2570805518921551;          // cos 0.26, sin 0.26
    for (let k = 0; k < 6; k++) o.push(C6[k], S6[k]);
    for (let k = 0; k < 12; k++) o.push(2 * (C12[k] * ct - S12[k] * st), 2 * (S12[k] * ct + C12[k] * st));
    return new Float64Array(o);
  })();
  static HALF = (() => {                     // (0,0,0) first, then the 13 neighbour offsets lexicographically after it
    const o = [0, 0, 0];
    for (let a = -1; a <= 1; a++) for (let b = -1; b <= 1; b++) for (let c = -1; c <= 1; c++)
      if (a > 0 || (a === 0 && (b > 0 || (b === 0 && c > 0)))) o.push(a, b, c);
    return new Int32Array(o);
  })();
  constructor(seed = 3906, count = 12000, opts = {}) {
    this.seed = seed >>> 0;
    this.count = Math.max(2, count | 0);
    // CT54: the option picks the weather (1-4) or the hovering ball (5). An explicit weather still wins for 1-4.
    opts = Object.assign({}, opts);
    const opt = opts.option != null ? optionOf(opts.option) : opts.hover ? 5 : optionOf(opts.weather);
    this.option = opt; this.optionInfo = OPTIONS[opt];
    if (OPTIONS[opt].hover) {
      // CT52.A2 ran on CT39.C6: still air, 20 C, the queen mills 20 s, nothing hangs (support irrelevant: no stem drawn)
      opts.hover = true; opts.weather = 'mild';
      if (!('ambientC' in opts)) opts.ambientC = 20;
      if (!('queenSettle' in opts)) opts.queenSettle = 20.0;
      if (!('support' in opts)) opts.support = 'beam';
    } else { opts.hover = false; if (!opts.weather) opts.weather = OPTIONS[opt].weather; }
    delete opts.option;
    const W = CONDITIONS[opts.weather] ? opts.weather : opts.weather === 'warm' ? 'mild' : 'mild';
    const preset = Object.assign({}, CONDITIONS[W]); delete preset.label;
    this.P = Object.assign({}, DEFAULTS, preset, opts);
    this.P.weather = W; if (!SUPPORTS[this.P.support]) this.P.support = 'branch';
    this.isBranch = this.P.support === 'branch';
    if (!this.isBranch) {                                 // C7: a flat surface: broader top, shorter
      if (!('envTop' in opts) && this.P.envTop < BEAM_SHAPE.envTopMin) this.P.envTop = BEAM_SHAPE.envTopMin;
      if (!('envAspect' in opts)) this.P.envAspect = Math.min(this.P.envAspect, BEAM_SHAPE.envAspectMax) * BEAM_SHAPE.envAspectX;
    }
    this._envInit();
    this.state = new Float64Array(this.count * STRIDE);
    this.step = 0;
    this.rng = new Rng(this.seed);
    const P = this.P;
    this.nCells = P.gridX * P.gridY * P.gridZ;
    this.YZ = P.gridY * P.gridZ; this.gx0 = P.siteX - P.gridX * P.cell / 2; this.gz0 = P.siteZ - P.gridZ * P.cell / 2; this.invCell = 1 / P.cell;
    this.field = new Float64Array(this.nCells);
    this.fieldTmp = new Float64Array(this.nCells);
    // CT52.A2 (option 5): the QUEEN'S OWN pheromone, kept apart from the workers' Nasonov scent ('scent' following)
    if (P.hover) { this.qfield = new Float64Array(this.nCells); this.qfieldTmp = new Float64Array(this.nCells); }
    this.density = new Float32Array(this.nCells);          // flying bees per 1-ft cell (rebuilt every SUB steps)
    this.cgx = Math.ceil(P.gridX * P.cell / P.coarse); this.cgy = Math.ceil(P.gridY * P.cell / P.coarse); this.cgz = Math.ceil(P.gridZ * P.cell / P.coarse);
    this.coarseD = new Float32Array(this.cgx * this.cgy * this.cgz);   // all bees per 4-ft cell
    this.checkpoints = new Map();
    this._init();
    this._rebuild();
    this._saveCheckpoint();
  }
  get time() { return this.step * DT; }

  // ---------------------------------------------------------------- setup
  _init() {
    const r = this.rng, s = this.state, P = this.P, N = this.count;
    // packing and the size the cluster should reach (A5 formula) -> spacing between settled bees
    let pack = 0.6 - 0.02 * (P.ambientC - 15); if (pack < 0.2) pack = 0.2; else if (pack > 0.8) pack = 0.8;
    this.packing = pack;
    this.spacing = cbrt(0.6 / pack);                 // contact distance = (ri + rj) * spacing; 0.6 = random close packing
    const nDrones = Math.max(0, Math.round(N * P.droneFrac));
    let beeVol = 0;
    for (let i = 0; i < N; i++) {
      const o = i * STRIDE;
      let caste = 0, len;
      if (i === 0) { caste = 2; len = P.queenLen; }
      else if (i <= nDrones) { caste = 1; len = P.droneMin + r.next() * (P.droneMax - P.droneMin); }
      else { len = P.workerMean + r.gauss() * P.workerSD; if (len < P.workerMin) len = P.workerMin; else if (len > P.workerMax) len = P.workerMax; }
      const L = len * FT_PER_MM, wr = P.widthRatio[caste];
      s[o + 17] = caste; s[o + 7] = L;
      s[o + 15] = 0.5 * L * cbrt(wr * wr);           // radius of the equal-volume sphere
      beeVol += 0.5235987755982988 * L * L * L * wr * wr;
    }
    this.beeVolume = beeVol;
    this.expectedVolume = beeVol / pack;
    // expected centroid ~ 0.45 of a beard of that volume below the branch (only used to centre the cloud & camera)
    const expLen = 1.6 * 2 * cbrt(this.expectedVolume / (2.3 * 3.2));
    P.siteY = this._soffitY(P.siteX) - 0.42 * expLen;
    // C7: one bark-holder's share of the support (a square of one contact distance), the shell's spacing
    const rw0 = 0.5 * P.workerMean * FT_PER_MM * cbrt(P.widthRatio[0] * P.widthRatio[0]);
    this.contact = 2 * rw0 * this.spacing;
    this.holderArea = this.contact * this.contact;
    this.shellSpacing = Math.min(this.spacing, cbrt(0.6 / P.shellPack));

    const cx = P.siteX, cy = P.siteY, cz = P.siteZ;
    for (let i = 0; i < N; i++) {
      const o = i * STRIDE;
      let x, y, z;
      do { x = r.next() * 2 - 1; y = r.next() * 2 - 1; z = r.next() * 2 - 1; } while (x * x + y * y + z * z > 0.64);
      s[o] = cx + x * P.cloudRadiusH;
      s[o + 1] = cy + y * P.cloudRadiusV; if (s[o + 1] < P.groundClear) s[o + 1] = P.groundClear + r.next();
      s[o + 2] = cz + z * P.cloudRadiusH;
      let dx, dy, dz, n;
      do { dx = r.gauss(); dy = r.gauss() * 0.5; dz = r.gauss(); n = Math.sqrt(dx * dx + dy * dy + dz * dz); } while (n < 1e-6);
      s[o + 3] = dx / n; s[o + 4] = dy / n; s[o + 5] = dz / n;
      s[o + 11] = P.speedMin + r.next() * (P.speedMax - P.speedMin) * 0.7; s[o + 6] = s[o + 11];
      s[o + 8] = r.gauss() * 3; s[o + 9] = r.gauss() * 3; s[o + 10] = r.gauss() * 3;
      { const u = r.next(); s[o + 12] = P.threshold * (0.3 + P.thresholdSpread * u * u); }
      s[o + 13] = 0; s[o + 14] = -1; s[o + 16] = 0;
      s[o + 18] = -1; s[o + 19] = -1; s[o + 20] = -1;
      { let gs = P.gripMean + P.gripSD * r.gauss(); if (gs < P.gripMin) gs = P.gripMin; else if (gs > P.gripMax) gs = P.gripMax; s[o + 22] = gs; }
    }
    // weight of each bee in mean-worker weights (by volume)
    const rw = 0.5 * P.workerMean * FT_PER_MM * cbrt(P.widthRatio[0] * P.widthRatio[0]);
    this.wgt = new Float64Array(N);
    for (let i = 0; i < N; i++) { const q = s[i * STRIDE + 15] / rw; this.wgt[i] = q * q * q; }
    // the queen starts near the middle of the cloud
    s[1] = cy + 1.0; s[0] = cx + 3; s[2] = cz + 2;
    this.moves = [];
    if (P.hover) {
      // CT52 (option 5): the queen never grips: slots 18..20 hold her drift about the station, 21/22/14 her velocity
      s[18] = 0; s[19] = 0; s[20] = 0; s[21] = 0; s[22] = 0; s[14] = 0;
      this.station = [P.siteX + P.stationDX, P.stationY, P.siteZ + P.stationDZ];
      this.stationB = [this.station[0] + P.moveDX, P.stationY, this.station[2] + P.moveDZ];
      this.pole = [this.stationB[0] + P.poleDX, this.stationB[2] + P.poleDZ];
      { const sp1 = P.ballSpacing * P.workerMean * FT_PER_MM; this.n0 = 1 / (sp1 * sp1 * sp1); }
      const nb = P.ballGrid; this.bNodes = nb + 1; this.bg = new Float64Array(this.bNodes * this.bNodes * this.bNodes);
      this.ball = { n: 0, cx: this.station[0], cy: this.station[1], cz: this.station[2], r2: 0, rad: 0 };
    }
  }

  // ---------------------------------------------------------------- spatial structures (rebuilt from state)
  _rebuild() {
    this._buildDensity();
    this._buildClusterHash();
    this._topology();
  }
  _cellIndex(x, y, z) {
    const P = this.P;
    const ix = Math.floor((x - this.gx0) * this.invCell);
    const iy = Math.floor(y * this.invCell);
    const iz = Math.floor((z - this.gz0) * this.invCell);
    if (ix < 0 || iy < 0 || iz < 0 || ix >= P.gridX || iy >= P.gridY || iz >= P.gridZ) return -1;
    return (ix * P.gridY + iy) * P.gridZ + iz;
  }
  // flying bees per 1-ft cell + a coarse hash of flying bees for separation
  _buildDensity() {
    const s = this.state, N = this.count, d = this.density, cd = this.coarseD, P = this.P;
    d.fill(0); cd.fill(0);
    let fx = 0, fy = 0, fz = 0, fn = 0;
    const ic = 1 / P.coarse, cgy = this.cgy, cgz = this.cgz;
    for (let i = 0; i < N; i++) {
      const o = i * STRIDE;
      const ix = Math.floor((s[o] - this.gx0) * ic), iy = Math.floor(s[o + 1] * ic), iz = Math.floor((s[o + 2] - this.gz0) * ic);
      if (ix >= 0 && iy >= 0 && iz >= 0 && ix < this.cgx && iy < cgy && iz < cgz) cd[(ix * cgy + iy) * cgz + iz] += 1;
      if (s[o + 16] < 2) { fx += s[o]; fy += s[o + 1]; fz += s[o + 2]; fn++; }   // CT54: 2 settled, 3 ball (option 5)
    }
    const fr = cbrt(fn / N) || 0.05;
    this.flyC = fn ? [fx / fn, fy / fn, fz / fn, fr] : [P.siteX, P.siteY, P.siteZ, 0.05];
    if (!this.flyHead) { this.flyHead = new Int32Array(this.nCells); this.flyNext = new Int32Array(N); }
    this.flyHead.fill(-1);
    for (let i = N - 1; i >= 0; i--) {
      const o = i * STRIDE;
      if (s[o + 16] >= 2) continue;                   // settled, or (option 5) in the ball
      const c = this._cellIndex(s[o], s[o + 1], s[o + 2]);
      if (c < 0) continue;
      d[c] += 1;
      this.flyNext[i] = this.flyHead[c]; this.flyHead[c] = i;
    }
    if (P.hover) this._buildBall();
  }
  // CT52: the bee-density grid of the ball (cloud-in-cell onto the nodes of a grid that follows the queen, snapped to
  // whole cells) and the ball's statistics (count, centroid, mean square distance from the queen)
  _buildBall() {
    const s = this.state, N = this.count, P = this.P, g = this.bg, nn = this.bNodes, h = P.ballCell, ih = 1 / h;
    g.fill(0);
    const half = 0.5 * P.ballGrid * h;
    const x0 = Math.floor((s[0] - half) * ih) * h, y0 = Math.floor((s[1] - half) * ih) * h, z0 = Math.floor((s[2] - half) * ih) * h;
    this.bX0 = x0; this.bY0 = y0; this.bZ0 = z0;
    const w = ih * ih * ih;                                    // one bee spread over a cell's volume -> bees / ft^3
    let n = 0, sx = 0, sy = 0, sz = 0, r2 = 0;
    for (let i = 1; i < N; i++) {
      const o = i * STRIDE; if (s[o + 16] !== 3) continue;
      const px = s[o], py = s[o + 1], pz = s[o + 2];
      n++; sx += px; sy += py; sz += pz;
      const ex = px - s[0], ey = py - s[1], ez = pz - s[2]; r2 += ex * ex + ey * ey + ez * ez;
      const fx = (px - x0) * ih, fy = (py - y0) * ih, fz = (pz - z0) * ih;
      const ix = Math.floor(fx), iy = Math.floor(fy), iz = Math.floor(fz);
      if (ix < 0 || iy < 0 || iz < 0 || ix >= nn - 1 || iy >= nn - 1 || iz >= nn - 1) continue;
      const tx = fx - ix, ty = fy - iy, tz = fz - iz, b = (ix * nn + iy) * nn + iz;
      const ux = 1 - tx, uy = 1 - ty, uz = 1 - tz;
      g[b] += ux * uy * uz * w;            g[b + 1] += ux * uy * tz * w;
      g[b + nn] += ux * ty * uz * w;       g[b + nn + 1] += ux * ty * tz * w;
      g[b + nn * nn] += tx * uy * uz * w;  g[b + nn * nn + 1] += tx * uy * tz * w;
      g[b + nn * nn + nn] += tx * ty * uz * w; g[b + nn * nn + nn + 1] += tx * ty * tz * w;
    }
    const B = this.ball;
    B.n = n;
    if (n) { B.cx = sx / n; B.cy = sy / n; B.cz = sz / n; B.r2 = r2 / n; B.rad = Math.sqrt(5 / 3 * B.r2); }   // uniform ball: <r^2> = 3R^2/5
    else { B.cx = s[0]; B.cy = s[1]; B.cz = s[2]; B.r2 = 0; B.rad = 0; }
  }
  // trilinear bee density (bees / ft^3) and its gradient at a point; 0 outside the grid
  _sampleBall(x, y, z, out) {
    const nn = this.bNodes, g = this.bg, ih = 1 / this.P.ballCell;
    const fx = (x - this.bX0) * ih, fy = (y - this.bY0) * ih, fz = (z - this.bZ0) * ih;
    const ix = Math.floor(fx), iy = Math.floor(fy), iz = Math.floor(fz);
    if (ix < 0 || iy < 0 || iz < 0 || ix >= nn - 1 || iy >= nn - 1 || iz >= nn - 1) { out[0] = out[1] = out[2] = out[3] = 0; return; }
    const tx = fx - ix, ty = fy - iy, tz = fz - iz, YZ = nn * nn, i000 = ix * YZ + iy * nn + iz;
    const c000 = g[i000], c001 = g[i000 + 1], c010 = g[i000 + nn], c011 = g[i000 + nn + 1];
    const c100 = g[i000 + YZ], c101 = g[i000 + YZ + 1], c110 = g[i000 + YZ + nn], c111 = g[i000 + YZ + nn + 1];
    const c00 = c000 + (c100 - c000) * tx, c10 = c010 + (c110 - c010) * tx, c01 = c001 + (c101 - c001) * tx, c11 = c011 + (c111 - c011) * tx;
    const c0 = c00 + (c10 - c00) * ty, c1 = c01 + (c11 - c01) * ty;
    out[0] = c0 + (c1 - c0) * tz;
    out[1] = (((c100 - c000) * (1 - ty) + (c110 - c010) * ty) * (1 - tz) + ((c101 - c001) * (1 - ty) + (c111 - c011) * ty) * tz) * ih;
    out[2] = (((c010 - c000) * (1 - tx) + (c110 - c100) * tx) * (1 - tz) + ((c011 - c001) * (1 - tx) + (c111 - c101) * tx) * tz) * ih;
    out[3] = ((c01 - c00) * (1 - ty) + (c11 - c10) * ty) * ih;
  }
  // fine hash of settled bees around the branch (cells 0.05 ft)
  _buildClusterHash() {
    const P = this.P, s = this.state, N = this.count;
    const H = 0.035, nx = 104, ny = 116, nz = 104;   // cell >= largest contact distance
    if (!this.cHead) {
      this.cH = H; this.cNx = nx; this.cNy = ny; this.cNz = nz;
      this.cX0 = P.siteX - nx * H / 2; this.cY0 = P.attachY + 0.5 - ny * H; this.cZ0 = P.siteZ - nz * H / 2;
      this.cHead = new Int32Array(nx * ny * nz).fill(-1); this.cNext = new Int32Array(N);
      this.cTouched = new Int32Array(N); this.cCellOf = new Int32Array(N);
    }
    for (let k = 0; k < this.nTouched; k++) this.cHead[this.cTouched[k]] = -1;
    this.nTouched = 0; this.settled = 0;
    let sx = 0, sy = 0, sz = 0, minY = 1e9, maxR = 0, h2 = 0;
    const topY = this._soffitY(P.siteX);                // C7: the support's underside (the stem or the beam)
    for (let i = N - 1; i >= 0; i--) {
      const o = i * STRIDE;
      if (s[o + 16] !== 2) continue;
      this._hashInsert(i);
      this.settled++; sx += s[o]; sy += s[o + 1]; sz += s[o + 2]; if (s[o + 1] < minY) minY = s[o + 1];
      h2 += (topY - s[o + 1]) * (topY - s[o + 1]);
    }
    if (this.settled) {
      sx /= this.settled; sy /= this.settled; sz /= this.settled;
      for (let i = 0; i < N; i++) {
        const o = i * STRIDE; if (s[o + 16] !== 2) continue;
        const dx = s[o] - sx, dz = s[o + 2] - sz; maxR += dx * dx + dz * dz;
      }
    }
    // robust size: for a solid (half-)ellipsoid <x^2+z^2> = 2a^2/5 and <h^2> = c^2/5
    const n = this.settled || 1;
    this.cStats = { n: this.settled, cx: sx, cy: sy, cz: sz, minY, halfWidth: Math.sqrt(2.5 * maxR / n), length: Math.sqrt(5 * h2 / n) };
  }
  _hashInsert(i) {
    const s = this.state, o = i * STRIDE, H = this.cH;
    let ix = Math.floor((s[o] - this.cX0) / H), iy = Math.floor((s[o + 1] - this.cY0) / H), iz = Math.floor((s[o + 2] - this.cZ0) / H);
    if (ix < 0) ix = 0; else if (ix >= this.cNx) ix = this.cNx - 1;
    if (iy < 0) iy = 0; else if (iy >= this.cNy) iy = this.cNy - 1;
    if (iz < 0) iz = 0; else if (iz >= this.cNz) iz = this.cNz - 1;
    const c = (ix * this.cNy + iy) * this.cNz + iz;
    if (this.cHead[c] === -1) this.cTouched[this.nTouched++] = c;
    this.cNext[i] = this.cHead[c]; this.cHead[c] = i; this.cCellOf[i] = c;
  }

  // ---------------------------------------------------------------- scent field
  _sample(x, y, z, out, fld) {          // trilinear concentration + its gradient (CT52.A2: of fld, default the total scent)
    const P = this.P, f = fld || this.field, gy = P.gridY, gz = P.gridZ, YZ = gy * gz;
    const fx = (x - this.gx0) * this.invCell - 0.5, fy = y * this.invCell - 0.5, fz = (z - this.gz0) * this.invCell - 0.5;
    const ix = Math.floor(fx), iy = Math.floor(fy), iz = Math.floor(fz);
    if (ix < 1 || iy < 1 || iz < 1 || ix >= P.gridX - 2 || iy >= gy - 2 || iz >= gz - 2) { out[0] = out[1] = out[2] = out[3] = 0; return; }
    const tx = fx - ix, ty = fy - iy, tz = fz - iz;
    const i000 = ix * YZ + iy * gz + iz;
    const c000 = f[i000], c001 = f[i000 + 1], c010 = f[i000 + gz], c011 = f[i000 + gz + 1];
    const c100 = f[i000 + YZ], c101 = f[i000 + YZ + 1], c110 = f[i000 + YZ + gz], c111 = f[i000 + YZ + gz + 1];
    const c00 = c000 + (c100 - c000) * tx, c10 = c010 + (c110 - c010) * tx, c01 = c001 + (c101 - c001) * tx, c11 = c011 + (c111 - c011) * tx;
    const c0 = c00 + (c10 - c00) * ty, c1 = c01 + (c11 - c01) * ty;
    out[0] = c0 + (c1 - c0) * tz;
    out[1] = ((c100 - c000) * (1 - ty) + (c110 - c010) * ty) * (1 - tz) + ((c101 - c001) * (1 - ty) + (c111 - c011) * ty) * tz;
    out[2] = ((c010 - c000) * (1 - tx) + (c110 - c100) * tx) * (1 - tz) + ((c011 - c001) * (1 - tx) + (c111 - c101) * tx) * tz;
    out[3] = (c01 - c00) * (1 - ty) + (c11 - c10) * ty;
  }
  _emit(x, y, z, amount) { const c = this._cellIndex(x, y, z); if (c >= 0) this.field[c] += amount / (this.P.cell * this.P.cell * this.P.cell); }
  _updateField(dt) {
    this._diffuse(this.field, this.fieldTmp, dt); { const t = this.field; this.field = this.fieldTmp; this.fieldTmp = t; }
    if (this.P.hover && this.P.follow === 'scent') { this._diffuse(this.qfield, this.qfieldTmp, dt); const t = this.qfield; this.qfield = this.qfieldTmp; this.qfieldTmp = t; }
  }
  _diffuse(f, g, dt) {
    const P = this.P, X = P.gridX, Y = P.gridY, Z = P.gridZ;
    const a = P.diffusion * dt / (P.cell * P.cell), k = 1 - P.decay * dt;
    for (let ix = 0; ix < X; ix++) for (let iy = 0; iy < Y; iy++) {
      const base = (ix * Y + iy) * Z;
      for (let iz = 0; iz < Z; iz++) {
        const i = base + iz, c = f[i];
        let lap = -6 * c;                                 // boundaries: open (outside = 0) except the ground (no flux)
        lap += ix > 0 ? f[i - Y * Z] : 0; lap += ix < X - 1 ? f[i + Y * Z] : 0;
        lap += iy > 0 ? f[i - Z] : c;     lap += iy < Y - 1 ? f[i + Z] : 0;
        lap += iz > 0 ? f[i - 1] : 0;     lap += iz < Z - 1 ? f[i + 1] : 0;
        g[i] = (c + a * lap) * k;
      }
    }
  }

  // ---------------------------------------------------------------- one flight step
  _stepOnce() {
    const s = this.state, r = this.rng, P = this.P, N = this.count, t = this.step * DT, sq = Math.sqrt(DT);
    const cx = P.siteX, cy = P.siteY, cz = P.siteZ;
    const sample = this._s4 || (this._s4 = new Float64Array(4));
    const C = this.cStats, haveCluster = C.n > 0;
    const sp0 = this.spacing;
    const ymaxBranch = this._soffitY(cx);              // C7: the underside of the support at mid-span
    const windNow = P.wind > 0 ? P.wind * this._gust(t) * P.windDrift : 0;
    const hover = P.hover, queenHolding = hover && s[16] === 3, sight = P.follow !== 'scent';   // CT54: option 5

    for (let i = 0; i < N; i++) {
      const o = i * STRIDE;
      let mode = s[o + 16];
      if (mode === 2) continue;                        // settled: moved by the cluster physics

      const isQueen = s[o + 17] === 2;
      let px = s[o], py = s[o + 1], pz = s[o + 2];
      let dx = s[o + 3], dy = s[o + 4], dz = s[o + 5];

      // --- flight noise (OU turn rate, OU target speed)
      let wx = s[o + 8], wy = s[o + 9], wz = s[o + 10];
      const wsig = mode === 1 ? P.wanderSigma * 0.35 : P.wanderSigma;
      wx += -P.wanderTheta * wx * DT + wsig * sq * r.gauss();
      wy += -P.wanderTheta * wy * DT + wsig * 0.6 * sq * r.gauss();
      wz += -P.wanderTheta * wz * DT + wsig * sq * r.gauss();
      s[o + 8] = wx; s[o + 9] = wy; s[o + 10] = wz;
      let ts = s[o + 11];
      ts += P.speedTheta * (P.speedMean - ts) * DT + P.speedSigma * sq * r.gauss();
      if (ts < P.speedMin) ts = P.speedMin; else if (ts > P.speedMax) ts = P.speedMax;
      s[o + 11] = ts;
      let ax = wx, ay = wy, az = wz, sp = s[o + 6], want = ts;

      if (hover && isQueen && t >= P.queenSettle) {
        // CT52: she flies to her station and holds it, hovering, drifting slowly about it (OU drift in slots 18..20)
        const nMv = this._movesDone(), ST = (nMv & 1) ? this.stationB : this.station, th = 0.25, dsg = P.queenDrift * Math.sqrt(2 * th);
        for (let k = 0; k < 3; k++) s[o + 18 + k] += -th * s[o + 18 + k] * DT + dsg * sq * r.gauss();
        const tx = ST[0] + s[o + 18] - px, ty = ST[1] + s[o + 19] - py, tz = ST[2] + s[o + 20] - pz;
        const dist = Math.sqrt(tx * tx + ty * ty + tz * tz);
        let vx = s[o + 21], vy = s[o + 22], vz = s[o + 14];
        const cruise = nMv ? P.moveSpeed : P.queenCruise;                           // A2: after a move command she flies slowly
        let wv = 1.2 * dist; if (wv > cruise) wv = cruise;                         // desired velocity toward the point
        const k = dist > 1e-9 ? wv / dist : 0;
        let gx = (tx * k - vx) * 3, gy = (ty * k - vy) * 3, gz = (tz * k - vz) * 3;
        const gn = Math.sqrt(gx * gx + gy * gy + gz * gz); if (gn > 25) { gx *= 25 / gn; gy *= 25 / gn; gz *= 25 / gn; }
        vx += gx * DT; vy += gy * DT; vz += gz * DT;
        px += vx * DT; py += vy * DT; pz += vz * DT;
        const vn = Math.sqrt(vx * vx + vy * vy + vz * vz);
        s[o + 21] = vx; s[o + 22] = vy; s[o + 14] = vz;
        if (vn > 0.03) { dx = vx / vn; dy = vy / vn; dz = vz / vn; }
        else {                                            // hovering: she turns slowly about the vertical
          const hx = dx + dz * 0.2 * DT, hz = dz - dx * 0.2 * DT, hn = Math.sqrt(hx * hx + hz * hz) || 1; dx = hx / hn; dy = 0; dz = hz / hn;
        }
        s[o] = px; s[o + 1] = py; s[o + 2] = pz; s[o + 3] = dx; s[o + 4] = dy; s[o + 5] = dz; s[o + 6] = vn;
        if (dist < 0.5 && s[o + 16] !== 3) s[o + 16] = 3;                           // she has arrived: she is the ball's core
        { const em = (s[o + 16] === 3 ? P.queenEmit : P.queenFlyingEmit) * DT; this._emit(px, py, pz, em);
          if (!sight) { const c = this._cellIndex(px, py, pz); if (c >= 0) this.qfield[c] += em / (P.cell * P.cell * P.cell); } }
        continue;
      }
      if (mode === 3) { this._ballStep(i, t); continue; }
      if (isQueen) {
        // the queen mills (slower, calmer) until queenSettle, then makes for the branch and alights (options 1-4)
        if (t >= P.queenSettle) {
          const tx = cx - px, ty = (ymaxBranch - s[o + 15] * sp0) - py, tz = cz - pz;
          const dist = Math.sqrt(tx * tx + ty * ty + tz * tz);
          if (dist < 0.04) { this._settle(i, cx, ymaxBranch - s[o + 15] * sp0, cz, t); continue; }   // C7: under the support
          const k = 8 + 10 / (dist + 0.2);
          ax = (tx / dist - dx) * k; ay = (ty / dist - dy) * k; az = (tz / dist - dz) * k;
          want = 1 + dist * 2.5; if (want > 12) want = 12;
        } else { ax *= 0.5; ay *= 0.5; az *= 0.5; want = ts * 0.6; }
        this._emit(px, py, pz, P.queenFlyingEmit * DT);
      } else {
        // neighbour/smell checks for milling bees run on every 4th step (staggered per bee) to save time
        const slowTick = ((this.step + i) & 3) === 0;
        // --- smell: become attracted once the scent here passes this bee's own threshold
        if (mode === 1 || slowTick) {
          this._sample(px, py, pz, sample);
          if (mode === 0 && sample[0] > s[o + 12]) { mode = 1; s[o + 16] = 1; }
          // CT52 (option 5): a following bee that no longer smells the scent gives up and mills
          else if (hover && mode === 1 && slowTick && t >= s[o + 14] && sample[0] < P.loseScent * s[o + 12]) { mode = 0; s[o + 16] = 0; }
        }

        if (mode === 1 && hover) {
          // CT52 (option 5): once the queen is in sight fly straight at her; elsewhere up the scent gradient.
          // (During an excursion out of the ball, t < slot 14, the bee ignores both and just flies.)
          let ux = 0, uy = 0, uz = 0;
          const vx = s[0] - px, vy = s[1] - py, vz = s[2] - pz, nearDist = Math.sqrt(vx * vx + vy * vy + vz * vz) || 1e-9;
          const away = t < s[o + 14];
          if (!away) {
            if (sight && nearDist < P.visRange) { ux = vx / nearDist; uy = vy / nearDist; uz = vz / nearDist; }
            else {
              const gn = Math.sqrt(sample[1] * sample[1] + sample[2] * sample[2] + sample[3] * sample[3]);
              if (gn > 1e-12) { ux = sample[1] / gn; uy = sample[2] / gn; uz = sample[3] / gn; }
            }
            ax += (ux - dx) * P.scentGain; ay += (uy - dy) * P.scentGain; az += (uz - dz) * P.scentGain;
            if (nearDist < 6) { want = 1.5 + nearDist * 2.0; if (want > ts) want = ts; }
            let joinD = nearDist;
            if (!sight && this.ball.n > 30) { const bx = this.ball.cx - px, by = this.ball.cy - py, bz = this.ball.cz - pz; joinD = Math.sqrt(bx * bx + by * by + bz * bz); }
            if (queenHolding && joinD < P.ballJoin) {
              s[o + 16] = 3; s[o + 6] = sp < P.ballSpeedMax ? sp : P.ballSpeedMax;
              s[o + 13] = r.next() < P.scentFrac ? 1 : 0;
              s[o + 18] = 0; s[o + 19] = 0; s[o + 20] = 0;
              continue;
            }
          }
        } else if (mode === 1) {
          // near the cluster: fly at what you can see; elsewhere: up the scent gradient
          let ux = 0, uy = 0, uz = 0, nearDist = 1e9;
          if (haveCluster) {
            const vx = C.cx - px, vy = C.cy - py, vz = C.cz - pz;
            nearDist = Math.sqrt(vx * vx + vy * vy + vz * vz);
            if (nearDist < P.nearField + C.halfWidth) { ux = vx / nearDist; uy = vy / nearDist; uz = vz / nearDist; }
          }
          if (ux === 0 && uy === 0 && uz === 0) {
            const gn = Math.sqrt(sample[1] * sample[1] + sample[2] * sample[2] + sample[3] * sample[3]);
            if (gn > 1e-12) { ux = sample[1] / gn; uy = sample[2] / gn; uz = sample[3] / gn; }
          }
          ax += (ux - dx) * P.scentGain; ay += (uy - dy) * P.scentGain; az += (uz - dz) * P.scentGain;
          if (nearDist < 6) { want = 1.0 + nearDist * 2.5; if (want > ts) want = ts; }
          // touch-down: on a settled bee
          if (haveCluster && nearDist < C.halfWidth + 1.2 && t >= s[o + 14] && this._tryLand(i, px, py, pz, t)) continue;
        } else {
          // --- milling: drawn toward where other bees are (local density), held loosely together
          if (slowTick) {
            // the bees it can see: centre of mass of the bees in the 3x3x3 block of 4-ft cells around it
            // (a ~12-ft visual neighbourhood); steer toward it, harder the further off-centre it is
            const ic = 1 / P.coarse, cgy = this.cgy, cgz = this.cgz, cd = this.coarseD, cs = P.coarse;
            const ix = Math.floor((px - this.gx0) * ic), iy = Math.floor(py * ic), iz = Math.floor((pz - this.gz0) * ic);
            let m = 0, mx = 0, my = 0, mz = 0;
            for (let a = -1; a <= 1; a++) { const jx = ix + a; if (jx < 0 || jx >= this.cgx) continue;
              for (let b = -1; b <= 1; b++) { const jy = iy + b; if (jy < 0 || jy >= cgy) continue;
                for (let c = -1; c <= 1; c++) { const jz = iz + c; if (jz < 0 || jz >= cgz) continue;
                  const w = cd[(jx * cgy + jy) * cgz + jz]; if (w === 0) continue;
                  m += w; mx += w * (this.gx0 + (jx + 0.5) * cs); my += w * ((jy + 0.5) * cs); mz += w * (this.gz0 + (jz + 0.5) * cs); } } }
            if (m > 1) {
              const vx = mx / m - px, vy = my / m - py, vz = mz / m - pz;
              const k = 4 * P.cohesionGain / (1.5 * cs);    // applied 1 step in 4 -> x4; per foot off-centre
              ax += k * vx; ay += k * vy; az += k * vz;
            } else {                                         // lost: head back toward the swarm
              const vx = cx - px, vy = cy - py, vz = cz - pz, vn = Math.sqrt(vx * vx + vy * vy + vz * vz) || 1;
              ax += 4 * P.cohesionGain * 3 * vx / vn; ay += 4 * P.cohesionGain * 3 * vy / vn; az += 4 * P.cohesionGain * 3 * vz / vn;
            }
          }
        }
        // --- stay with the swarm (milling bees)
        if (mode === 0) {
          const F = this.flyC, rh = P.cloudRadiusH * F[3], rv = P.cloudRadiusV * F[3];
          const ux = (px - F[0]) / rh, uy = (py - F[1]) / rv, uz = (pz - F[2]) / rh, q = Math.sqrt(ux * ux + uy * uy + uz * uz);
          if (q > P.cloudWallStart) {
            const k = P.cloudWallGain * (q - P.cloudWallStart) / (1 - P.cloudWallStart);
            const vx = F[0] - px, vy = F[1] - py, vz = F[2] - pz, vn = Math.sqrt(vx * vx + vy * vy + vz * vz) || 1;
            ax += k * vx / vn; ay += k * vy / vn; az += k * vz / vn;
          }
        }
        // --- keep clear of close neighbours (flying bees in the same and adjacent 1-ft cells)
        if (slowTick) {
          const c0 = this._cellIndex(px, py, pz);
          if (c0 >= 0) {
            const Y = P.gridY, Z = P.gridZ, R2 = P.sepRadius * P.sepRadius, sr = P.sepRadius * this.invCell;
            let rx = 0, ry = 0, rz = 0;
            // only look into a neighbouring cell when this bee is within sepRadius of that face
            const fx = (px - this.gx0) * this.invCell, fy = py * this.invCell, fz = (pz - this.gz0) * this.invCell;
            const ux = fx - Math.floor(fx), uy = fy - Math.floor(fy), uz = fz - Math.floor(fz);
            const a0 = ux < sr ? -1 : 0, a1 = ux > 1 - sr ? 1 : 0, b0 = uy < sr ? -1 : 0, b1 = uy > 1 - sr ? 1 : 0, e0 = uz < sr ? -1 : 0, e1 = uz > 1 - sr ? 1 : 0;
            for (let a = a0; a <= a1; a++) for (let b = b0; b <= b1; b++) for (let c = e0; c <= e1; c++) {
              const cc = c0 + a * Y * Z + b * Z + c;
              if (cc < 0 || cc >= this.nCells) continue;
              for (let j = this.flyHead[cc]; j !== -1; j = this.flyNext[j]) {
                if (j === i) continue;
                const q = j * STRIDE, ex = px - s[q], ey = py - s[q + 1], ez = pz - s[q + 2], d2 = ex * ex + ey * ey + ez * ez;
                if (d2 < R2 && d2 > 1e-12) { const d1 = Math.sqrt(d2), w = (P.sepRadius - d1) / (P.sepRadius * d1); rx += ex * w; ry += ey * w; rz += ez * w; }
              }
            }
            ax += 2 * P.sepGain * rx; ay += 2 * P.sepGain * ry; az += 2 * P.sepGain * rz;   // every 4th step, so the gain is doubled vs every 2nd
          }
        }
      }
      // outer limit of the open space (safety) and the ground
      const ox = px - cx, oz = pz - cz, oh = Math.sqrt(ox * ox + oz * oz);
      if (oh > P.outerWall) { ax -= 6 * ox / oh; az -= 6 * oz / oh; }
      if (py > cy + P.cloudRadiusV * 2) ay -= 6;
      const gc = P.groundClear * 3; if (py < gc) ay += 9 * (gc - py) / gc;
      // B1/C1: a bee making for the cluster that is above the beam flies out past its front or back face and comes in
      // from below (the cluster hangs under the front beam)
      if (!hover && (mode === 1 || (isQueen && t >= P.queenSettle))) {   // (option 5: nobody lands there)
        const ddx = px - cx, ddz = pz - cz, hz = 0.5 * P.beamD + 0.6;
        if ((ddx < 0 ? -ddx : ddx) < P.arborHalf + P.postW + 0.6 && py > this._beamY(px) - 0.05) {
          if ((ddz < 0 ? -ddz : ddz) < hz) { az += ddz < 0 ? -30 : 30; if (dy < 0.3) ay += 15; }
          else if ((ddz < 0 ? -ddz : ddz) < hz + 1.5) ay -= 25;
        }
      }

      // integrate: pure turning, then move
      const along = ax * dx + ay * dy + az * dz;
      ax -= along * dx; ay -= along * dy; az -= along * dz;
      dx += ax * DT; dy += ay * DT; dz += az * DT;
      const n = Math.sqrt(dx * dx + dy * dy + dz * dz); dx /= n; dy /= n; dz /= n;
      sp += (want - sp) * P.speedResponse * DT;
      px += dx * sp * DT; py += dy * sp * DT; pz += dz * sp * DT;
      if (mode === 0 || (isQueen && t < P.queenSettle)) pz += windNow * DT;   // C7: the wind carries the milling fliers (across the beam)
      if (py < 0.1) py = 0.1;
      // C1: flying bees cannot pass through the timber of the arbor (posts, beams, rafters, slats)
      { const so = this._so || (this._so = new Float64Array(3)), ax = this._stone(px, py, pz, s[o + 15], so);
        if (ax) { px = so[0]; py = so[1]; pz = so[2];
          if (ax === 1) dx = -dx; else if (ax === 2) dy = -dy; else dz = -dz; } }
      s[o] = px; s[o + 1] = py; s[o + 2] = pz; s[o + 3] = dx; s[o + 4] = dy; s[o + 5] = dz; s[o + 6] = sp;
    }

    this.step++;
    if (this.step % SUB === 0) this._slow(SUB * DT);
    this._saveCheckpoint();
  }

  // CT52: one step of a bee in the flying ball (mode 3): velocity integration with a pull toward the queen, a push
  // away from crowding (down the gradient of the bee density, stiffening above n0), its own erratic flight and its
  // own slow speed. Leaves the ball when flung far out, on an excursion, or when it loses the scent.
  _ballStep(i, t) {
    const s = this.state, P = this.P, r = this.rng, o = i * STRIDE, sq = Math.sqrt(DT);
    let px = s[o], py = s[o + 1], pz = s[o + 2], dx = s[o + 3], dy = s[o + 4], dz = s[o + 5], sp = s[o + 6];
    // A2: the centre it is pulled toward - the queen ('sight'), or the centre of the ball bees it can see ('scent')
    const sight = P.follow !== 'scent', B = this.ball, useBall = !sight && B.n > 30;
    const ccx = useBall ? B.cx : s[0], ccy = useBall ? B.cy : s[1], ccz = useBall ? B.cz : s[2];
    const ex = px - ccx, ey = py - ccy, ez = pz - ccz, rr = Math.sqrt(ex * ex + ey * ey + ez * ez) || 1e-9;
    const slowTick = ((this.step + i) & 3) === 0;
    if (slowTick) {
      if (rr > P.ballLeave) { s[o + 16] = 1; s[o + 13] = 0; return; }
      const sm = this._s4b || (this._s4b = new Float64Array(4));
      this._sample(px, py, pz, sm);
      if (sm[0] < P.loseScent * s[o + 12]) { s[o + 16] = 0; s[o + 13] = 0; return; }
      if (!sight) { this._sample(px, py, pz, sm, this.qfield); const gn = Math.sqrt(sm[1] * sm[1] + sm[2] * sm[2] + sm[3] * sm[3]); if (gn > 1e-12) { s[o + 18] = sm[1] / gn; s[o + 19] = sm[2] / gn; s[o + 20] = sm[3] / gn; } }
      if (r.next() < P.ballExcursion * 4 * DT) {           // a dart out of the ball: off for 1-3 s, then back
        s[o + 16] = 1; s[o + 13] = 0; s[o + 14] = t + 1 + 2 * r.next();
        s[o + 3] = ex / rr; s[o + 4] = ey / rr; s[o + 5] = ez / rr; s[o + 6] = 6; s[o + 11] = 9;
        return;
      }
    }
    // erratic flight (OU) - shares the wander slots with milling flight
    const wsig = P.wanderSigma * P.ballWander;
    let wx = s[o + 8], wy = s[o + 9], wz = s[o + 10];
    wx += -P.wanderTheta * wx * DT + wsig * sq * r.gauss();
    wy += -P.wanderTheta * wy * DT + wsig * 0.8 * sq * r.gauss();
    wz += -P.wanderTheta * wz * DT + wsig * sq * r.gauss();
    s[o + 8] = wx; s[o + 9] = wy; s[o + 10] = wz;
    let ts = s[o + 11];
    ts += P.speedTheta * (P.speedMean - ts) * DT + P.speedSigma * sq * r.gauss();
    if (ts < P.speedMin) ts = P.speedMin; else if (ts > P.speedMax) ts = P.speedMax;
    s[o + 11] = ts;
    let want = P.ballSpeed * ts / P.speedMean;
    if (want < P.ballSpeedMin) want = P.ballSpeedMin; else if (want > P.ballSpeedMax) want = P.ballSpeedMax;
    // forces (ft/s^2)
    let g = P.ballPull; if (rr > P.ballEdge) g += P.ballPullOut * (rr - P.ballEdge);
    let ax = -g * ex / rr, ay = -g * ey / rr, az = -g * ez / rr;
    { const qx = px - s[0], qy = py - s[1], qz = pz - s[2], qr = Math.sqrt(qx * qx + qy * qy + qz * qz) || 1e-9;   // not through the queen
      if (qr < 0.06) { const k = 40 * (0.06 - qr) / 0.06; ax += k * qx / qr; ay += k * qy / qr; az += k * qz / qr; } }
    // A2 'scent': drift up the scent gradient (the direction sampled on its last smell, kept in its unused grip slots)
    if (!sight) { ax += P.scentDrift * s[o + 18]; ay += P.scentDrift * s[o + 19]; az += P.scentDrift * s[o + 20]; }
    const bs = this._sb || (this._sb = new Float64Array(4));
    this._sampleBall(px, py, pz, bs);
    const rel = bs[0] / this.n0, kp = P.ballPress * (rel < 1 ? 1 : rel * rel) / this.n0;
    ax -= kp * bs[1]; ay -= kp * bs[2]; az -= kp * bs[3];
    // wander as a lateral acceleration (turn rate x speed)
    ax += wx * want; ay += wy * want; az += wz * want;
    // integrate the velocity, damp it, hold the bee's own speed
    let vx = dx * sp, vy = dy * sp, vz = dz * sp;
    vx += (ax - P.ballDrag * vx) * DT; vy += (ay - P.ballDrag * vy) * DT; vz += (az - P.ballDrag * vz) * DT;
    let vn = Math.sqrt(vx * vx + vy * vy + vz * vz) || 1e-9;
    let nsp = vn + (want - vn) * P.ballResponse * DT;
    if (nsp < 0.25) nsp = 0.25; else if (nsp > 2.5 * P.ballSpeedMax) nsp = 2.5 * P.ballSpeedMax;
    dx = vx / vn; dy = vy / vn; dz = vz / vn;
    px += dx * nsp * DT; py += dy * nsp * DT; pz += dz * nsp * DT;
    if (py < 0.1) py = 0.1;
    { const so = this._so || (this._so = new Float64Array(3)), axs = this._stone(px, py, pz, s[o + 15], so);
      if (axs) { px = so[0]; py = so[1]; pz = so[2]; if (axs === 1) dx = -dx; else if (axs === 2) dy = -dy; else dz = -dz; } }
    s[o] = px; s[o + 1] = py; s[o + 2] = pz; s[o + 3] = dx; s[o + 4] = dy; s[o + 5] = dz; s[o + 6] = nsp;
  }

  // contact test against settled bees (fine hash); land touching the first one found
  _tryLand(i, px, py, pz, t) {
    const s = this.state, o = i * STRIDE, H = this.cH, ri = s[o + 15], sp = this.spacing;
    const ix = Math.floor((px - this.cX0) / H), iy = Math.floor((py - this.cY0) / H), iz = Math.floor((pz - this.cZ0) / H);
    if (ix < 1 || iy < 1 || iz < 1 || ix >= this.cNx - 1 || iy >= this.cNy - 1 || iz >= this.cNz - 1) return false;
    for (let a = -1; a <= 1; a++) for (let b = -1; b <= 1; b++) for (let c = -1; c <= 1; c++) {
      const cc = ((ix + a) * this.cNy + (iy + b)) * this.cNz + (iz + c);
      for (let j = this.cHead[cc]; j !== -1; j = this.cNext[j]) {
        const q = j * STRIDE, ex = px - s[q], ey = py - s[q + 1], ez = pz - s[q + 2], d2 = ex * ex + ey * ey + ez * ez;
        const dc = (ri + s[q + 15]) * sp;
        if (d2 < dc * dc * 1.21) {
          const d1 = Math.sqrt(d2) || 1e-6;
          return this._settle(i, s[q] + ex / d1 * dc, s[q + 1] + ey / d1 * dc, s[q + 2] + ez / d1 * dc, t);
        }
      }
    }
    return false;
  }
  // ---------------------------------------------------------------- 30 Hz: scent field + cluster physics
  _slow(dt) {
    const s = this.state, P = this.P, N = this.count, r = this.rng;
    const q = s;                                        // queen = bee 0
    const queenSettled = q[16] === 2;
    // 1) emissions from the settled: queen + fanning surface bees blowing scent outward
    if (queenSettled) this._emit(q[0], q[1], q[2], P.queenEmit * dt);
    // CT52 (option 5): ball bees with the Nasonov gland exposed add scent where they fly
    if (P.hover) for (let i = 1; i < N; i++) { const o = i * STRIDE; if (s[o + 16] === 3 && s[o + 13] === 1) this._emit(s[o], s[o + 1], s[o + 2], P.flightScentEmit * dt); }
    const C = this.cStats;
    for (let i = 1; i < N; i++) {
      const o = i * STRIDE;
      if (s[o + 16] !== 2 || s[o + 13] !== 1 || !this.surface || !this.surface[i]) continue;
      const vx = s[o] - C.cx, vy = s[o + 1] - C.cy, vz = s[o + 2] - C.cz, vn = Math.sqrt(vx * vx + vy * vy + vz * vz) || 1;
      this._emit(s[o] + vx / vn * P.fanOutward, s[o + 1] + vy / vn * P.fanOutward, s[o + 2] + vz / vn * P.fanOutward, P.fanEmit * dt);
    }
    // 2) diffusion + decay
    this._updateField(dt);
    // 3) cluster physics for settled bees (crawl toward the queen, sag, keep packing distance, stay off the branch)
    if (queenSettled && this.step % P.relaxEvery === 0) this._relax(P.relaxEvery * DT);
    else this._buildClusterHash();
    // 4) rebuild the flying-bee neighbour structure
    this._buildDensity();
  }

  _settle(i, x, y, z, t) {
    const s = this.state, o = i * STRIDE;
    s[o] = x; s[o + 1] = y; s[o + 2] = z; s[o + 6] = 0; s[o + 16] = 2; s[o + 14] = t;
    s[o + 13] = (s[o + 17] !== 2 && this.rng.next() < this.P.fanFraction) ? 1 : 0;
    s[o + 8] = 0; s[o + 9] = 0; s[o + 10] = 0;
    s[o + 18] = -1; s[o + 19] = -1; s[o + 20] = -1;
    if (s[o + 17] === 2) s[o + 18] = -2;                // the queen holds the branch
    else if (this._takeHolds(i, null) === 0) {            // A7: grab the branch and/or the highest bees in reach --
      s[o + 16] = 1; s[o + 13] = 0; s[o + 6] = 2; s[o + 14] = t + 0.3;   // nothing above to hold: it can't land here, keeps flying
      return false;
    }
    this._hashInsert(i);
    this.cStats.n++;
    return true;
  }

  // ---------------------------------------------------------------- A7: grips
  // distance from a point to the branch surface (the branch is a cylinder along X)
  // a free spot on the bark: within reach of the branch and no other branch-holder closer than 0.9 contact distance
  _branchFree(i, x, y, z) {
    const s = this.state, P = this.P, sp = this.spacing, ri = s[i * STRIDE + 15] * sp, H = this.cH;
    // only the underside of the bark: within barkAngle of straight down (bees hang; they don't perch on the sides)
    if (!this._underArch(x, z) || y > this._axisY(x) || this._branchGap(x, y, z) >= 0.5 * s[i * STRIDE + 7] * P.gripReach) return false;   // C1: the beam's underside; C7: the stem's lower half
    if (P.shell && !this._inFootprint(x, y, z)) return false;         // C7: outside the attachment area
    const ix = Math.floor((x - this.cX0) / H), iy = Math.floor((y - this.cY0) / H), iz = Math.floor((z - this.cZ0) / H);
    let holders = 0, strained = false;
    for (let a = -1; a <= 1; a++) for (let b = -1; b <= 1; b++) for (let c = -1; c <= 1; c++) {
      const jx = ix + a, jy = iy + b, jz = iz + c;
      if (jx < 0 || jy < 0 || jz < 0 || jx >= this.cNx || jy >= this.cNy || jz >= this.cNz) continue;
      for (let j = this.cHead[(jx * this.cNy + jy) * this.cNz + jz]; j !== -1; j = this.cNext[j]) {
        if (j === i || !this._holds(j, -2) || s[j * STRIDE + 16] !== 2) continue;
        const q = j * STRIDE, ex = x - s[q], ey = y - s[q + 1], ez = z - s[q + 2], dc = 0.9 * (ri + s[q + 15] * sp);
        if (ex * ex + ey * ey + ez * ez < dc * dc) return false;          // that spot is taken
        holders++;
        if (s[q + 21] > P.barkComfort * s[q + 22]) strained = true;      // a bark-holder next to it is heavily loaded
      }
    }
    // C7: with the shell on, any free spot inside the footprint; off (C1-C6): only while founding, or next to
    // bark-holders that are strained
    return P.shell ? true : this.cStats.n < P.foundingBees || strained;
  }
  // how many settled bees hold on to bee j (holders are within one link, so the 27 hash cells around j suffice)
  _holderCount(j) {
    const s = this.state, H = this.cH, q = j * STRIDE;
    const ix = Math.floor((s[q] - this.cX0) / H), iy = Math.floor((s[q + 1] - this.cY0) / H), iz = Math.floor((s[q + 2] - this.cZ0) / H);
    let n = 0;
    for (let a = -2; a <= 2; a++) for (let b = -2; b <= 2; b++) for (let c = -2; c <= 2; c++) {
      const jx = ix + a, jy = iy + b, jz = iz + c;
      if (jx < 0 || jy < 0 || jz < 0 || jx >= this.cNx || jy >= this.cNy || jz >= this.cNz) continue;
      for (let k = this.cHead[(jx * this.cNy + jy) * this.cNz + jz]; k !== -1; k = this.cNext[k]) if (k !== j && this._holds(k, j)) n++;
    }
    return n;
  }
  // C1: height of the underside of the front beam above x (it sags: lowest, attachY, at mid-span)
  _beamY(x) {
    const P = this.P, u = (x - P.siteX) / P.arborHalf, uu = u * u;
    return P.attachY + P.beamSag * (uu < 1 ? uu : 1);
  }
  // C7: the vine stem's axis: a loop slung under the front beam, lowest (stemDrop below the beam) at mid-span
  _stemAxisY(x) {
    const P = this.P, u = (x - P.siteX) / P.stemHalf, uu = u * u;
    return this._beamY(x) - P.stemR - P.stemDrop * (uu < 1 ? 1 - uu : 0);
  }
  // the underside of what the bees hang from (C7: the stem, or the beam as in C1-C6)
  _soffitY(x) { return this.isBranch ? this._stemAxisY(x) - this.P.stemR : this._beamY(x); }
  _axisY(x) { return this.isBranch ? this._stemAxisY(x) : this._beamY(x); }   // (renderer: where a grip on the support ends)
  _underArch(x, z) { const P = this.P, dz = z - P.siteZ, dx = x - P.siteX;
    if (this.isBranch) return (dz < 0 ? -dz : dz) < P.stemR + 0.12 && (dx < 0 ? -dx : dx) < 0.7 * P.stemHalf;   // C7: near the stem
    return (dz < 0 ? -dz : dz) < 0.5 * P.beamD - 0.05 && (dx < 0 ? -dx : dx) < P.arborHalf - 0.5 * P.postW - 0.3; }   // C1: the beam's underside, clear of its worn edges and the posts
  // C7: inside the attachment area? Within the envelope's top radius of the queen (along the stem; on the beam, a
  // circle cut by the beam's usable width). Before the first envelope: a founding patch of ~0.06 ft.
  _inFootprint(x, y, z) {
    const s = this.state, E = this.env, r0 = E ? E.r0 : 0.06, dx = x - s[0], dz = z - s[2];
    return this.isBranch ? (dx < 0 ? -dx : dx) < r0 : dx * dx + dz * dz < r0 * r0;
  }
  // C7: keep a settled bee (radius rb) out of the support; writes the corrected (y, z) into out[]
  _solid(x, y, z, rb, out) {
    const P = this.P;
    if (this.isBranch) {
      const ay = this._stemAxisY(x), dx = x - P.siteX;
      if ((dx < 0 ? -dx : dx) < 0.7 * P.stemHalf) {
        if (y > ay) y = ay;                                  // nothing climbs above the stem's axis
        const ey = y - ay, ez = z - P.siteZ, d2 = ey * ey + ez * ez, m = P.stemR + rb;
        if (d2 < m * m) { const d = Math.sqrt(d2); if (d > 1e-9) { y = ay + ey * m / d; z = P.siteZ + ez * m / d; } else y = ay - m; }
      }
      const by = this._beamY(x) - rb; if (y > by) y = by;
    } else {
      const by = this._soffitY(x), lim = by - rb;
      if (y > lim && this._underArch(x, z)) y = lim; else if (y > by) y = by;
    }
    out[0] = y; out[1] = z;
  }
  /** C1: the solid parts of the arbor, as axis-aligned boxes {kind, x0, x1, y0, y1, z0, z1, sag}. A box with sag = 1
   *  is a beam: its y0 / y1 are at mid-span and it is lifted by _soffitY(x) - attachY along its length. */
  arborBoxes() {
    if (this._boxes) return this._boxes;
    const P = this.P, B = [], hs = P.arborHalf, pw = 0.5 * P.postW, bd = 0.5 * P.beamD, zf = P.siteZ, zb = P.siteZ - P.arborBack;
    const topPost = P.attachY + P.beamSag + P.beamH;                  // posts carry the beam ends
    for (const z of [zf, zb]) for (const sx of [-1, 1])
      B.push({ kind: 'post', x0: P.siteX + sx * hs - pw, x1: P.siteX + sx * hs + pw, y0: -0.5, y1: topPost, z0: z - pw, z1: z + pw, sag: 0 });
    for (const z of [zf, zb])
      B.push({ kind: 'beam', x0: P.siteX - hs - 0.9, x1: P.siteX + hs + 0.9, y0: P.attachY, y1: P.attachY + P.beamH, z0: z - bd, z1: z + bd, sag: 1 });
    const rw = 0.5 * P.rafterW;
    let rTop = 0;
    for (const rx of P.rafterX) {
      const x = P.siteX + rx, y0 = this._beamY(x) + P.beamH;
      B.push({ kind: 'rafter', x0: x - rw, x1: x + rw, y0, y1: y0 + P.rafterH, z0: zb - P.rafterOver, z1: zf + P.rafterOver, sag: 0 });
      if (y0 + P.rafterH > rTop) rTop = y0 + P.rafterH;
    }
    for (const dz of P.slatZ)
      B.push({ kind: 'slat', x0: P.siteX - hs - 0.6, x1: P.siteX + hs + 0.6, y0: rTop, y1: rTop + P.slatH, z0: zf + dz - 0.5 * P.slatW, z1: zf + dz + 0.5 * P.slatW, sag: 0 });
    this._bbox = [P.siteX - hs - 1, P.siteX + hs + 1, -0.5, rTop + P.slatH, zb - P.rafterOver, zf + P.rafterOver];
    return (this._boxes = B);
  }
  // C1: keep a flying bee out of the timber: pushed out through the nearest face of the box it is in.
  // Returns 0 if it was clear; otherwise writes the corrected position into out[] and returns the face normal axis
  // (1 = x, 2 = y, 3 = z) so the caller can reflect its heading.
  _stone(px, py, pz, r, out) {
    if (this.pole) { // CT52.A2 (option 5): the measuring pole (a vertical cylinder): pushed out radially
      const ex = px - this.pole[0], ez = pz - this.pole[1], R = this.P.poleR + r, d2 = ex * ex + ez * ez;
      if (d2 < R * R && py < this.P.poleH + r) {
        const d = Math.sqrt(d2);
        if (d < 1e-9) { out[0] = this.pole[0] + R; out[2] = pz; } else { out[0] = this.pole[0] + ex / d * R; out[2] = this.pole[1] + ez / d * R; }
        out[1] = py; return (ex < 0 ? -ex : ex) > (ez < 0 ? -ez : ez) ? 1 : 3;
      }
    }
    const B = this._boxes || this.arborBoxes(), bb = this._bbox;
    if (px < bb[0] - r || px > bb[1] + r || py < bb[2] - r || py > bb[3] + r || pz < bb[4] - r || pz > bb[5] + r) return 0;
    for (let k = 0; k < B.length; k++) {
      const b = B[k], lift = b.sag ? this._beamY(px) - this.P.attachY : 0;
      const x0 = b.x0 - r, x1 = b.x1 + r, y0 = b.y0 + lift - r, y1 = b.y1 + lift + r, z0 = b.z0 - r, z1 = b.z1 + r;
      if (px <= x0 || px >= x1 || py <= y0 || py >= y1 || pz <= z0 || pz >= z1) continue;
      let best = px - x0, axis = 1; out[0] = x0; out[1] = py; out[2] = pz;
      if (x1 - px < best) { best = x1 - px; out[0] = x1; }
      if (py - y0 < best) { best = py - y0; axis = 2; out[0] = px; out[1] = y0; }
      if (y1 - py < best) { best = y1 - py; axis = 2; out[0] = px; out[1] = y1; }
      if (pz - z0 < best) { best = pz - z0; axis = 3; out[0] = px; out[1] = py; out[2] = z0; }
      if (z1 - pz < best) { best = z1 - pz; axis = 3; out[0] = px; out[1] = py; out[2] = z1; }
      return axis;
    }
    return 0;
  }
  /** A9 (derived, never part of the state): the hanging STRANDS. Each settled bee that hangs from the stone is
   *  followed up its highest hold (the grip with the fewest links to the iron; ties: first grip slot) to the bee
   *  that grips the iron at the top of its strand. root[i] = that bee (-1: not hanging), parent[i] = the hold
   *  followed (-2: the iron itself, -1: not hanging), depth[i] = links from the iron. */
  strands(root, parent, depthOut) {
    const s = this.state, N = this.count;
    this._topology();
    const depth = this.depth, order = this.order, n = this.nOrder;
    root.fill(-1); parent.fill(-1); if (depthOut) depthOut.set(depth);
    for (let k = 0; k < n; k++) {
      const i = order[k], o = i * STRIDE, d = depth[i];
      if (d === 0) { root[i] = i; parent[i] = -2; continue; }
      let best = -1, bd = 1e9;
      for (let g = 0; g < 3; g++) { const v = s[o + 18 + g];
        if (v >= 0 && v < N && s[v * STRIDE + 16] === 2 && depth[v] >= 0 && depth[v] < d && depth[v] < bd) { bd = depth[v]; best = v; } }
      if (best >= 0) { parent[i] = best; root[i] = root[best]; }
    }
    return n;
  }
  _branchGap(x, y, z) {                              // B1: distance below the soffit (only under the arch)
    if (!this._underArch(x, z)) return 1e9;
    if (this.isBranch) { const ey = y - this._stemAxisY(x), ez = z - this.P.siteZ; return Math.sqrt(ey * ey + ez * ez) - this.P.stemR; }   // C7: from the bark
    return this._soffitY(x) - y;
  }
  _link(i, j) { const s = this.state; return 0.5 * (s[i * STRIDE + 7] + s[j * STRIDE + 7]) * this.P.linkBody; }
  _grips(i, g) { const o = i * STRIDE + 18; return this.state[o + g]; }
  _holds(i, j) { const o = i * STRIDE; return this.state[o + 18] === j || this.state[o + 19] === j || this.state[o + 20] === j; }
  // fill free grip slots of bee i: the branch first if in reach, then settled bees in reach, highest first.
  // depth (optional): only bees already hanging from the branch (depth >= 0) count as holds.
  _takeHolds(i, depth) {
    const s = this.state, P = this.P, o = i * STRIDE, sp = this.spacing, H = this.cH;
    const x = s[o], y = s[o + 1], z = s[o + 2], ri = s[o + 15] * sp;
    let free = 0; for (let g = 0; g < P.maxGrips; g++) if (s[o + 18 + g] === -1) free++;
    if (!free) return 0;
    const put = (v) => { for (let g = 0; g < P.maxGrips; g++) if (s[o + 18 + g] === -1) { s[o + 18 + g] = v; free--; return; } };
    let added = 0;
    if (!this._holds(i, -2) && this._branchFree(i, x, y, z)) { put(-2); added++; }
    const ix = Math.floor((x - this.cX0) / H), iy = Math.floor((y - this.cY0) / H), iz = Math.floor((z - this.cZ0) / H);
    while (free > 0) {
      let best = -1, bestY = -1e9;
      for (let a = -2; a <= 2; a++) for (let b = -2; b <= 2; b++) for (let c = -2; c <= 2; c++) {
        const jx = ix + a, jy = iy + b, jz = iz + c;
        if (jx < 0 || jy < 0 || jz < 0 || jx >= this.cNx || jy >= this.cNy || jz >= this.cNz) continue;
        for (let j = this.cHead[(jx * this.cNy + jy) * this.cNz + jz]; j !== -1; j = this.cNext[j]) {
          if (j === i || s[j * STRIDE + 16] !== 2 || this._holds(i, j)) continue;
          if (depth && depth[j] < 0) continue;
          const q = j * STRIDE, ex = x - s[q], ey = y - s[q + 1], ez = z - s[q + 2], reach = this._link(i, j) * P.gripReach;
          if (ey > P.holdBelow * reach) continue;          // holds are above (or about level), never well below
          if (ex * ex + ey * ey + ez * ez < reach * reach && s[q + 1] > bestY && this._holderCount(j) < P.maxHeldBy) { bestY = s[q + 1]; best = j; }
        }
      }
      if (best < 0) break;
      put(best); added++;
    }
    return added;
  }
  // derived (never written to the state): which bees hang from the branch through their grips (depth = links
  // from the branch, BFS order), and the load each one carries (bee-weights, own weight included).
  _topology() {
    const s = this.state, N = this.count, P = this.P;
    if (!this.depth) {
      this.depth = new Int32Array(N); this.order = new Int32Array(N); this.chStart = new Int32Array(N + 1);
      this.chList = new Int32Array(N * 3); this.chCur = new Int32Array(N); this.load = new Float64Array(N);
    }
    const depth = this.depth, order = this.order, cs = this.chStart, cl = this.chList, cur = this.chCur, load = this.load;
    const valid = (v) => v >= 0 && s[v * STRIDE + 16] === 2;
    cs.fill(0);
    for (let i = 0; i < N; i++) { const o = i * STRIDE; if (s[o + 16] !== 2) continue;
      for (let g = 0; g < 3; g++) { const v = s[o + 18 + g]; if (valid(v) && v !== i) cs[v + 1]++; } }
    for (let i = 0; i < N; i++) cs[i + 1] += cs[i];
    for (let i = 0; i < N; i++) cur[i] = cs[i];
    for (let i = 0; i < N; i++) { const o = i * STRIDE; if (s[o + 16] !== 2) continue;
      for (let g = 0; g < 3; g++) { const v = s[o + 18 + g]; if (valid(v) && v !== i) cl[cur[v]++] = i; } }
    depth.fill(-1);
    let n = 0;
    for (let i = 0; i < N; i++) { const o = i * STRIDE;
      if (s[o + 16] === 2 && (s[o + 18] === -2 || s[o + 19] === -2 || s[o + 20] === -2)) { depth[i] = 0; order[n++] = i; } }
    const roots = n;
    for (let h = 0; h < n; h++) { const p = order[h];
      for (let k = cs[p]; k < cs[p + 1]; k++) { const c = cl[k]; if (depth[c] === -1) { depth[c] = depth[p] + 1; order[n++] = c; } } }
    this.nOrder = n;
    // loads: each bee passes its load (own weight + what hangs from it) up its supporting grips, shared equally
    load.fill(0);
    for (let k = 0; k < n; k++) load[order[k]] = this.wgt[order[k]];
    let branchLoad = 0, maxLoad = 0, over = 0, maxDepth = 0, rootLoad = 0;
    for (let k = n - 1; k >= 0; k--) {
      const i = order[k], o = i * STRIDE, d = depth[i];
      let ns = 0;
      for (let g = 0; g < 3; g++) { const v = s[o + 18 + g]; if (v === -2 || (valid(v) && depth[v] >= 0 && depth[v] < d)) ns++; }
      const share = load[i] / ns;
      for (let g = 0; g < 3; g++) { const v = s[o + 18 + g];
        if (v === -2) branchLoad += share; else if (valid(v) && depth[v] >= 0 && depth[v] < d) load[v] += share; }
    }
    for (let k = 0; k < n; k++) { const i = order[k], L = load[i] - this.wgt[i];   // held = load minus own weight
      if (L > maxLoad) maxLoad = L; if (L > s[i * STRIDE + 22]) over++; if (depth[i] > maxDepth) maxDepth = depth[i]; if (depth[i] === 0) rootLoad += L; }
    this.loadStats = { hanging: n, onBranch: roots, branchLoad, maxHeld: maxLoad, meanHeldTop: roots ? rootLoad / roots : 0, overloaded: over, maxDepth };
  }

  _relax(dt) {
    const s = this.state, P = this.P, N = this.count, r = this.rng, sp = this.spacing, t = this.step * DT;
    const qx = s[0], qz = s[2];
    const bz = P.siteZ;
    if (!this.corr) { this.corr = new Float64Array(N * 3); this.nbr = new Int32Array(N); if (!this.surface) this.surface = new Uint8Array(N); }
    if (!this.shell) this.shell = new Uint8Array(N);
    const corr = this.corr, nbr = this.nbr, shell = this.shell;
    nbr.fill(0);
    this._findShell();                                   // C7: who is in the outer layer (from last tick's surface)
    // 0) holds on bees that have flown off are gone
    for (let i = 0; i < N; i++) { const o = i * STRIDE; if (s[o + 16] !== 2) continue;
      for (let g = 0; g < 3; g++) { const v = s[o + 18 + g];
        if (v >= 0 && (s[v * STRIDE + 16] !== 2 || s[o + 1] - s[v * STRIDE + 1] > P.letGoBelow * this._link(i, v))) s[o + 18 + g] = -1; } }
    // 1) who hangs from what, and the loads
    this._topology();
    const depth = this.depth, order = this.order, load = this.load, nOrder = this.nOrder;
    for (let i = 0; i < N; i++) s[i * STRIDE + 21] = depth[i] >= 0 ? load[i] - this.wgt[i] : 0;
    // 2) bees with no hold leading to the branch grab what they can reach -- or fall and fly back
    for (let i = 1; i < N; i++) { const o = i * STRIDE;
      if (s[o + 16] !== 2 || depth[i] >= 0) continue;
      for (let g = 0; g < 3; g++) s[o + 18 + g] = -1;
      if (this._takeHolds(i, depth) === 0) {
        s[o + 16] = 1; s[o + 6] = 4; s[o + 13] = 0; s[o + 14] = t + 1 + r.next() * 2;
        s[o + 3] = 0; s[o + 4] = -1; s[o + 5] = 0;
      }
    }
    // 3) better holds: now and then a bee lets go of its most-loaded hold for a higher, less-loaded one in reach
    //    (or the branch). This shares the load and moves bees up toward the attachment.
    for (let k = 0; k < nOrder; k++) {
      const i = order[k]; if (i === 0 || depth[i] === 0) continue;
      if (r.next() >= P.regrip) continue;
      const o = i * STRIDE, d = depth[i];
      let worst = -1, wl = -1, freeSlot = -1;
      for (let g = 0; g < P.maxGrips; g++) { const v = s[o + 18 + g];
        if (v === -1) { if (freeSlot < 0) freeSlot = g; continue; }
        if (v >= 0 && load[v] > wl) { wl = load[v]; worst = g; } }
      const x = s[o], y = s[o + 1], z = s[o + 2], ri = s[o + 15] * sp;
      // the branch, if a leg can reach it
      // climb onto free bark within one body length (the spot on the bark straight toward the branch axis)
      if (!this._holds(i, -2) && this._branchGap(x, y, z) < s[o + 7] * P.gripReach * P.climbReach) {
        // B1: up onto the timber - straight above, else the nearest free spot in two rings around that point
        // (on a flat underside the spot straight above is usually the one its own hold already occupies)
        const OFF = Swarm.RING, step = 2 * ri;
        let placed = false;
        for (let k = 0; k < OFF.length; k += 2) {
          let x2 = x + OFF[k] * step, z2 = z + OFF[k + 1] * step, ny2 = this._soffitY(x2) - s[o + 15];
          if (this.isBranch) {                          // C7: onto the stem's bark: around it from where the bee is
            const ay = this._stemAxisY(x2), m = P.stemR + s[o + 15];
            let ey = y - ay, ez = z - P.siteZ, d = Math.sqrt(ey * ey + ez * ez) || 1; ey /= d; ez /= d;
            const tt = OFF[k + 1] * step / m; let py2 = ey + tt * ez, pz2 = ez - tt * ey;   // step along the bark
            d = Math.sqrt(py2 * py2 + pz2 * pz2) || 1; ny2 = ay + py2 / d * m; z2 = P.siteZ + pz2 / d * m;
          }
          if (this._branchFree(i, x2, ny2, z2)) {
            const g = freeSlot >= 0 ? freeSlot : worst;
            if (g >= 0) { s[o + 18 + g] = -2; s[o] = x2; s[o + 1] = ny2; s[o + 2] = z2; }
            placed = true; break;
          }
        }
        if (placed) continue;
      }
      let best = -1, bl = 1e9;
      const H = this.cH, ix = Math.floor((x - this.cX0) / H), iy = Math.floor((y - this.cY0) / H), iz = Math.floor((z - this.cZ0) / H);
      for (let a = -2; a <= 2; a++) for (let b = -2; b <= 2; b++) for (let c = -2; c <= 2; c++) {
        const jx = ix + a, jy = iy + b, jz = iz + c;
        if (jx < 0 || jy < 0 || jz < 0 || jx >= this.cNx || jy >= this.cNy || jz >= this.cNz) continue;
        for (let j = this.cHead[(jx * this.cNy + jy) * this.cNz + jz]; j !== -1; j = this.cNext[j]) {
          if (j === i || depth[j] < 0 || depth[j] >= d || this._holds(i, j)) continue;
          const q = j * STRIDE, ex = x - s[q], ey = y - s[q + 1], ez = z - s[q + 2], reach = this._link(i, j) * P.gripReach;
          if (ey > P.holdBelow * reach) continue;
          if (ex * ex + ey * ey + ez * ez < reach * reach) {
            if (load[j] < bl) { bl = load[j]; best = j; }
          }
        }
      }
      if (best < 0 || this._holderCount(best) >= P.maxHeldBy) continue;
      if (freeSlot >= 0) s[o + 18 + freeSlot] = best;
      else if (worst >= 0 && (bl + this.wgt[i] < P.climbRatio * wl || wl - this.wgt[s[o + 18 + worst]] > s[s[o + 18 + worst] * STRIDE + 22])) s[o + 18 + worst] = best;
    }
    // C7: the envelope for this tick (its size follows the settled bees; it leans with the gusts)
    this._envelope(t);
    const E = this.env, gust = E ? E.gust : 0;
    // 4) gravity (each hanging bee is lowered until its grips stop it) + a slow sideways crawl toward the queen + jitter
    for (let k = 0; k < nOrder; k++) {
      const i = order[k]; if (i === 0 || depth[i] === 0) continue;   // bees holding the bark stay put
      const o = i * STRIDE;
      let vx = P.crawlH * (qx - s[o]), vz = P.crawlH * (qz - s[o + 2]);
      const v = Math.sqrt(vx * vx + vz * vz);
      if (v > P.crawlMax) { const kk = P.crawlMax / v; vx *= kk; vz *= kk; }
      s[o] += vx * dt + (r.next() - 0.5) * 0.002;
      s[o + 1] += -(P.shell ? P.sagShell : P.sag) + (r.next() - 0.5) * 0.002;
      s[o + 2] += vz * dt + (r.next() - 0.5) * 0.002;
      if (gust !== 0) { let hf = 2 * (E.top - s[o + 1]); if (hf > 1.5) hf = 1.5; else if (hf < 0) hf = 0; s[o + 2] += P.windPush * gust * hf; }   // C7: the wind pushes the hanging bees across the beam
    }
    this._buildClusterHash();
    if (!this.p3) { this.p3 = new Float64Array(N * 3); this.rad = new Float64Array(N); }
    const p3 = this.p3, rad = this.rad, sol = this._sol || (this._sol = new Float64Array(2));
    const spS = P.shell ? this.shellSpacing : sp;                       // C7: the shell packs tighter than the core
    for (let i = 0; i < N; i++) { const o = i * STRIDE; p3[i * 3] = s[o]; p3[i * 3 + 1] = s[o + 1]; p3[i * 3 + 2] = s[o + 2]; rad[i] = s[o + 15] * (shell[i] ? spS : sp); }
    // grips as links, solved from the branch downward (BFS order: a bee's holds are placed before it)
    const gs = P.shell ? P.gripSoft : 1;
    const gripPass = () => {
      for (let k = 0; k < nOrder; k++) {
        const i = order[k]; if (i === 0 || depth[i] === 0) continue;
        const o = i * STRIDE;
        let x = p3[i * 3], y = p3[i * 3 + 1], z = p3[i * 3 + 2];
        const by = this._soffitY(x);
        for (let rep = 0; rep < 2; rep++) for (let g = 0; g < 3; g++) {
          const v = s[o + 18 + g];
          if (v === -2) {                                            // B1: a grip on the stone: hang at most half a body below it
            const mx = 0.5 * s[o + 7] * P.linkBody;
            if (this.isBranch) {                                     // C7: at most half a body out from the stem's bark
              const ay = this._stemAxisY(x), ey = y - ay, ez = z - P.siteZ, d = Math.sqrt(ey * ey + ez * ez), m = P.stemR + mx;
              if (d > m) { y = ay + ey * m / d; z = P.siteZ + ez * m / d; }
            } else if (by - y > mx) y = by - mx;
          } else if (v >= 0 && depth[v] >= 0 && depth[v] < depth[i]) {
            const ex = x - p3[v * 3], ey = y - p3[v * 3 + 1], ez = z - p3[v * 3 + 2], d2 = ex * ex + ey * ey + ez * ez;
            const L = this._link(i, v);
            if (d2 > L * L) { const f = L / Math.sqrt(d2);             // C7: with the envelope on, a grip gives a little (gripSoft)
              x += (p3[v * 3] + ex * f - x) * gs; y += (p3[v * 3 + 1] + ey * f - y) * gs; z += (p3[v * 3 + 2] + ez * f - z) * gs; }
          }
        }
        // the support is solid
        this._solid(x, y, z, s[o + 15], sol); y = sol[0]; z = sol[1];
        p3[i * 3] = x; p3[i * 3 + 1] = y; p3[i * 3 + 2] = z;
      }
    };
    const ny = this.cNy, nz = this.cNz, nx = this.cNx, head = this.cHead, next = this.cNext, cellOf = this.cCellOf;
    const HS = Swarm.HALF;
    // overlap, Gauss-Seidel (each push applied at once; fixed order -> deterministic). count: tally neighbours.
    const overlapPass = (count) => {
      for (let i = 0; i < N; i++) {
        if (s[i * STRIDE + 16] !== 2) continue;
        let xi = p3[i * 3], yi = p3[i * 3 + 1], zi = p3[i * 3 + 2];
        const ri = rad[i];
        let cnt = 0;
        const c0 = cellOf[i], ix = (c0 / (ny * nz)) | 0, iy = ((c0 / nz) | 0) % ny, iz = c0 % nz;
        // half stencil: own cell (bees after i in the list) + the 13 neighbour cells 'after' it -> each pair once
        for (let st = 0; st < 14; st++) {
          const a = HS[st * 3], b = HS[st * 3 + 1], c = HS[st * 3 + 2];
          const jx = ix + a, jy = iy + b, jz = iz + c;
          if (jx < 0 || jy < 0 || jz < 0 || jx >= nx || jy >= ny || jz >= nz) continue;
          for (let j = st === 0 ? next[i] : head[(jx * ny + jy) * nz + jz]; j !== -1; j = next[j]) {
            let ex = xi - p3[j * 3], ey = yi - p3[j * 3 + 1], ez = zi - p3[j * 3 + 2];
            let d2 = ex * ex + ey * ey + ez * ez; const dc = ri + rad[j];
            if (count && d2 < dc * dc * 1.69) { cnt++; nbr[j]++; }
            if (d2 < dc * dc) {
              if (d2 <= 1e-14) { if (!P.shell) continue; ex = 1e-5; ey = (i & 1 ? 1e-5 : -1e-5); ez = (j & 1 ? 1e-5 : -1e-5); d2 = 3e-10; }   // C7: coincident: part them
              const d1 = Math.sqrt(d2), f = (dc - d1) / d1;
              const ai = i === 0 || depth[i] === 0, aj = j === 0 || depth[j] === 0;     // the queen and bark-holders are anchored
              if (ai && aj && !(P.shell && i && j)) continue;         // C7: two bark-holders shuffle apart along the bark
              const wi = ai && !aj ? 0 : (aj && !ai ? 1 : 0.5), wj = aj && !ai ? 0 : (ai && !aj ? 1 : 0.5);
              xi += ex * f * wi; yi += ey * f * wi; zi += ez * f * wi;
              p3[j * 3] -= ex * f * wj; p3[j * 3 + 1] -= ey * f * wj; p3[j * 3 + 2] -= ez * f * wj;
            }
          }
        }
        p3[i * 3] = xi; p3[i * 3 + 1] = yi; p3[i * 3 + 2] = zi;
        if (count) nbr[i] += cnt;
      }
    };
    const solidPass = () => {                             // the support is solid; nothing climbs above it
      for (let i = 1; i < N; i++) {
        if (s[i * STRIDE + 16] !== 2) continue;
        this._solid(p3[i * 3], p3[i * 3 + 1], p3[i * 3 + 2], s[i * STRIDE + 15], sol);
        p3[i * 3 + 1] = sol[0]; p3[i * 3 + 2] = sol[1];
      }
    };
    const extra = P.shell ? P.overlapExtra : 0;
    for (let it = 0; it < P.relaxIters; it++) {
      if (gs > 0) gripPass();                             // C7: with the shell on the grips do not pull (gripSoft 0)
      if (P.shell) this._contain(p3, depth);              // C7: the envelope: bees outside it are drawn back toward it
      overlapPass(it === P.relaxIters - 1 && extra === 0);
      solidPass();
    }
    // C7: extra packing passes after the grips (a crowd under one hold needs several passes to spread out)
    for (let e = 0; e < extra; e++) { overlapPass(e === extra - 1); solidPass(); }
    // C7: grips that the packing has stretched are re-taken where the bee now is (the network gives way plastically
    // instead of pulling the crowd back together next tick)
    if (P.shell) this._regripStretched(p3, depth, load);
    // (the last pass is the overlap pass: bees never end a tick inside one another; links may be a hair long)
    for (let i = 1; i < N; i++) { const o = i * STRIDE; if (s[o + 16] !== 2) continue; s[o] = p3[i * 3]; s[o + 1] = p3[i * 3 + 1]; s[o + 2] = p3[i * 3 + 2]; }
    this._buildClusterHash();
    // surface bees (fewer neighbours than the cluster average) can fan; now and then one that holds nobody up takes off
    let sum = 0, cntS = 0;
    for (let i = 0; i < N; i++) if (s[i * STRIDE + 16] === 2) { sum += nbr[i]; cntS++; }
    const cut = cntS ? P.fanSurfaceRatio * sum / cntS : 0;
    const cs = this.chStart;
    for (let i = 1; i < N; i++) {
      const o = i * STRIDE; if (s[o + 16] !== 2) { this.surface[i] = 0; continue; }
      this.surface[i] = (P.shell && this.env) ? (this._envOut(s[o], s[o + 1], s[o + 2]) > -1.2 * this.contact ? 1 : 0) : (nbr[i] < cut ? 1 : 0);   // C7: the outer layer of the envelope
      if (this.surface[i] && cs[i + 1] === cs[i] && r.next() < P.retakeoff) {
        s[o + 16] = 1; s[o + 6] = 8; s[o + 13] = 0; s[o + 18] = -1; s[o + 19] = -1; s[o + 20] = -1;
        s[o + 14] = t + 2 + r.next() * 4;
        const vx = s[o] - s[0], vy = s[o + 1] - s[1], vz = s[o + 2] - s[2], vn = Math.sqrt(vx * vx + vy * vy + vz * vz) || 1;
        s[o + 3] = vx / vn; s[o + 4] = vy / vn; s[o + 5] = vz / vn;
        s[o] += s[o + 3] * 0.05; s[o + 1] += s[o + 4] * 0.05; s[o + 2] += s[o + 5] * 0.05;
      }
    }
  }

  // ---------------------------------------------------------------- C7: shell, tension, gusts
  // the shell: the settled bees within shellThick contact distances inside the envelope's surface (from the last
  // tick's envelope, which checkpoints keep)
  _findShell() {
    const s = this.state, N = this.count, P = this.P, sh = this.shell;
    sh.fill(0); this.shellCount = 0;
    if (!P.shell || !this.env) return;
    const lim = -P.shellThick * this.contact;
    for (let i = 0; i < N; i++) { const o = i * STRIDE; if (s[o + 16] !== 2) continue;
      if (this._envOut(s[o], s[o + 1], s[o + 2]) > lim) { sh[i] = 1; this.shellCount++; } }
  }
  // C7: the envelope's profile: radius / greatest radius at u = depth / length (0 = the support, 1 = the tip).
  // Above the widest point it opens from envTop toward 1 (fast, then flattening); below, half an ellipse, drawn
  // toward a point by envTaper.
  _envG(u) {
    const P = this.P, a = P.envTop, w = P.envWidest;
    if (u <= 0) return a;
    if (u >= 1) return 0;
    if (u < w) { const t = 1 - u / w; return a + (1 - a) * (1 - t * t); }
    const v = (u - w) / (1 - w), q = 1 - v * v;
    return Math.sqrt(q > 0 ? q : 0) * (1 - P.envTaper * v);
  }
  _envInit() {                                           // integral of g^2 over [0, 1] (Simpson, 200 steps)
    const n = 200; let sum = 0;
    for (let k = 0; k <= n; k++) { const g = this._envG(k / n), w = k === 0 || k === n ? 1 : (k & 1 ? 4 : 2); sum += w * g * g; }
    this.envI = sum / (3 * n);
  }
  _envelope(t) {
    const P = this.P, s = this.state, n = this.cStats.n;
    if (!P.shell || n < 1) { this.env = null; return; }
    const fs = this.shellCount && n ? this.shellCount / n : 0.5;         // share of the bees in the shell (last tick)
    const V = n * (this.beeVolume / this.count) * (fs / P.shellPack + (1 - fs) / this.packing) * P.envFill;
    const Rm = cbrt(V / (3.141592653589793 * 2 * P.envAspect * this.envI)), L = 2 * P.envAspect * Rm;
    const gust = P.wind > 0 ? P.wind * this._gust(t) : 0;
    let r0 = P.envTop * Rm; if (r0 < 0.06) r0 = 0.06;
    this.env = { Rm, L, r0, qx: s[0], qz: s[2], top: this._soffitY(s[0]), lean: P.windLean * gust, gust };
  }
  // how far a point is outside the envelope (ft; negative inside)
  _envOut(x, y, z) {
    const E = this.env, h = E.top - y, lz = E.lean * (h > 0 ? h : 0), dx = x - E.qx, dz = z - E.qz - lz;
    const rho = Math.sqrt(dx * dx + dz * dz), u = h / E.L;
    if (u > 1) return (h - E.L) + rho;
    return rho - E.Rm * this._envG(u < 0 ? 0 : u);
  }
  // draw every hanging bee that is outside the envelope back toward it: along the line to the envelope's centre
  // (on its axis at the widest point), by envPull of how far out it is, at most envPullMax per pass
  _contain(p3, depth) {
    const E = this.env; if (!E) return;
    const s = this.state, N = this.count, P = this.P, cy = E.top - P.envWidest * E.L;
    for (let i = 1; i < N; i++) {
      if (s[i * STRIDE + 16] !== 2 || depth[i] <= 0) continue;
      const x = p3[i * 3], y = p3[i * 3 + 1], z = p3[i * 3 + 2], h = E.top - y, lz = E.lean * (h > 0 ? h : 0);
      const dx = x - E.qx, dz = z - E.qz - lz, rho = Math.sqrt(dx * dx + dz * dz);
      const u = h / E.L;
      let out;
      if (u > 1) out = (h - E.L) + rho;
      else { const r = E.Rm * this._envG(u < 0 ? 0 : u); out = rho - r; }
      if (out <= 0) continue;
      let m = P.envPull * out; if (m > P.envPullMax) m = P.envPullMax;
      const cx = E.qx, czz = E.qz + E.lean * (P.envWidest * E.L);
      const vx = cx - x, vy = cy - y, vz = czz - z, vn = Math.sqrt(vx * vx + vy * vy + vz * vz);
      if (vn < 1e-9) continue;
      p3[i * 3] = x + vx / vn * m; p3[i * 3 + 1] = y + vy / vn * m; p3[i * 3 + 2] = z + vz / vn * m;
    }
  }
  _regripStretched(p3, depth, load) {
    const s = this.state, N = this.count, P = this.P, H = this.cH, lim = P.stretch;
    for (let i = 1; i < N; i++) {
      const o = i * STRIDE; if (s[o + 16] !== 2 || depth[i] <= 0) continue;
      const x = p3[i * 3], y = p3[i * 3 + 1], z = p3[i * 3 + 2], d = depth[i];
      for (let g = 0; g < P.maxGrips; g++) {
        const v = s[o + 18 + g]; if (v < 0) continue;
        const ex = x - p3[v * 3], ey = y - p3[v * 3 + 1], ez = z - p3[v * 3 + 2], L = this._link(i, v);
        if (ex * ex + ey * ey + ez * ez <= lim * lim * L * L) continue;
        // stretched: the least-loaded bee above, within reach of where this bee is now, that it does not hold yet
        const ix = Math.floor((x - this.cX0) / H), iy = Math.floor((y - this.cY0) / H), iz = Math.floor((z - this.cZ0) / H);
        let best = -1, bl = 1e9;
        for (let a = -2; a <= 2; a++) for (let b = -2; b <= 2; b++) for (let c = -2; c <= 2; c++) {
          const jx = ix + a, jy = iy + b, jz = iz + c;
          if (jx < 0 || jy < 0 || jz < 0 || jx >= this.cNx || jy >= this.cNy || jz >= this.cNz) continue;
          for (let j = this.cHead[(jx * this.cNy + jy) * this.cNz + jz]; j !== -1; j = this.cNext[j]) {
            if (j === i || depth[j] < 0 || depth[j] >= d || s[j * STRIDE + 16] !== 2 || this._holds(i, j)) continue;
            const fx = x - p3[j * 3], fy = y - p3[j * 3 + 1], fz = z - p3[j * 3 + 2], reach = this._link(i, j) * P.gripReach;
            if (fy > P.holdBelow * reach) continue;
            if (fx * fx + fy * fy + fz * fz < reach * reach && load[j] < bl) { bl = load[j]; best = j; }
          }
        }
        if (best >= 0) s[o + 18 + g] = best;
      }
    }
  }
  // the gust strength at time t: smooth steps between random levels in [-0.25, 1] (the wind blows mostly one way)
  _gust(t) {
    const T = this.P.gustPeriod, u = t / T, k = Math.floor(u), f = u - k, e = f * f * (3 - 2 * f);
    const a = hash01(k * 7919 + this.seed), b = hash01((k + 1) * 7919 + this.seed);
    return -0.25 + 1.25 * (a + (b - a) * e);
  }

  // ---------------------------------------------------------------- CT52.A2: move commands
  _movesDone() { let n = 0; for (let k = 0; k < this.moves.length; k++) if (this.moves[k] <= this.step) n++; return n; }
  /** where the queen is heading now (station A or B) */
  stationNow() { return (this._movesDone() & 1) ? this.stationB : this.station; }
  /** tell the queen to move to the other station, starting at the next step. Only once she holds a station. Later
   *  events and the checkpoints after now are discarded (they belong to a history that no longer happens). */
  requestMove() {
    if (!this.P.hover || this.state[16] !== 3) return false;
    const at = this.step + 1;
    this.moves = this.moves.filter(m => m < at); this.moves.push(at);
    for (const k of [...this.checkpoints.keys()]) if (k > this.step) this.checkpoints.delete(k);
    return true;
  }
  /** forget every move (Reset) */
  clearMoves() { this.moves = []; for (const k of [...this.checkpoints.keys()]) if (k > 0) this.checkpoints.delete(k); }

  // ---------------------------------------------------------------- checkpoints / seeking
  _saveCheckpoint() {
    if (this.step % CHECKPOINT_EVERY === 0 && !this.checkpoints.has(this.step))
      this.checkpoints.set(this.step, { state: this.state.slice(), field: this.field.slice(), qfield: this.qfield ? this.qfield.slice() : null, rng: this.rng.s,
                                        surface: this.surface ? this.surface.slice() : null,
                                        env: this.env ? Object.assign({}, this.env) : null });   // C7: the envelope in force
  }
  seek(target) {
    target = Math.max(0, Math.floor(target));
    if (target < this.step) {
      let ck = Math.floor(target / CHECKPOINT_EVERY) * CHECKPOINT_EVERY;
      while (!this.checkpoints.has(ck)) ck -= CHECKPOINT_EVERY;
      const c = this.checkpoints.get(ck);
      this.state.set(c.state); this.field.set(c.field); if (c.qfield) this.qfield.set(c.qfield); this.rng.s = c.rng; this.step = ck;
      if (c.surface) { if (!this.surface) this.surface = new Uint8Array(this.count); this.surface.set(c.surface); }
      else if (this.surface) this.surface.fill(0);
      this.env = c.env ? Object.assign({}, c.env) : null;
      this._rebuild();
    }
    while (this.step < target) this._stepOnce();
  }
  reset() { this.seek(0); }

  census() {                            // options 1-4: [milling, attracted, settled, fanning]
    const c = [0, 0, 0, 0], s = this.state;   // option 5 (CT52): [milling, attracted, in the ball incl. the queen, scenting in the ball]
    if (this.P.hover) {
      for (let i = 0; i < this.count; i++) { const m = s[i * STRIDE + 16];
        if (m === 3) { c[2]++; if (s[i * STRIDE + 13] === 1) c[3]++; } else if (m < 2) c[m]++; }
      return c;
    }
    for (let i = 0; i < this.count; i++) { const m = s[i * STRIDE + 16]; c[m]++; if (m === 2 && s[i * STRIDE + 13] === 1 && this.surface && this.surface[i]) c[3]++; }
    return c;
  }
  /** CT52 (option 5): the flying ball: bees in it, centroid, equivalent diameter (ft) */
  ballShape() {
    const B = this.ball; if (!B) return null;
    return { n: B.n, cx: B.cx, cy: B.cy, cz: B.cz, diameter: 2 * B.rad, queenHolding: this.state[16] === 3, station: this.stationNow(), moves: this._movesDone() };
  }
  /** size of the cluster as it stands: length below the branch, greatest width, centroid */
  clusterShape() {
    const s = this.state, P = this.P, C = this.cStats;
    if (!C.n) return { n: 0, length: 0, width: 0, cx: P.siteX, cy: P.attachY, cz: P.siteZ, volume: 0 };
    return { n: C.n, length: C.length, width: 2 * C.halfWidth, cx: C.cx, cy: C.cy, cz: C.cz,
             volume: (C.n / this.count) * this.expectedVolume, load: this.loadStats };
  }
  hash() {
    const b = new Uint8Array(this.state.buffer);
    let h = 0x811c9dc5;
    for (let i = 0; i < b.length; i++) { h ^= b[i]; h = Math.imul(h, 0x01000193); }
    return (h >>> 0).toString(16).padStart(8, '0');
  }
}

const api = { Swarm, LABEL, STRIDE, DT, SUB, RELAX_EVERY, CHECKPOINT_EVERY, DEFAULTS, FT_PER_MM, CONDITIONS, SUPPORTS, OPTIONS, optionOf };
if (typeof window !== 'undefined') window.CT54Sim = api;
if (typeof module !== 'undefined') module.exports = api;
})();
