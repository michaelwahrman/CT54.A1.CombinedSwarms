#!/usr/bin/env python3
# =============================================================================
#  CT54.A1.CombinedSwarms  --  local server
#
#  * Serves the CT54.A1.CombinedSwarms browser simulation (three.js is vendored locally,
#    nothing is fetched from the internet).
#  * Receives every rendered frame from the browser and writes it to disk:
#        CT54.A1.CombinedSwarms_frames/CT54.A1.CombinedSwarms_frame_000000.png ...
#  * On "Finish & Make Movie" it runs ffmpeg to build
#        CT54.A1.CombinedSwarms_movies/CT54.A1.CombinedSwarms_movie_<seed>_<timestamp>.mp4
#    verifies the movie, and then DELETES the individual frames.
#
#  Usage:  python CT54.A1.CombinedSwarms_server.py [--port 8739] [--no-browser]
#  Requires Python 3.8+ (standard library only) and ffmpeg for the movie step.
# =============================================================================

import argparse
import datetime
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import webbrowser
from http import HTTPStatus
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

LABEL = "CT54.A1.CombinedSwarms"
ROOT = os.path.dirname(os.path.abspath(__file__))
FRAMES_DIR = os.path.join(ROOT, f"{LABEL}_frames")
MOVIES_DIR = os.path.join(ROOT, f"{LABEL}_movies")
FRAME_PATTERN = f"{LABEL}_frame_%06d.png"
FRAME_RE = re.compile(rf"^{re.escape(LABEL)}_frame_(\d{{6}})\.png$")
MAX_FRAME_BYTES = 64 * 1024 * 1024

_lock = threading.Lock()


def log(msg):
    print(f"[{LABEL}] {msg}", flush=True)


def find_ffmpeg():
    """ffmpeg on PATH, or a copy dropped next to this script, or imageio-ffmpeg."""
    for name in (f"{LABEL}_ffmpeg.exe", f"{LABEL}_ffmpeg", "ffmpeg.exe", "ffmpeg"):
        p = os.path.join(ROOT, name)
        if os.path.isfile(p):
            return p
    p = shutil.which("ffmpeg")
    if p:
        return p
    try:
        import imageio_ffmpeg  # type: ignore
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        return None


def list_frames():
    if not os.path.isdir(FRAMES_DIR):
        return []
    return sorted(f for f in os.listdir(FRAMES_DIR) if FRAME_RE.match(f))


def clear_frames():
    n = 0
    for f in list_frames():
        try:
            os.remove(os.path.join(FRAMES_DIR, f))
            n += 1
        except OSError:
            pass
    try:
        os.rmdir(FRAMES_DIR)
    except OSError:
        pass
    return n


def make_movie(fps, meta):
    ffmpeg = find_ffmpeg()
    frames = list_frames()
    if not frames:
        return {"ok": False, "error": "No frames were recorded."}
    # frames must be contiguous from 0 for the image2 demuxer
    for i, f in enumerate(frames):
        if int(FRAME_RE.match(f).group(1)) != i:
            return {"ok": False, "error": f"Frame sequence has a gap at {i}; frames kept in {FRAMES_DIR}"}
    if not ffmpeg:
        return {"ok": False,
                "error": "ffmpeg was not found. Install it (Windows: 'winget install ffmpeg', "
                         "macOS: 'brew install ffmpeg', Linux: 'sudo apt install ffmpeg') or place "
                         f"ffmpeg next to {LABEL}_server.py, then press Finish again. "
                         f"{len(frames)} frames are kept in {FRAMES_DIR}."}
    os.makedirs(MOVIES_DIR, exist_ok=True)
    stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    seed = re.sub(r"[^0-9A-Za-z_-]", "", str(meta.get("seed", "x")))[:32]
    base = f"{LABEL}_movie_seed{seed}_{stamp}"
    out = os.path.join(MOVIES_DIR, base + ".mp4")
    cmd = [ffmpeg, "-y", "-loglevel", "error",
           "-framerate", str(fps),
           "-i", os.path.join(FRAMES_DIR, FRAME_PATTERN),
           "-c:v", "libx264", "-preset", "medium", "-crf", "16",
           "-pix_fmt", "yuv420p",
           "-vf", "pad=ceil(iw/2)*2:ceil(ih/2)*2",
           "-movflags", "+faststart",
           "-metadata", f"title={LABEL}",
           "-metadata", f"comment={LABEL} seed={meta.get('seed')} bees={meta.get('bees')}",
           out]
    log("encoding: " + " ".join(cmd))
    try:
        r = subprocess.run(cmd, capture_output=True, text=True)
    except Exception as e:  # noqa
        return {"ok": False, "error": f"ffmpeg failed to start: {e}. Frames kept."}
    if r.returncode != 0 or not os.path.isfile(out) or os.path.getsize(out) == 0:
        return {"ok": False, "error": "ffmpeg error (frames kept): " + (r.stderr or "")[-1500:]}

    # write a small sidecar describing the run
    info = dict(meta)
    info.update({"label": LABEL, "frames": len(frames), "fps": fps, "movie": os.path.basename(out),
                 "created": stamp})
    with open(os.path.join(MOVIES_DIR, base + "_info.json"), "w") as fh:
        json.dump(info, fh, indent=2)

    # movie verified -> delete the individual frames
    deleted = clear_frames()
    log(f"movie written: {out}  ({len(frames)} frames, {deleted} frame files deleted)")
    return {"ok": True, "movie": f"{LABEL}_movies/{os.path.basename(out)}",
            "frames": len(frames), "deleted": deleted, "path": out}


class Handler(SimpleHTTPRequestHandler):
    # explicit MIME types: Windows registries sometimes map .js to text/plain,
    # which breaks ES-module loading.
    extensions_map = {
        "": "application/octet-stream",
        ".html": "text/html; charset=utf-8",
        ".js": "text/javascript; charset=utf-8",
        ".mjs": "text/javascript; charset=utf-8",
        ".css": "text/css; charset=utf-8",
        ".json": "application/json",
        ".png": "image/png",
        ".webp": "image/webp",
        ".woff2": "font/woff2",
        ".mp4": "video/mp4",
        ".txt": "text/plain; charset=utf-8",
    }

    def __init__(self, *a, **kw):
        super().__init__(*a, directory=ROOT, **kw)

    def log_message(self, fmt, *args):
        if "/api/frame" not in (self.path or ""):
            sys.stderr.write(f"[{LABEL}] " + (fmt % args) + "\n")

    def end_headers(self):
        self.send_header("Cache-Control", "no-store")
        super().end_headers()

    def _json(self, obj, code=200):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _body(self):
        n = int(self.headers.get("Content-Length", "0"))
        if n > MAX_FRAME_BYTES:
            raise ValueError("body too large")
        return self.rfile.read(n)

    # ---- GET: static files (+ Range support for the movie player) ----
    def do_GET(self):
        u = urlparse(self.path)
        if u.path == "/":
            self.send_response(302)
            self.send_header("Location", "/index.html")
            self.end_headers()
            return
        if u.path == "/api/status":
            return self._json({"ok": True, "label": LABEL, "ffmpeg": bool(find_ffmpeg()),
                               "frames_on_disk": len(list_frames())})
        if u.path.endswith(".mp4") and "Range" in self.headers:
            return self._range_get(u.path)
        return super().do_GET()

    def _range_get(self, urlpath):
        path = self.translate_path(urlpath)
        if not os.path.isfile(path):
            return self.send_error(404)
        size = os.path.getsize(path)
        m = re.match(r"bytes=(\d*)-(\d*)", self.headers["Range"])
        start = int(m.group(1)) if m and m.group(1) else 0
        end = int(m.group(2)) if m and m.group(2) else size - 1
        end = min(end, size - 1)
        if start > end:
            self.send_response(416)
            self.send_header("Content-Range", f"bytes */{size}")
            self.end_headers()
            return
        self.send_response(206)
        self.send_header("Content-Type", "video/mp4")
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
        self.send_header("Content-Length", str(end - start + 1))
        self.end_headers()
        with open(path, "rb") as fh:
            fh.seek(start)
            left = end - start + 1
            while left > 0:
                chunk = fh.read(min(1 << 20, left))
                if not chunk:
                    break
                try:
                    self.wfile.write(chunk)
                except (BrokenPipeError, ConnectionResetError):
                    return
                left -= len(chunk)

    # ---- POST: frame upload / new take / finish ----
    def do_POST(self):
        u = urlparse(self.path)
        q = parse_qs(u.query)
        try:
            if u.path == "/api/frame":
                idx = int(q.get("i", ["-1"])[0])
                if not (0 <= idx <= 999999):
                    return self._json({"ok": False, "error": "bad index"}, 400)
                data = self._body()
                if not data.startswith(b"\x89PNG"):
                    return self._json({"ok": False, "error": "not a PNG"}, 400)
                os.makedirs(FRAMES_DIR, exist_ok=True)
                name = FRAME_PATTERN % idx
                tmp = os.path.join(FRAMES_DIR, name + ".part")
                with open(tmp, "wb") as fh:
                    fh.write(data)
                os.replace(tmp, os.path.join(FRAMES_DIR, name))
                return self._json({"ok": True, "i": idx})

            if u.path == "/api/new_take":
                self._body()
                with _lock:
                    n = clear_frames()
                log(f"new take: cleared {n} old frame(s)")
                return self._json({"ok": True, "cleared": n})

            if u.path == "/api/finish":
                meta = json.loads(self._body() or b"{}")
                fps = int(meta.get("fps", 30))
                fps = max(1, min(fps, 240))
                with _lock:
                    res = make_movie(fps, meta)
                return self._json(res, 200 if res.get("ok") else 500)

            if u.path == "/api/shutdown":
                self._json({"ok": True})
                threading.Thread(target=self.server.shutdown, daemon=True).start()
                return
        except Exception as e:  # noqa
            return self._json({"ok": False, "error": str(e)}, 500)
        self.send_error(404)


def main():
    ap = argparse.ArgumentParser(description=f"{LABEL} local server")
    ap.add_argument("--port", type=int, default=8739)
    ap.add_argument("--no-browser", action="store_true")
    args = ap.parse_args()

    httpd = ThreadingHTTPServer(("127.0.0.1", args.port), Handler)
    url = f"http://127.0.0.1:{args.port}/index.html"
    log(f"serving {ROOT}")
    log(f"open {url}")
    log("ffmpeg: " + (find_ffmpeg() or "NOT FOUND (needed only for the movie step)"))
    log("press Ctrl+C to stop")
    if not args.no_browser:
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    log("stopped")


if __name__ == "__main__":
    main()
