#!/bin/sh
# CT54.A1.CombinedSwarms -- macOS / Linux / WSL launcher: starts the local frame server and opens the browser
cd "$(dirname "$0")"
exec python3 CT54.A1.CombinedSwarms_server.py "$@"
