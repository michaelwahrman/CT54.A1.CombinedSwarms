// =============================================================================
//  CT54.A1.CombinedSwarms  --  rendering, camera, controls, frame capture, movie
//  three.js comes from the local CT54.A1.CombinedSwarms_lib folder (no internet).
//  CT54.A1: CT39.C8 and CT52.A2 COMBINED. One page, five options, chosen on the startup card, the Option selector or
//       the keys 1-5; a banner over the picture always says which option is running. Options 1-4 are the CT39.C8
//       hanging cluster (beard / compact / broad / swaying); option 5 is the CT52.A2 hovering ball (Move queen G, Follow
//       sight/scent, the measuring pole). Option 5 is marked everywhere as OBSERVED BUT NOT IN THE LITERATURE.
//  Controls / recording / movie pipeline are carried over from CT39.A1.Swarm.
//  C8:  a 'how to use' card after the title (what you will see, the other shapes, the chains, the camera); it
//       waits for Start; the ? Help button / ? key shows it again.
//  C7:  THE SHELL AND THE CONDITIONS. The settled bees form a smooth, dense outer layer (the chains are inside it;
//       N shows them). A Weather selector (warm & calm / cool / windy) and a 'Hangs from' selector (a thin vine stem
//       slung under the beam / the beam's flat underside) set the cluster's shape - see the sim and SCIENCE.md 6.7.
//       The vine stem is drawn when the swarm hangs from it. Shell bees face up. The opening is the title art alone,
//       with one line pointing to the About file (CT54: replaced by CT54.A1.CombinedSwarms_AUDIT.html). index.html is the
//       page (harness v3).
//  C6:  the opening card is replaced by four captions laid over the empty dawn scene (no bees yet); after the last
//       one the bees appear, their sound rises and the simulation begins.
//  C5:  camera help in the lower-left of the picture; T aims at the queen / cluster centre / cluster tip; right- or
//       shift-drag pans; double-click re-centres; orbit goes further below; the close-up comes as close as it can
//       while keeping the whole settled swarm in its window.
//  C4:  the opening title is the user's 'swarm 3.webp' (CT39.artwork), copied as CT54.A1.CombinedSwarms_title.webp.
//  C3:  shadows are OFF at the start (Q / the Shadows button turns them on; ?shadows=1 starts with them on).
//  C2:  the sea's waves are computed per pixel (no tiled texture, so no repeating pattern far out); the opening card
//       is rewritten in plain language (scent model, chains gripping the wood).
//  C1:  NEW SETTING - the arch and the ruins are gone. An OLD WOODEN ARBOR (pergola), in bad shape, stands at the
//       brink of a high place above the Adriatic; the queen and her swarm hang from the underside of its sagging front
//       beam. The summit breaks off in cliffs a few yards beyond it, toward the sea and the dawn. Everything else as B3.
//  B3:  the Adriatic below to the east; no inlays; only the arch and broken runs of the crepidoma remain, all
//       severely eroded and dull; only Venus and Jupiter (and the moon) in the sky.
//  B1:  NEW WORLD - an abandoned mountain-top sanctuary above the Adriatic just before dawn: stone altar, temple
//       ruins and an arch whose underside the swarm hangs from; esoteric metal symbols inlaid in the stone (user's
//       artwork); natural light only (twilight sky, the glow of the east, moonlight), the sky brightening through
//       the run. Metal bees: narrow black / broad gold stripes, five red eyes, crystal wings, black outline.
//       Look / Shadows / Reflections / Outline / Crystal switches (all on by default). Title 'swarm 9' 15 s.
//  A12: LOOK button/W - wireframe <-> shaded; SHADOWS button/Q; OUTLINE (inverted-hull shader) on shaded bees, U;
//       fewer bees by default (4,000) with a bee-count selector and an FPS readout; JUNK J - none / some / lots
//       (lots adds sofas, mattresses, a shopping cart, appliances, a bathtub, crates, cones, tyres).
//  A11: WIREFRAME again (unlit, no shadows, low-poly bees -> far fewer draw passes and pixels per frame); bees striped
//       black and red; the story card holds 32 s; HUD status type larger, in metallic gold; close-up window further back.
//  A10: shaded scene with shadows - an empty junk-yard lot, one streetlight, a sagging power line the swarm hangs
//       from; IRON BEES (body, head, two self-lit eyes, two outlined wings); strands shown by CONTRAST (N), not
//       colour; a second, small CLOSE-UP window on the forming cluster (P); opening title -> Zoltar-style card -> scene.
//  A9:  mechanical metal UI (riveted plates, steel keys, odometer drums; fonts bundled).
// =============================================================================
(async function () {
'use strict';
const THREE = window.THREE;
const { Swarm, LABEL, STRIDE, DT, CHECKPOINT_EVERY, FT_PER_MM, OPTIONS, optionOf } = window.CT54Sim;

// ---------------------------------------------------------------- parameters
const qs = new URLSearchParams(location.search);
const SEED = parseInt(qs.get('seed') ?? '3906', 10) >>> 0;
// CT54: the option (1-5). ?option=N (or a name: beard, compact, broad, windy, hover); an old ?weather= still works.
const OPTION = qs.has('option') ? optionOf(qs.get('option')) : qs.has('weather') ? optionOf(qs.get('weather')) : 1;
const OPT = OPTIONS[OPTION], HOVER = OPT.hover;
const BEES = Math.max(50, Math.min(30000, parseInt(qs.get('bees') ?? (HOVER ? '5000' : '7500'), 10)));   // CT54: 7,500 for 1-4 (CT39), 5,000 for 5 (CT52)
const W = parseInt(qs.get('w') ?? '1280', 10);
const H = parseInt(qs.get('h') ?? '720', 10);
const simOpts = {};
if (qs.has('temp')) simOpts.ambientC = parseFloat(qs.get('temp'));                    // air temperature, C -> packing
if (qs.has('fan')) simOpts.fanFraction = Math.max(0, Math.min(1, parseFloat(qs.get('fan'))));   // share of surface bees that fan
if (qs.has('threshold')) simOpts.threshold = Math.max(1e-5, parseFloat(qs.get('threshold')));    // scent level that attracts a bee
// C7: the conditions (Weather) and what the cluster hangs from (Support); ?shell=0 turns the shell and envelope off
simOpts.option = OPTION;
if (!HOVER) simOpts.support = ['branch', 'beam'].includes(qs.get('support')) ? qs.get('support') : 'branch';
if (HOVER && qs.get('follow') === 'scent') simOpts.follow = 'scent';                   // CT52.A2: how ball bees keep with the queen
if (HOVER && qs.has('movespeed')) simOpts.moveSpeed = Math.max(0.1, Math.min(8, parseFloat(qs.get('movespeed'))));   // ft/s
if (qs.get('shell') === '0') simOpts.shell = 0;
if (qs.has('climb')) simOpts.climbReach = Math.max(0.5, Math.min(4, parseFloat(qs.get('climb'))));   // B1: how far below free stone a bee can step up (body lengths)
const FPS = 30;                                         // movie frame rate
const STEPS_PER_FRAME_1X = Math.round(1 / (DT * FPS));  // 4 sim steps per film frame at x1
const SPEEDS = [1, 2, 4, 8, 16, 32, 64];                // sim steps per film frame
const MAX_INFLIGHT = 4;                                 // concurrent frame uploads
const MIN_BEE_PX = 3.0;                                 // "visible size": a worker is drawn at least this many pixels long (A10: body length)
const CAM_POS = new THREE.Vector3(0, 6.0, 0);           // POV: 6 ft above the ground

// ---------------------------------------------------------------- state
const sim = new Swarm(SEED, BEES, simOpts);
const P = sim.P;
const SITE = new THREE.Vector3(P.siteX, P.siteY, P.siteZ);      // cluster centroid (computed by the sim)
let CL = HOVER ? { n: 0, length: 0, width: 0, cx: P.siteX, cy: P.siteY, cz: P.siteZ, load: null } : sim.clusterShape();   // A6: the cluster as it has formed (updated every frame)
const ATTACH_Y = P.attachY;
let speedIdx = SPEEDS.indexOf(STEPS_PER_FRAME_1X);
let direction = +1;          // +1 forward, -1 backward, 0 paused
let recording = true, serverOk = false, finished = false;
let filmFrame = 0, inflight = 0, uploadErrors = 0;
let autoZoom = true, exaggerate = true, casteColours = false, showHud = true, showScent = false;
let strandMode = ['contrast', 'chains', 'off'].includes(qs.get('strands')) ? qs.get('strands') : 'off';   // A10 (N); C7: off by default (the smooth shell)
let showPip = qs.get('pip') !== '0';            // A10: close-up window (P)
let introActive = false, beesHidden = false;   // C6: no bees in the scene while the captions play
let showLoad = false, showLinks = false;   // A7: K shades bees by the load they hold up; G draws their grips
let displayStep = 0;         // the step being shown (differs from sim.step only while rewinding)

// ---------------------------------------------------------------- renderer (A10: shaded, with shadows)
const canvas = document.getElementById('view');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, preserveDrawingBuffer: true });
renderer.setPixelRatio(1);
renderer.setSize(W, H, false);              // fixed render/movie size; CSS scales it to the window
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.NoToneMapping;
renderer.shadowMap.enabled = true;          // A12: shadows can be switched on (shaded look); updated by hand per view
renderer.shadowMap.type = THREE.PCFShadowMap;
renderer.shadowMap.autoUpdate = false;
renderer.autoClear = false;
// A12: the two looks. Objects only drawn in one of them are listed here; applyLook() switches.
let shaded = qs.get('look') !== 'wire', shadowsOn = qs.get('shadows') === '1', outlineOn = qs.get('outline') === '1';   // C3: shadows off by default; B2: outline off by default
const SHADED_ONLY = [], WIRE_ONLY = [], GROUNDS = [];   // GROUNDS: terrain meshes that swap to a wire material

// ---------------------------------------------------------------- B1: an abandoned sacred site above the Adriatic, before dawn
// A mountain-top shrine: a stone altar, the platform and a wall fragment of a temple (B2: no columns), and a free-standing arch (its
// gateway) under which the swarm hangs. The sun is still below the horizon, east over the sea; the sky lightens
// through the run (dawn progress follows simulation time, so a recorded movie always looks the same) and a waning
// crescent moon hangs in the east above the glow. All light is natural: sky light (hemisphere), the glow of the
// eastern sky (a low, warm, soft shadow-casting light - from the default view it comes from behind the arch, so
// the swarm is diffusely lit from the sky and backlit by the dawn) and faint moonlight. Everything is generated here,
// except the inlaid symbols (CT54.A1.CombinedSwarms_symbols.js, from the user's artwork).
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(60, W / H, 0.3, 60000);
let groundAt = null;                                  // CT52.A2: ground height (for the foot of the pole)
camera.position.copy(CAM_POS);
camera.lookAt(SITE);
const rnd = (() => { let a = 20261006; return () => { a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; })();
const grey = (v) => new THREE.Color(v, v, v);
let envTex = null;                                    // the sky, pre-filtered for reflections (rebuilt as dawn brightens)
const METALS = [];                                    // materials that reflect the sky (Reflections button)
const std = (v, rough = 0.85, metal = 0) => { const m = new THREE.MeshStandardMaterial({ color: typeof v === 'number' ? grey(v) : v, roughness: rough, metalness: metal });
  if (metal > 0) METALS.push(m); return m; };
function shadowy(o, cast = true, recv = true) { o.traverse(m => { if (m.isMesh) { m.castShadow = cast; m.receiveShadow = recv; } }); return o; }
function canvasTex(size, draw, repeat) {
  const c = document.createElement('canvas'); c.width = c.height = size; draw(c.getContext('2d'), size);
  const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; if (repeat) t.repeat.set(repeat, repeat);
  t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8; return t;
}
// directions: east = where the sun will rise (over the sea), a little left of straight behind the arbor
const EAST = new THREE.Vector3(-0.42, 0, -1).normalize();
const DAWN_S = Math.max(10, parseFloat(qs.get('dawn') ?? '300'));       // sim seconds from deep twilight to just-before-sunrise
const sunDir = new THREE.Vector3(), moonDir = new THREE.Vector3();
// B2: the sky over Monte Gargano (41.7 N, on the Adriatic) on an autumn morning, local sidereal time 7.0 h, when the
// sun is ~9 deg below the eastern horizon: alt/az worked out from right ascension and declination, then turned so
// that the sun's azimuth falls on EAST (the glow). Named objects: Betelgeuse, Rigel (with the rest of Orion), the
// Pleiades, Sirius, and the planets Venus, Jupiter and Mars; plus the waning crescent moon near Venus.
const SKY_LAT = THREE.MathUtils.degToRad(41.7), SKY_LST = 7.0;
function skyDir(raH, decD, out = new THREE.Vector3()) {
  const H = THREE.MathUtils.degToRad((SKY_LST - raH) * 15), d = THREE.MathUtils.degToRad(decD);
  const alt = Math.asin(Math.sin(SKY_LAT) * Math.sin(d) + Math.cos(SKY_LAT) * Math.cos(d) * Math.cos(H));
  const az = Math.atan2(-Math.cos(d) * Math.sin(H), Math.sin(d) * Math.cos(SKY_LAT) - Math.cos(d) * Math.cos(H) * Math.sin(SKY_LAT));
  const SUN_AZ = THREE.MathUtils.degToRad(93.4), phi = -(az - SUN_AZ);           // compass azimuth -> the scene's EAST
  const hx = EAST.x * Math.cos(phi) + EAST.z * Math.sin(phi), hz = -EAST.x * Math.sin(phi) + EAST.z * Math.cos(phi);
  return out.set(hx * Math.cos(alt), Math.sin(alt), hz * Math.cos(alt)).normalize();
}
skyDir(11.2, 6.5, moonDir);                                                       // the moon: ~24 deg up, just south of east
// ---- sky: twilight gradient, a warm glow in the east, stars that fade as the sky lightens
const skyUniforms = { uSun: { value: sunDir }, uDawn: { value: 0 }, uMoon: { value: moonDir } };
const SKY_VS = 'varying vec3 vd; void main(){ vd = normalize(position); vec4 p = projectionMatrix * modelViewMatrix * vec4(position,1.0); gl_Position = p.xyww; }';
const SKY_FS = `
  uniform vec3 uSun; uniform float uDawn; uniform vec3 uMoon; varying vec3 vd;
  float hash(vec3 p){ p = fract(p * 0.3183099 + 0.1); p *= 17.0; return fract(p.x * p.y * p.z * (p.x + p.y + p.z)); }
  void main(){
    vec3 d = normalize(vd); float h = d.y, dw = uDawn;
    vec3 zen = mix(vec3(0.010, 0.016, 0.045), vec3(0.10, 0.17, 0.34), dw);
    vec3 hor = mix(vec3(0.045, 0.055, 0.10), vec3(0.42, 0.40, 0.46), dw);
    vec3 c = mix(hor, zen, pow(clamp(h, 0.0, 1.0), 0.45));
    vec3 sh = normalize(vec3(uSun.x, 0.0, uSun.z));
    float toward = max(dot(normalize(vec3(d.x, 0.0, d.z)), sh), 0.0);
    float low = exp(-max(h, 0.0) * 7.0);
    vec3 glow = mix(vec3(0.85, 0.32, 0.10), vec3(1.0, 0.62, 0.30), dw) * (0.12 + 1.6 * dw * dw);
    c += glow * pow(toward, 3.0) * low;                                     // the eastern glow along the horizon
    c += vec3(0.50, 0.32, 0.42) * 0.25 * dw * pow(toward, 1.5) * exp(-max(h, 0.0) * 2.5);   // rose band above it
    if (h < 0.0) c = mix(c, mix(vec3(0.02, 0.03, 0.06), vec3(0.16, 0.18, 0.24), dw), clamp(-h * 6.0, 0.0, 1.0));
    // stars, fading out as the sky brightens
    vec3 q = floor(d * 420.0); float st = hash(q);
    float star = 0.0;   // B3: no background stars (B2: a faint field)
    c += vec3(0.85, 0.9, 1.0) * star * (0.18 + 0.35 * hash(q + 7.0));
    // earthshine haze around the moon
    float m = max(dot(d, uMoon), 0.0); c += vec3(0.45, 0.5, 0.6) * pow(m, 900.0) * 0.6 + vec3(0.05, 0.06, 0.09) * pow(m, 60.0) * (1.0 - 0.6 * dw);
    gl_FragColor = vec4(c, 1.0);
    #include <tonemapping_fragment>
    #include <colorspace_fragment>
  }`;
const skyMat = new THREE.ShaderMaterial({ side: THREE.BackSide, depthWrite: false, uniforms: skyUniforms, vertexShader: SKY_VS, fragmentShader: SKY_FS });
const sky = new THREE.Mesh(new THREE.SphereGeometry(50000, 48, 24), skyMat);
sky.frustumCulled = false; sky.renderOrder = -10; scene.add(sky);
// the waning crescent moon (lit limb toward the sun below the horizon), with a faint ashen earthshine disc
const moon = (() => {
  const tex = canvasTex(256, (c, n) => {
    c.clearRect(0, 0, n, n); const r = n * 0.42, cx = n / 2, cy = n / 2;
    c.fillStyle = 'rgba(120,130,150,0.22)'; c.beginPath(); c.arc(cx, cy, r, 0, 7); c.fill();          // earthshine
    c.save(); c.beginPath(); c.arc(cx, cy, r, 0, 7); c.clip();
    c.fillStyle = '#f4efe2'; c.beginPath(); c.arc(cx, cy, r, 0, 7); c.fill();
    c.globalCompositeOperation = 'destination-out'; c.beginPath(); c.arc(cx - r * 0.42, cy - r * 0.32, r * 1.02, 0, 7); c.fill();
    c.restore();
  });
  const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false, fog: false, toneMapped: false }));
  sp.position.copy(moonDir).multiplyScalar(30000); sp.scale.set(650, 650, 1);
  sp.material.rotation = 0.6; sp.renderOrder = -9; scene.add(sp); return sp;
})();
// B2: stars and planets as small glowing discs on the sky (screen-sized, so they stay points at any zoom)
const SKY_OBJ = [];
{
  const glowTex = canvasTex(64, (c, n) => { const g = c.createRadialGradient(n / 2, n / 2, 0, n / 2, n / 2, n / 2);
    g.addColorStop(0, 'rgba(255,255,255,1)'); g.addColorStop(0.18, 'rgba(255,255,255,.85)'); g.addColorStop(0.4, 'rgba(255,255,255,.18)'); g.addColorStop(1, 'rgba(255,255,255,0)');
    c.fillStyle = g; c.fillRect(0, 0, n, n); });
  // name, RA (h), Dec (deg), size, colour, how long it survives the dawn (1 = to the end)
  // B3: only two points of light are left in the sky (with the moon): Venus, the morning star, low over the sea,
  // and Jupiter high in the south-east
  const LIST = [
    ['Venus', 11.9, 1.5, 0.032, 0xfffbec, 1.0], ['Jupiter', 8.6, 18.5, 0.022, 0xfff1d6, 0.75],
  ];
  for (const [name, ra, dec, size, col, last] of LIST) {
    const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTex, color: col, transparent: true, depthWrite: false, fog: false, toneMapped: false,
      sizeAttenuation: false, blending: THREE.AdditiveBlending }));
    skyDir(ra, dec, sp.position).multiplyScalar(40000); sp.scale.set(size * 2.1, size * 2.1, 1); sp.renderOrder = -8; sp.userData = { name, last, size };   // (sizes in the list are relative; x2.1 = on-screen)
    scene.add(sp); SKY_OBJ.push(sp);
  }
}
function updateSkyObjects(d) {
  for (const sp of SKY_OBJ) { const f = Math.max(0, 1 - Math.pow(d / Math.max(0.05, sp.userData.last), 2) * 0.92);
    sp.material.opacity = f; sp.visible = f > 0.02; }
}
// ---- lights
const hemi = new THREE.HemisphereLight(0x5a6c96, 0x2a2622, 0.4);
scene.add(hemi);
const sun = new THREE.DirectionalLight(0xffb27a, 0.6);           // the glow of the eastern sky (named 'sun' for the shadow switch)
sun.castShadow = true;
const SHADOW = Math.max(512, Math.min(8192, parseInt(qs.get('shadow') ?? '4096', 10)));
sun.shadow.mapSize.set(SHADOW, SHADOW);
Object.assign(sun.shadow.camera, { left: -40, right: 40, top: 40, bottom: -40, near: 10, far: 300 });
sun.shadow.bias = -0.0004; sun.shadow.normalBias = 0.02; sun.shadow.radius = 4;   // soft: the light comes from a broad patch of sky
scene.add(sun, sun.target);
const moonLight = new THREE.DirectionalLight(0x9fb4e0, 0.25);
moonLight.position.copy(SITE).addScaledVector(moonDir, 150); moonLight.target.position.copy(SITE);
scene.add(moonLight, moonLight.target);
scene.fog = new THREE.FogExp2(0x1a2236, 0.0016);
// reflections: the sky (only) pre-filtered into an environment map; rebuilt when dawn has moved on a little
const envScene = new THREE.Scene();
envScene.add(new THREE.Mesh(new THREE.SphereGeometry(100, 48, 24), new THREE.ShaderMaterial({ side: THREE.BackSide, uniforms: skyUniforms,
  vertexShader: 'varying vec3 vd; void main(){ vd = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }',
  fragmentShader: SKY_FS.replace('#include <tonemapping_fragment>', '').replace('#include <colorspace_fragment>', '') })));
{ const ground = new THREE.Mesh(new THREE.CircleGeometry(90, 32), new THREE.MeshBasicMaterial({ color: 0x2a2620 }));  // the dark land below
  ground.rotation.x = -Math.PI / 2; ground.position.y = -6; envScene.add(ground); }
const pmrem = new THREE.PMREMGenerator(renderer);
let envRT = null, envDawn = -1, reflectOn = qs.get('reflect') !== '0';
function applyReflections() { for (const m of METALS) { m.envMap = reflectOn ? envTex : null; m.needsUpdate = true; } }
function rebuildEnv(d) {
  if (envRT && Math.abs(d - envDawn) < 0.03) return;
  envDawn = d; const old = envRT; envRT = pmrem.fromScene(envScene, 0, 0.1, 200); envTex = envRT.texture;
  if (old) old.dispose(); applyReflections();
}
// dawn: 0 = deep blue twilight (sun ~12 deg below the horizon) ... 1 = the moment before sunrise (~1 deg below)
let dawn = -1;
function updateDawn(tSim) {
  const d = Math.min(1, Math.max(0, tSim / DAWN_S));
  if (Math.abs(d - dawn) < 1e-4 && envRT) return;
  dawn = d;
  const el = THREE.MathUtils.degToRad(-12 + 11 * d);
  sunDir.set(EAST.x * Math.cos(el), Math.sin(el), EAST.z * Math.cos(el)).normalize();
  skyUniforms.uDawn.value = d;
  // the glow light: from a few degrees ABOVE the horizon where the bright sky is (not from the sun itself)
  const ge = THREE.MathUtils.degToRad(5 + 3 * d);
  sun.position.set(SITE.x + EAST.x * Math.cos(ge) * 160, SITE.y + Math.sin(ge) * 160, SITE.z + EAST.z * Math.cos(ge) * 160); sun.target.position.copy(SITE);
  sun.intensity = 0.25 + 2.1 * d * d; sun.color.setRGB(1.0, 0.55 + 0.2 * d, 0.32 + 0.22 * d);
  hemi.intensity = 0.6 + 1.3 * d; hemi.color.setRGB(0.32 + 0.3 * d, 0.40 + 0.3 * d, 0.62 + 0.18 * d);
  hemi.groundColor.setRGB(0.10 + 0.12 * d, 0.09 + 0.10 * d, 0.08 + 0.08 * d);
  moonLight.intensity = 0.3 * (1 - 0.7 * d);
  scene.fog.color.setRGB(0.08 + 0.26 * d, 0.10 + 0.24 * d, 0.17 + 0.25 * d);
  moon.material.opacity = 1 - 0.45 * d;
  updateSkyObjects(d);
  rebuildEnv(d);
}
// ---- the mountain top: a plateau of thin turf and rock, falling away on every side; ridges to the west, north and
// south; the sea far below to the east
const stoneTex = canvasTex(512, (c, n) => {                        // weathered limestone: warm grey, pitted, faint lichen
  c.fillStyle = '#aaa08d'; c.fillRect(0, 0, n, n);
  const blot = (x, y, r, col, a) => { const g = c.createRadialGradient(x, y, 0, x, y, r); g.addColorStop(0, `rgba(${col},${a})`); g.addColorStop(1, `rgba(${col},0)`); c.fillStyle = g;
    for (const ox of [-n, 0, n]) for (const oy of [-n, 0, n]) c.fillRect(x - r + ox, y - r + oy, 2 * r, 2 * r); };
  for (let k = 0; k < 420; k++) { const v = 130 + rnd() * 60 | 0; blot(rnd() * n, rnd() * n, 6 + rnd() * 40, `${v},${v - 5},${v - 16}`, 0.22); }
  for (let k = 0; k < 60; k++) blot(rnd() * n, rnd() * n, 4 + rnd() * 16, '118,124,92', 0.18);            // lichen
  for (let k = 0; k < 9000; k++) { const v = 60 + rnd() * 150 | 0; c.fillStyle = `rgba(${v},${v},${v - 6},.28)`; c.fillRect(rnd() * n, rnd() * n, 1.3, 1.3); }
  for (let k = 0; k < 40; k++) { c.strokeStyle = `rgba(70,64,56,${0.15 + rnd() * 0.2})`; c.lineWidth = 0.6 + rnd(); c.beginPath();    // fine cracks
    let x = rnd() * n, y = rnd() * n; c.moveTo(x, y); for (let j = 0; j < 6; j++) { x += (rnd() - 0.5) * 40; y += (rnd() - 0.5) * 40; c.lineTo(x, y); } c.stroke(); }
});
const groundTex = canvasTex(512, (c, n) => {                       // short mountain turf, bare rock and scree
  c.fillStyle = '#4a4e38'; c.fillRect(0, 0, n, n);
  const blot = (x, y, r, col, a) => { const g = c.createRadialGradient(x, y, 0, x, y, r); g.addColorStop(0, `rgba(${col},${a})`); g.addColorStop(1, `rgba(${col},0)`); c.fillStyle = g;
    for (const ox of [-n, 0, n]) for (const oy of [-n, 0, n]) c.fillRect(x - r + ox, y - r + oy, 2 * r, 2 * r); };
  for (let k = 0; k < 260; k++) blot(rnd() * n, rnd() * n, 10 + rnd() * 45, rnd() < 0.5 ? '96,100,70' : '58,62,40', 0.25);
  for (let k = 0; k < 120; k++) blot(rnd() * n, rnd() * n, 4 + rnd() * 14, '150,145,128', 0.45);          // rock showing through
  for (let k = 0; k < 16000; k++) { const v = 40 + rnd() * 110 | 0; c.fillStyle = `rgba(${v},${v + 8},${v - 12},.35)`; c.fillRect(rnd() * n, rnd() * n, 1, 1.8); }
}, 90);
const stoneMat = new THREE.MeshStandardMaterial({ map: stoneTex, bumpMap: stoneTex, bumpScale: 1.2, roughness: 0.92, metalness: 0 });
// value noise / fbm (deterministic)
const NZ = (() => {
  const h = (x, y, z) => { let n = (x * 374761393 + y * 668265263 + z * 2147483647) | 0; n = Math.imul(n ^ (n >>> 13), 1274126177); return ((n ^ (n >>> 16)) >>> 0) / 4294967296; };
  const sm = (t) => t * t * (3 - 2 * t);
  const v = (x, y, z) => { const xi = Math.floor(x), yi = Math.floor(y), zi = Math.floor(z), xf = sm(x - xi), yf = sm(y - yi), zf = sm(z - zi);
    let r = 0; for (let a = 0; a < 2; a++) for (let b = 0; b < 2; b++) for (let c = 0; c < 2; c++)
      r += h(xi + a, yi + b, zi + c) * (a ? xf : 1 - xf) * (b ? yf : 1 - yf) * (c ? zf : 1 - zf); return r; };
  return { v, fbm: (x, y, z, o = 4) => { let s = 0, a = 0.5, f = 1; for (let i = 0; i < o; i++) { s += a * v(x * f, y * f, z * f); f *= 2.03; a *= 0.5; } return s / (1 - Math.pow(0.5, o)); } };
})();
const SM = THREE.MathUtils.smoothstep;
// C1: the summit is a polar mesh (fine near the arbor, coarse far away). 16 ft beyond the arbor, on the sea side,
// it breaks off at a BRINK and falls in steep cliffs toward the Adriatic ~1,400 ft below: from the arbor one looks
// out over the open sea. Steep ground is coloured as bare rock (vertex colours).
{
  const NA = 220, rings = [0];
  for (let r = 0.6; r < 1300; r *= 1.045) rings.push(r);
  const pos = [], uv = [], col = [], idx = [];
  const n2 = (x, z) => Math.sin(x * 0.013 + Math.sin(z * 0.009) * 2) * Math.cos(z * 0.011 - 0.7) + 0.5 * Math.sin(x * 0.041 + z * 0.033);
  const hAt = (x, z) => {
    const r = Math.hypot(x - SITE.x, z - SITE.z);
    let y = 0.6 * n2(x, z) * Math.min(1, r / 60);
    if (r > 180) y -= Math.pow((r - 180) / 60, 2) * 9;
    const e = r > 1 ? ((x - SITE.x) * EAST.x + (z - SITE.z) * EAST.z) / r : 0, sea = SM(e, 0.25, 0.7);
    const brink = 16 + 7 * NZ.fbm(Math.atan2(z - SITE.z, x - SITE.x) * 3 + 5, 0, 0, 3);      // a ragged edge
    if (r > brink) y -= sea * (Math.min(60, (r - brink) * 3.2) + Math.pow(Math.max(0, r - brink - 18) / 9, 2) * 9 + 30 * NZ.fbm(x * 0.05, 0, z * 0.05, 3) * SM(r - brink, 0, 20));
    if (r > 55) y -= Math.pow((r - 55) / 22, 2) * 14 * SM(e, 0.1, 0.5);
    if (r < 12) y *= r / 12;
    return Math.max(-1500, y);
  };
  for (let k = 0; k < rings.length; k++) for (let a = 0; a < NA; a++) {
    const th = a / NA * Math.PI * 2, x = SITE.x + Math.cos(th) * rings[k], z = SITE.z + Math.sin(th) * rings[k], y = hAt(x, z);
    pos.push(x - SITE.x, y, z - SITE.z); uv.push((x - SITE.x) / 2400 + 0.5, (z - SITE.z) / 2400 + 0.5);
    const d = 0.6, sl = Math.min(1, Math.hypot(hAt(x + d, z) - y, hAt(x, z + d) - y) / d / 1.2), rock = SM(sl, 0.35, 0.8);
    col.push(1 + rock * 0.55, 1 + rock * 0.45, 1 + rock * 0.55);                  // rock: lighter, greyer than turf
  }
  for (let k = 0; k < rings.length - 1; k++) for (let a = 0; a < NA; a++) {
    const i0 = k * NA + a, i1 = k * NA + (a + 1) % NA, j0 = i0 + NA, j1 = i1 + NA; idx.push(i0, i1, j0, i1, j1, j0);
  }
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
  g.setAttribute('color', new THREE.Float32BufferAttribute(col, 3)); g.setIndex(idx); g.computeVertexNormals();
  { const nm = g.attributes.normal; let flip = 0; for (let i = 0; i < nm.count; i += 97) if (nm.getY(i) < 0) flip++; if (flip > nm.count / 194) { idx.reverse(); g.setIndex(idx); g.computeVertexNormals(); } }
  const ground = new THREE.Mesh(g, new THREE.MeshStandardMaterial({ map: groundTex, roughness: 1, metalness: 0, vertexColors: true }));
  ground.position.set(SITE.x, 0, SITE.z); ground.receiveShadow = true; scene.add(ground);
  ground.userData.wire = new THREE.MeshBasicMaterial({ color: 0x3b4436, wireframe: true, fog: true }); ground.userData.solid = ground.material;
  GROUNDS.push(ground);
  groundAt = hAt;
}
// distant ridges (W, N, S) and the sea to the east
{
  const ridge = (rad, h0, h1, seg, col, skipEast) => {
    const pos = [], idx = [];
    for (let k = 0; k <= seg; k++) {
      const a = k / seg * Math.PI * 2, dx = Math.sin(a), dz = Math.cos(a);
      const east = Math.max(0, dx * EAST.x + dz * EAST.z);
      let h = h0 + (h1 - h0) * (0.5 + 0.5 * Math.sin(a * 7 + 1.3) * Math.cos(a * 3.1)) + (rnd() - 0.5) * h0 * 0.35;
      if (skipEast) { const k = Math.min(1, Math.pow(east, 1.5) * 1.6); h = h * (1 - k) - 2900 * k; }   // open to the sea in the east
      pos.push(SITE.x + dx * rad, -3000, SITE.z + dz * rad, SITE.x + dx * rad, h, SITE.z + dz * rad);
      if (k < seg) { const b = k * 2; idx.push(b, b + 2, b + 1, b + 1, b + 2, b + 3); }
    }
    const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.setIndex(idx); g.computeVertexNormals();
    const m = new THREE.Mesh(g, new THREE.MeshStandardMaterial({ color: col, roughness: 1, side: THREE.DoubleSide, fog: false })); scene.add(m);
    m.userData.wire = new THREE.MeshBasicMaterial({ color: 0x2c3442, wireframe: true, fog: true }); m.userData.solid = m.material; GROUNDS.push(m);
  };
  // we stand on a summit: the nearer ridges lie below eye level, the far inland mountains rise a little above it
  ridge(9000, -900, 250, 140, 0x2a3242, true);
  ridge(20000, 600, 3400, 120, 0x3d4659, true);
  // B3: the Adriatic, ~1,400 ft below and spread out to the eastern horizon: a dark mirror of the dawn sky with waves
  // C2: the waves are no longer a tiled normal-map texture. That texture repeated every ~220 ft, and far out its
  // tiles and their mip levels showed as a regular grid and moire. The waves are now computed per pixel from the
  // world position: ten wave trains with incommensurate wavelengths (2-310 ft) and unrelated directions, so there is no
  // period anywhere, plus a slow noise that varies their strength across the sea. Each train fades out once it is
  // finer than ~1 pixel (from the pixel's footprint on the water), so the far sea never aliases. The fine waves that
  // disappear in the distance are replaced by extra roughness, which widens the glitter path the way real
  // sub-pixel chop does.
  const seaMat = std(new THREE.Color(0x0c1826), 0.12, 0.85); seaMat.fog = false; seaMat.envMapIntensity = 1.3;
  // wavelength (ft), direction (rad; the wind blows from about 0.9 rad, with a spread), slope. Short waves carry the
  // texture; long ones are kept gentle so they never read as stripes.
  const WAVES = [[1.7, 0.42, 0.05], [2.6, 1.61, 0.05], [3.9, 0.07, 0.05], [5.8, 1.27, 0.05], [8.3, 0.66, 0.045],
                 [11.9, 1.93, 0.04], [17.4, 0.21, 0.035], [25.3, 1.48, 0.03], [36.8, 0.88, 0.025], [53.9, 0.33, 0.018],
                 [79.1, 1.71, 0.013], [117.0, 1.05, 0.01], [173.0, 0.52, 0.008]];
  seaMat.onBeforeCompile = (sh) => {
    sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nvarying vec3 vSeaW;')
      .replace('#include <project_vertex>', '#include <project_vertex>\n  vSeaW = (modelMatrix * vec4(transformed, 1.0)).xyz;');
    const waveCode = WAVES.map(([L, d, sl]) => { const k = (2 * Math.PI / L).toFixed(6), cx = Math.cos(d).toFixed(6), cz = Math.sin(d).toFixed(6);
      return `  { vec2 kd = vec2(${cx}, ${cz}) * ${k}; float f = 1.0 - smoothstep(0.35, 1.1, ${k} * seaFp); float ph = dot(kd, seaP) + ${(d * 7.3).toFixed(4)};
    seaG += vec2(${cx}, ${cz}) * cos(ph) * ${sl.toFixed(4)} * f * (0.55 + 0.9 * seaPatch); seaLost += ${sl.toFixed(4)} * (1.0 - f); }`; }).join('\n');
    sh.fragmentShader = sh.fragmentShader.replace('#include <common>', `#include <common>
varying vec3 vSeaW;
float seaHash(vec2 q) { return fract(sin(dot(q, vec2(127.1, 311.7))) * 43758.5453); }
float seaNoise(vec2 q) { vec2 i = floor(q), u = fract(q); u = u * u * (3.0 - 2.0 * u);
  return mix(mix(seaHash(i), seaHash(i + vec2(1, 0)), u.x), mix(seaHash(i + vec2(0, 1)), seaHash(i + vec2(1, 1)), u.x), u.y); }`)
      .replace('#include <roughnessmap_fragment>', `#include <roughnessmap_fragment>
  vec2 seaP = vSeaW.xz, seaG = vec2(0.0); float seaLost = 0.0;
  float seaFp = length(fwidth(seaP));                                   // ft of water under this pixel
  float seaPatch = 0.6 * seaNoise(seaP / 900.0 + 3.1) + 0.4 * seaNoise(seaP / 260.0 - 7.7);
${waveCode}
  // irregular chop: the gradient of value noise at three scales, faded like the waves
  for (int o = 0; o < 3; o++) { float sc = o == 0 ? 31.0 : (o == 1 ? 13.0 : 5.3), e = 0.12 * sc;
    float f = 1.0 - smoothstep(0.2, 0.7, seaFp / sc);
    vec2 q = seaP / sc + float(o) * 17.3;
    vec2 gq = vec2(seaNoise(q + vec2(0.12, 0.0)) - seaNoise(q - vec2(0.12, 0.0)), seaNoise(q + vec2(0.0, 0.12)) - seaNoise(q - vec2(0.0, 0.12))) / 0.24;
    seaG += gq * 0.035 * f; seaLost += 0.035 * (1.0 - f); }
  roughnessFactor = clamp(roughnessFactor + seaLost * 0.5, 0.0, 0.45);`)
      .replace('#include <normal_fragment_maps>', `
  { vec3 nW = normalize(vec3(-seaG.x, 1.0, -seaG.y)); normal = normalize((viewMatrix * vec4(nW, 0.0)).xyz); }`);
  };
  seaMat.customProgramCacheKey = () => 'sea-c2';
  const sea = new THREE.Mesh(new THREE.PlaneGeometry(200000, 200000), seaMat);
  sea.rotation.x = -Math.PI / 2; sea.position.set(SITE.x, -1400, SITE.z); scene.add(sea);
  // a few low islands far out (as the Tremiti islands lie off Monte Gargano), dark against the bright water
  for (const [ang, dist, len, hgt] of [[-0.55, 26000, 2600, 260], [-0.47, 31000, 1500, 170], [-0.62, 34000, 900, 120]]) {
    const ca = Math.cos(ang), sa = Math.sin(ang), dx = EAST.x * ca - EAST.z * sa, dz = EAST.x * sa + EAST.z * ca;
    const is = new THREE.Mesh(new THREE.SphereGeometry(1, 24, 8, 0, Math.PI * 2, 0, Math.PI / 2), new THREE.MeshStandardMaterial({ color: 0x3a4152, roughness: 1, fog: false }));
    is.scale.set(len, hgt, len * 0.45); is.position.set(SITE.x + dx * dist, -1400, SITE.z + dz * dist); is.rotation.y = ang; scene.add(is);
  }
  sea.userData.wire = new THREE.MeshBasicMaterial({ color: 0x1a2a3a, fog: true }); sea.userData.solid = sea.material; GROUNDS.push(sea);
}
// ---- A2: THE MEASURING POLE beside the queen's second station: 1 in across, 10 ft above the ground, painted dark
// grey with a 1-in white band at every foot (a red one at 5 ft and 10 ft), so the ball's height and size can be read
// against it. It stands exactly where the sim's solid pole is (sim.pole; P.poleR, P.poleH).
if (HOVER) {   // CT54: option 5 only
  const [px, pz] = sim.pole, g0 = groundAt ? groundAt(px, pz) : 0, R = P.poleR, Hh = P.poleH;
  const pole = new THREE.Group();
  const shaft = new THREE.Mesh(new THREE.CylinderGeometry(R, R, Hh + 0.6, 16), new THREE.MeshStandardMaterial({ color: 0x3b3d40, roughness: 0.55, metalness: 0.3 }));
  shaft.position.set(px, g0 + (Hh - 0.6) / 2, pz); pole.add(shaft);
  const white = new THREE.MeshStandardMaterial({ color: 0xf2efe6, roughness: 0.4, emissive: 0x2a2a28 });
  const red = new THREE.MeshStandardMaterial({ color: 0xc8261e, roughness: 0.4, emissive: 0x2a0806 });
  for (let f = 1; f <= Hh; f++) {
    const band = new THREE.Mesh(new THREE.CylinderGeometry(R * 1.12, R * 1.12, 1 / 12, 16), f % 5 === 0 ? red : white);
    band.position.set(px, g0 + f, pz); pole.add(band);
  }
  const cap = new THREE.Mesh(new THREE.SphereGeometry(R * 1.3, 12, 8), red); cap.position.set(px, g0 + Hh + 0.02, pz); pole.add(cap);
  shadowy(pole); scene.add(pole);
}
// ---- C1: THE ARBOR. An old wooden pergola at the brink of the summit, in bad shape: four posts, two long beams,
// rafters across them (two are gone, one has fallen and leans from the back beam to the ground) and a few slats.
// The timber is silvered and weathered: lengthwise checks (splits), raised grain, rounded and crumbled arrises,
// rot at the post feet and at the beam ends, splintered broken ends, lichen on the tops, a dead vine. Dull and dry
// (roughness 1, almost no sky reflection). The solid parts are exactly the sim's boxes (sim.arborBoxes()); the
// front beam's underside, where the bees hang, is weathered only lightly (<= 0.02 ft, into the wood) and sags as
// the sim's does. A few bare rocks lie about.
// inward direction on a box: gradient of a rounded-box function (face normal on faces, diagonal on edges)
const boxIn = (x, y, z, hx, hy, hz, out) => out.set(Math.sign(x) * Math.pow(Math.abs(x) / hx, 9) / hx, Math.sign(y) * Math.pow(Math.abs(y) / hy, 9) / hy, Math.sign(z) * Math.pow(Math.abs(z) / hz, 9) / hz).normalize();
// a rough rock (kept from B3 for the few boulders): pitted, chipped, chunks missing
function erodedBox(w, h, d, o = {}) {
  const amp = o.amp ?? 0.06, chip = o.chip ?? 0.22, chunk = o.chunk ?? 0.35, freq = o.freq ?? 1.6, seed = o.seed ?? rnd() * 100, res = o.res ?? 0.14;
  const g = new THREE.BoxGeometry(w, h, d, Math.max(2, Math.min(48, Math.round(w / res))), Math.max(2, Math.min(48, Math.round(h / res))), Math.max(2, Math.min(48, Math.round(d / res))));
  const p = g.attributes.position, col = new Float32Array(p.count * 3), hx = w / 2, hy = h / 2, hz = d / 2, cw = Math.min(0.45, 0.35 * Math.min(w, h, d)), tmp = new THREE.Vector3();
  for (let i = 0; i < p.count; i++) {
    const x = p.getX(i), y = p.getY(i), z = p.getZ(i); boxIn(x, y, z, hx, hy, hz, tmp);
    const ex = SM(Math.abs(x), hx - cw, hx), ey = SM(Math.abs(y), hy - cw, hy), ez = SM(Math.abs(z), hz - cw, hz), edge = Math.max(ex * ey, ey * ez, ex * ez);
    const n1 = NZ.fbm(x * freq + seed, y * freq, z * freq), n2 = NZ.fbm(x * 0.45 + seed * 3, y * 0.45, z * 0.45, 3);
    const dsp = amp * (0.3 + n1 * 1.4) + chip * edge * (0.4 + 1.2 * n1) + chunk * SM(n2, 0.58, 0.78);
    p.setXYZ(i, x - tmp.x * dsp, y - tmp.y * dsp, z - tmp.z * dsp);
    const v = 0.74 - 0.3 * Math.min(1, dsp / (amp * 2.5 + 0.02)), lich = SM(NZ.fbm(x * 0.9 + 40 + seed, y * 0.9, z * 0.9, 3), 0.6, 0.72);
    col[i * 3] = v * (1 - lich) + 0.42 * lich; col[i * 3 + 1] = v * 0.97 * (1 - lich) + 0.46 * lich; col[i * 3 + 2] = v * 0.9 * (1 - lich) + 0.32 * lich;
  }
  g.setAttribute('color', new THREE.BufferAttribute(col, 3)); g.computeVertexNormals(); return g;
}
// a weathered timber: len along local X, h (Y) x d (Z). Grain and checks run along the length (noise stretched along
// X); arrises rounded and crumbled; rot at either end (rotA at -X, rotB at +X); broken = -1 / +1 splinters that end
// (every 'fibre' stops at a different length); limitBottom caps the weathering of the underside (the bees' face);
// bend(x) lifts the timber along its length (the beam's sag). Vertex colours: silver-grey, dark in the cracks and
// the rot, greenish lichen on the upper faces, damp-dark toward the ground (base = height of the -Y face).
const woodTmp = new THREE.Vector3();
function woodBox(len, h, d, o = {}) {
  const seed = o.seed ?? rnd() * 100, ch = o.check ?? 0.05, edgeW = Math.min(0.12, 0.3 * Math.min(h, d));
  const sx = Math.max(4, Math.min(o.maxSeg ?? 140, Math.round(len / (o.resL ?? 0.12)))), sy = Math.max(3, Math.round(h / 0.045)), sz = Math.max(3, Math.round(d / 0.045));
  const g = new THREE.BoxGeometry(len, h, d, sx, sy, sz), p = g.attributes.position, col = new Float32Array(p.count * 3);
  const hx = len / 2, hy = h / 2, hz = d / 2;
  for (let i = 0; i < p.count; i++) {
    let x = p.getX(i), y = p.getY(i), z = p.getZ(i); boxIn(x, y, z, hx, hy, hz, woodTmp);
    const ey = SM(Math.abs(y), hy - edgeW, hy), ez = SM(Math.abs(z), hz - edgeW, hz), arris = ey * ez;
    const grain = NZ.fbm(x * 0.7 + seed, y * 11, z * 11, 3);                        // raised grain, along the length
    const check = SM(NZ.fbm(x * 0.22 + seed * 2, y * 7.5, z * 7.5, 3), 0.66, 0.74);  // long splits
    const crumble = NZ.fbm(x * 2.2 + seed, y * 2.2, z * 2.2, 3);
    const endA = SM(-x, hx - (o.rotLenA ?? 0.6), hx) * (o.rotA ?? 0), endB = SM(x, hx - (o.rotLenB ?? 0.6), hx) * (o.rotB ?? 0);
    const rot = (endA + endB) * (0.4 + 1.1 * crumble);
    let dsp = 0.012 * grain + ch * check + (0.045 + 0.06 * crumble) * arris + rot * 0.12;
    if (o.limitBottom && y < -hy + 1e-4 && Math.abs(z) < hz - 0.05 && Math.abs(x) < hx - 0.5) dsp = Math.min(dsp, 0.02);
    x -= woodTmp.x * dsp; y -= woodTmp.y * dsp; z -= woodTmp.z * dsp;
    if (o.broken) {                                                               // splintered end
      const L = o.splinter ?? 0.7, x0 = o.broken * (hx - L), t = (x - x0) * o.broken;
      if (t > 0) { const f = 0.15 + 0.85 * Math.pow(NZ.fbm(y * 9 + seed, z * 9, seed, 3), 1.6); x = x0 + o.broken * t * f; }
    }
    if (o.bend) y += o.bend(x);
    p.setXYZ(i, x, y, z);
    const hollow = Math.min(1, dsp / 0.08), wy = o.vertical ? x + hx : (o.base ?? 0) + y + hy;
    let v = 0.72 + 0.12 * (grain - 0.5) - 0.42 * hollow - 0.25 * Math.min(1, rot) - 0.18 * (1 - Math.min(1, wy / 2.5));
    const lich = (o.vertical ? woodTmp.x < -0.5 : woodTmp.y < -0.5) ? SM(NZ.fbm(x * 1.3 + 70 + seed, y * 1.3, z * 1.3, 3), 0.56, 0.7) : 0;   // on upper faces
    let r = v * 1.0, gg = v * 0.95, b = v * 0.86;
    r = r * (1 - lich) + 0.46 * lich; gg = gg * (1 - lich) + 0.5 * lich; b = b * (1 - lich) + 0.3 * lich;
    col[i * 3] = Math.max(0.05, r); col[i * 3 + 1] = Math.max(0.05, gg); col[i * 3 + 2] = Math.max(0.05, b);
  }
  g.setAttribute('color', new THREE.BufferAttribute(col, 3));
  g.computeVertexNormals();
  return g;
}
const woodTex = canvasTex(512, (c, n) => {                         // silvered old timber: grey grain lines, knots, dark checks
  c.fillStyle = '#b4ad9f'; c.fillRect(0, 0, n, n);
  for (let k = 0; k < 260; k++) {                                   // grain lines run along u (the timber's length)
    const y0 = rnd() * n, a = 1 + rnd() * 5, f = 1 + (rnd() * 3 | 0), ph = rnd() * 6.3, v = 90 + rnd() * 100 | 0;
    c.strokeStyle = `rgba(${v},${v - 4},${v - 14},${0.12 + rnd() * 0.22})`; c.lineWidth = 0.6 + rnd() * 1.6; c.beginPath();
    for (let x = 0; x <= n; x += 8) { const y = y0 + a * Math.sin(x / n * Math.PI * 2 * f + ph); x ? c.lineTo(x, y) : c.moveTo(x, y); } c.stroke(); }
  for (let k = 0; k < 7; k++) {                                     // knots
    const x = rnd() * n, y = rnd() * n, r = 4 + rnd() * 9;
    for (let j = 5; j >= 0; j--) { c.strokeStyle = `rgba(60,48,38,${0.12 + j * 0.05})`; c.lineWidth = 1.2; c.beginPath(); c.ellipse(x, y, r + j * 5, (r + j * 5) * 0.45, 0, 0, Math.PI * 2); c.stroke(); }
    c.fillStyle = 'rgba(48,38,30,.75)'; c.beginPath(); c.ellipse(x, y, r, r * 0.6, 0, 0, Math.PI * 2); c.fill(); }
  for (let k = 0; k < 26; k++) {                                    // checks
    let x = rnd() * n, y = rnd() * n; const L = 60 + rnd() * 220; c.strokeStyle = `rgba(30,26,22,${0.35 + rnd() * 0.4})`; c.lineWidth = 0.8 + rnd() * 1.4; c.beginPath(); c.moveTo(x, y);
    for (let s = 0; s < L; s += 10) { x += 10; y += (rnd() - 0.5) * 2.5; c.lineTo(x, y); } c.stroke(); }
  for (let k = 0; k < 9000; k++) { const v = 70 + rnd() * 140 | 0; c.fillStyle = `rgba(${v},${v - 3},${v - 10},.22)`; c.fillRect(rnd() * n, rnd() * n, 2.5, 0.8); }
});
const woodMat = new THREE.MeshStandardMaterial({ map: woodTex, bumpMap: woodTex, bumpScale: 2.0, roughness: 1.0, metalness: 0, vertexColors: true });
woodMat.envMapIntensity = 0.08;                                     // dull, dry
const WOOD_WIRE = new THREE.MeshBasicMaterial({ color: 0xa79a80, wireframe: true, fog: true, transparent: true, opacity: 0.28, depthWrite: false });
stoneMat.vertexColors = true; stoneMat.roughness = 1.0; stoneMat.bumpScale = 2.4; stoneMat.envMapIntensity = 0.0;
const arbor = new THREE.Group();
const addPart = (geo, mat, x, y, z, rx = 0, ry = 0, rz = 0) => { const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); m.rotation.set(rx, ry, rz);
  m.castShadow = m.receiveShadow = true; m.userData.wire = mat === woodMat ? WOOD_WIRE : WOOD_WIRE; m.userData.solid = mat; arbor.add(m); GROUNDS.push(m); return m; };
{
  const B = sim.arborBoxes(), hs = P.arborHalf, lift = (wx) => sim._beamY(wx) - P.attachY;
  let pk = 0;
  for (const b of B) {
    const w = b.x1 - b.x0, h = b.y1 - b.y0, d = b.z1 - b.z0, cx = (b.x0 + b.x1) / 2, cy = (b.y0 + b.y1) / 2, cz = (b.z0 + b.z1) / 2;
    if (b.kind === 'post') {                                         // vertical: built along X, turned up (local -X = the foot)
      const g = woodBox(h, w, d, { rotA: 1.4, rotLenA: 1.2, rotB: 0.5, rotLenB: 0.3, check: 0.07, vertical: true, resL: 0.15 });
      g.rotateZ(Math.PI / 2);
      addPart(g, woodMat, cx, cy, cz, 0, (pk++ % 3) * 0.03, 0);
    } else if (b.kind === 'beam') {
      const front = b.z1 > P.siteZ;
      const g = woodBox(w, h, d, { rotA: 0.8, rotB: front ? 0.6 : 1.0, check: 0.06, limitBottom: front, base: b.y0, bend: (lx) => lift(cx + lx), maxSeg: 160,
        broken: front ? 0 : 1, splinter: 0.6 });
      addPart(g, woodMat, cx, cy, cz);
    } else if (b.kind === 'rafter') {                                // along Z: build along X, turn 90 deg about Y
      const g = woodBox(d, h, w, { rotA: 0.9, rotB: 0.7, rotLenA: 0.4, rotLenB: 0.4, check: 0.04, base: b.y0, broken: pk % 2 ? -1 : 1, splinter: 0.35 });
      g.rotateY(Math.PI / 2); pk++;
      addPart(g, woodMat, cx, cy, cz);
    } else {                                                         // slats: thin, one broken short
      const g = woodBox(w, h, d, { check: 0.02, base: b.y0, rotA: 0.5, rotB: 0.5, broken: pk % 3 === 0 ? -1 : 0, splinter: 1.6 });
      pk++;
      addPart(g, woodMat, cx, cy, cz);
    }
  }
  // the fallen rafter (cosmetic; not solid for the bees): one end still caught on the back beam, the other in the
  // grass behind the arbor, where two rafters are missing
  { const zb = P.siteZ - P.arborBack, top = P.attachY + P.beamH + lift(P.siteX - 1.3), foot = new THREE.Vector3(P.siteX - 0.5, 0.1, zb - 4.6), hd = new THREE.Vector3(P.siteX - 1.25, top + 0.1, zb + 0.4);
    const L = foot.distanceTo(hd) + 0.3, g = woodBox(L, P.rafterH, P.rafterW, { rotA: 1.2, rotB: 0.8, check: 0.05, broken: 1, splinter: 0.5 });
    const m = addPart(g, woodMat, (foot.x + hd.x) / 2, (foot.y + hd.y) / 2, (foot.z + hd.z) / 2);
    m.quaternion.setFromUnitVectors(new THREE.Vector3(1, 0, 0), hd.clone().sub(foot).normalize()); }
  // a knee brace that has come away, lying against the front-left post
  { const g = woodBox(2.4, 0.3, 0.22, { rotA: 1, rotB: 1, check: 0.04, broken: -1, splinter: 0.4 });
    const m = addPart(g, woodMat, P.siteX - hs - 0.9, 0.7, P.siteZ + 0.45); m.rotation.set(0.15, 0.4, 0.55); }
  // short offcuts and a split plank in the grass
  for (let k = 0; k < 4; k++) addPart(woodBox(0.9 + rnd() * 1.6, 0.12 + rnd() * 0.15, 0.3 + rnd() * 0.2, { rotA: 1, rotB: 1, check: 0.03 }), woodMat,
    P.siteX + (rnd() - 0.5) * 12, 0.08, P.siteZ - P.arborBack * rnd() + (rnd() - 0.2) * 3, (rnd() - 0.5) * 0.1, rnd() * 3, (rnd() - 0.5) * 0.1);
  // a dead vine: a gnarled stem up the front-left post and along the top of the front beam, with dry tendrils
  // hanging from the rafters (cosmetic, thin)
  const vineMat = new THREE.MeshStandardMaterial({ color: 0x4c3f33, roughness: 1, metalness: 0 });
  const vine = (pts, r) => { const c = new THREE.CatmullRomCurve3(pts.map(q => new THREE.Vector3(...q))); addPart(new THREE.TubeGeometry(c, Math.max(8, pts.length * 10), r, 6, false), vineMat, 0, 0, 0); };
  { const x0 = P.siteX - hs, z0 = P.siteZ, pr = P.postW / 2 + 0.05, pts = [];
    for (let k = 0; k <= 14; k++) { const a = k * 1.1, y = k * (P.attachY + P.beamSag) / 14; pts.push([x0 + Math.cos(a) * pr, y, z0 + Math.sin(a) * pr]); }
    pts.push([x0 + 0.6, P.attachY + P.beamSag + P.beamH + 0.08, z0 + 0.1]);
    for (let k = 1; k <= 6; k++) { const x = x0 + 0.6 + k * 0.55; pts.push([x, sim._beamY(x) + P.beamH + 0.07 + 0.05 * Math.sin(k * 2.3), z0 + 0.12 * Math.sin(k * 1.7)]); }
    vine(pts, 0.035); }
  for (const rx of [-4.0, -2.6, 2.55]) for (let k = 0; k < 2; k++) {
    const x = P.siteX + rx + (rnd() - 0.5) * 0.1, z = P.siteZ - 1.2 - rnd() * (P.arborBack - 2.4), y = sim._beamY(x) + P.beamH, L = 0.8 + rnd() * 1.6, pts = [];
    for (let j = 0; j <= 6; j++) pts.push([x + Math.sin(j * 1.3 + k) * 0.08, y - L * j / 6, z + Math.cos(j * 1.1) * 0.08]);
    vine(pts, 0.012);
  }
  // C7: the thin support - a dead vine stem slung in a loop under the front beam (the sim's cylinder exactly where
  // the bees can grip it, |x| < 0.7 stemHalf; gnarled, and climbing up over the beam's face at either end), held up
  // by a few tendrils wound round the beam
  if (P.support === 'branch') {
    const R = P.stemR, zf = P.siteZ, hb = P.stemHalf, pts = [];
    const zf0 = zf + 0.5 * P.beamD + R * 0.9;                          // the beam's front face
    pts.push([P.siteX - hb - 0.5, sim._beamY(P.siteX - hb - 0.5) + P.beamH * 0.7, zf0]);
    pts.push([P.siteX - hb - 0.15, sim._beamY(P.siteX - hb) - R * 0.4, zf0 - 0.05]);
    for (let k = 0; k <= 26; k++) {
      const x = P.siteX - hb + 2 * hb * k / 26, u = Math.abs(x - P.siteX) / hb, wob = u > 0.7 ? (u - 0.7) / 0.3 : 0;
      pts.push([x, sim._stemAxisY(x) + 0.02 * wob * Math.sin(k * 1.9), zf + wob * (0.06 * Math.sin(k * 1.3 + 0.5))]);
    }
    pts.push([P.siteX + hb + 0.15, sim._beamY(P.siteX + hb) - R * 0.4, zf0 - 0.05]);
    pts.push([P.siteX + hb + 0.45, sim._beamY(P.siteX + hb + 0.45) + P.beamH * 0.8, zf0]);
    pts.push([P.siteX + hb + 0.7, sim._beamY(P.siteX + hb + 0.7) + P.beamH + 0.06, zf0 - 0.2]);
    const c = new THREE.CatmullRomCurve3(pts.map(q => new THREE.Vector3(...q)));
    const g = new THREE.TubeGeometry(c, 420, R, 10, false), pp = g.attributes.position, tmp = new THREE.Vector3(), cen = new THREE.Vector3();
    // bark: shallow ridges along the stem, a little knobbly; the part the bees grip stays within 0.008 ft of R
    for (let i = 0; i < pp.count; i++) {
      tmp.fromBufferAttribute(pp, i); const t = Math.floor(i / 11) / 420; c.getPointAt(Math.min(1, t), cen);
      const d = tmp.clone().sub(cen), ang = Math.atan2(d.z, d.y), mid = Math.abs(tmp.x - P.siteX) < 0.7 * hb;
      const a = (mid ? 0.006 : 0.016) * (Math.sin(ang * 7 + tmp.x * 3) * 0.6 + NZ.fbm(tmp.x * 6, ang, 3.3, 3) - 0.5);
      tmp.addScaledVector(d.normalize(), a); pp.setXYZ(i, tmp.x, tmp.y, tmp.z);
    }
    g.computeVertexNormals(); addPart(g, vineMat, 0, 0, 0);
    for (const tx of [-0.82, 0.8]) {                                   // tendrils wound round the beam, holding it up
      const x0 = P.siteX + tx * hb, y0 = sim._stemAxisY(x0), yb = sim._beamY(x0), tp = [];
      for (let k = 0; k <= 16; k++) { const a = k / 16 * Math.PI * 2.2, rr = 0.5 * P.beamD + 0.05;
        tp.push([x0 + k * 0.012, k < 3 ? y0 + (yb - y0) * k / 3 : yb + P.beamH / 2 - Math.cos(a) * (P.beamH / 2 + 0.04), k < 3 ? zf + 0.04 * k : zf + Math.sin(a) * rr]); }
      vine(tp, 0.012);
    }
  }
  // a few bare rocks of the summit
  for (const [dx, dz, s] of [[-7.5, 2.5, 1.0], [6.8, -7.5, 1.4], [-9.5, -9, 0.8], [3.5, 5.5, 0.6], [11, 1.5, 1.1]]) {
    const w = 1.2 * s + rnd() * s, hh = 0.6 * s + rnd() * 0.5 * s, dd = 1.0 * s + rnd() * s;
    addPart(erodedBox(w, hh, dd, { amp: 0.07, chip: 0.3, chunk: 0.3 }), stoneMat, P.siteX + dx, hh * 0.3, P.siteZ + dz, (rnd() - 0.5) * 0.2, rnd() * 3, (rnd() - 0.5) * 0.2);
  }
}
scene.add(arbor);
// (C1: the arbor swaps to a wireframe material in the wire look, like the terrain)

// ---------------------------------------------------------------- B1: metal honeybees
// Each bee: a metal body (abdomen + thorax + head) with alternating NARROW BLACK and BROADER GOLD stripes, FIVE RED
// EYES (two compound eyes and the three ocelli on the crown, as a real honeybee has), two wings of thin semi-
// transparent CRYSTAL with a fine edge, and a black OUTLINE (inverted hull) that makes the hanging structure legible.
// Bee-local frame: +Z = head, +Y = back, X = sideways; length 1 = the bee's body length. One instance matrix per
// bee, shared by all the meshes. Wings are posed in the vertex shader from aFold (0 spread .. 1 folded) and aFlap.
function mergeAll(geos) {                          // merge non-indexed position+normal geometries
  const gs = geos.map(g => g.index ? g.toNonIndexed() : g);
  let n = 0; for (const g of gs) n += g.attributes.position.count;
  const pa = new Float32Array(n * 3), na = new Float32Array(n * 3); let o = 0;
  for (const g of gs) { pa.set(g.attributes.position.array, o); na.set(g.attributes.normal.array, o); o += g.attributes.position.array.length; }
  const m = new THREE.BufferGeometry(); m.setAttribute('position', new THREE.BufferAttribute(pa, 3)); m.setAttribute('normal', new THREE.BufferAttribute(na, 3)); return m;
}
const LOWQ = qs.get('q') === 'low';
const seg = (a, b) => LOWQ ? [Math.max(5, a - 3), Math.max(4, b - 3)] : [a, b];
const ell = (rx, ry, rz, x, y, z, ws, hs) => { const g = new THREE.SphereGeometry(1, ...seg(ws, hs)); g.rotateX(Math.PI / 2); g.scale(rx, ry, rz); g.translate(x, y, z); return g; };
// abdomen with enough rings for crisp stripes (the stripes themselves are drawn per pixel in the shader)
const beeBodyGeo = mergeAll([
  ell(0.165, 0.155, 0.30, 0, -0.01, -0.20, 12, 12),      // abdomen  z -0.50 .. 0.10
  ell(0.150, 0.150, 0.150, 0, 0.02, 0.20, 9, 7),         // thorax   z  0.05 .. 0.35
  ell(0.130, 0.120, 0.095, 0, 0.0, 0.40, 9, 7),          // head     z  0.31 .. 0.50
]);
// five eyes: the two compound eyes on the sides of the head, three ocelli in a triangle on the crown
const beeEyeGeo = mergeAll([
  ell(0.045, 0.07, 0.05, 0.105, 0.03, 0.415, 8, 6), ell(0.045, 0.07, 0.05, -0.105, 0.03, 0.415, 8, 6),
  ell(0.018, 0.018, 0.018, 0, 0.118, 0.44, 6, 4), ell(0.016, 0.016, 0.016, 0.04, 0.11, 0.40, 6, 4), ell(0.016, 0.016, 0.016, -0.04, 0.11, 0.40, 6, 4),
]);
// stripes: in the body's own frame (before the instance matrix), so they ride along with each bee
const STRIPE_VS = (vs) => vs.replace('#include <common>', '#include <common>\nvarying vec3 vBee;')
  .replace('#include <begin_vertex>', '#include <begin_vertex>\nvBee = position;');
const STRIPE_FS_HEAD = `varying vec3 vBee;
  // 0 = black, 1 = gold. Abdomen: bands 0.095 body-lengths long, 0.033 black then 0.062 gold (narrow black, broad
  // gold), the tip black; thorax: dark gold (bronze); head: black.
  float beeGold() {
    float z = vBee.z;
    if (z > 0.31) return 0.0;
    if (z > 0.06) return 0.45;
    if (z < -0.46) return 0.0;
    float f = fract((z + 0.5) / 0.095);
    return smoothstep(0.30, 0.36, f) * (1.0 - smoothstep(0.96, 1.0, f));
  }
  const vec3 GOLD = vec3(1.0, 0.72, 0.28), BLACKM = vec3(0.025, 0.022, 0.02);`;
const shadedBodyMat = new THREE.MeshStandardMaterial({ color: 0xffffff, metalness: 1.0, roughness: 0.3, envMapIntensity: 1.0 });
shadedBodyMat.onBeforeCompile = (sh) => {
  sh.vertexShader = STRIPE_VS(sh.vertexShader);
  sh.fragmentShader = sh.fragmentShader.replace('#include <common>', '#include <common>\n' + STRIPE_FS_HEAD)
    .replace('#include <color_fragment>', '#include <color_fragment>\n float gk = beeGold(); diffuseColor.rgb *= mix(BLACKM, GOLD, gk);')
    .replace('#include <metalnessmap_fragment>', '#include <metalnessmap_fragment>\n metalnessFactor = mix(0.55, 1.0, gk);')
    .replace('#include <roughnessmap_fragment>', '#include <roughnessmap_fragment>\n roughnessFactor = mix(0.22, 0.30, gk);');
};
shadedBodyMat.customProgramCacheKey = () => 'ct39b1body';
METALS.push(shadedBodyMat);
const wireBodyMat = new THREE.MeshBasicMaterial({ wireframe: true, fog: true });
wireBodyMat.onBeforeCompile = (sh) => {
  sh.vertexShader = STRIPE_VS(sh.vertexShader);
  sh.fragmentShader = sh.fragmentShader.replace('#include <common>', '#include <common>\n' + STRIPE_FS_HEAD)
    .replace('#include <color_fragment>', '#include <color_fragment>\n diffuseColor.rgb *= mix(vec3(0.16, 0.14, 0.12), GOLD, beeGold());');
};
wireBodyMat.customProgramCacheKey = () => 'ct39b1wire';
// OUTLINE: the body again in black, back faces only, pushed out along its normals by uOutline body-lengths
const outlineMat = new THREE.MeshBasicMaterial({ color: 0x000000, side: THREE.BackSide, fog: true });
const uOutline = { value: parseFloat(qs.get('outlinew') ?? '0.035') };
outlineMat.onBeforeCompile = (sh) => { sh.uniforms.uOutline = uOutline;
  sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nuniform float uOutline;')
    .replace('#include <begin_vertex>', 'vec3 transformed = position + normalize(normal) * uOutline;'); };
outlineMat.customProgramCacheKey = () => 'ct39outline';
// eyes: red, faintly self-lit
const eyeMat = new THREE.MeshStandardMaterial({ color: 0x5a0000, emissive: 0xff1a0a, emissiveIntensity: 0.9, metalness: 0.2, roughness: 0.25 });
// wings: ellipses along their own axis u (0 at the hinge .. 0.56 at the tip), width v; attribute aWing = (u, v, side)
function wingGeo(outline) {
  const N = 28, A = 0.28, B = 0.095, pts = [];
  const rim = (k, s) => { const t = k / N * Math.PI * 2; return [A + A * Math.cos(t) * s, B * Math.sin(t) * s]; };
  for (const side of [-1, 1]) for (let k = 0; k < N; k++) {
    if (outline) {
      const a0 = rim(k, 1), a1 = rim(k + 1, 1), b0 = rim(k, 0.93), b1 = rim(k + 1, 0.93);
      pts.push(...a0, side, ...a1, side, ...b0, side, ...b0, side, ...a1, side, ...b1, side);
    } else { const a0 = rim(k, 1), a1 = rim(k + 1, 1); pts.push(A, 0, side, ...a0, side, ...a1, side); }
  }
  if (outline) for (const side of [-1, 1]) {        // a vein along the middle of each wing
    pts.push(0.02, -0.004, side, 0.5, -0.004, side, 0.5, 0.004, side, 0.02, -0.004, side, 0.5, 0.004, side, 0.02, 0.004, side);
  }
  const g = new THREE.BufferGeometry();
  const a = new Float32Array(pts);
  g.setAttribute('aWing', new THREE.BufferAttribute(a, 3));
  g.setAttribute('position', new THREE.BufferAttribute(new Float32Array(a.length), 3));   // placeholder (posed in the shader)
  g.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1);
  return g;
}
const aFold = new THREE.InstancedBufferAttribute(new Float32Array(BEES), 1).setUsage(THREE.DynamicDrawUsage);
const aFlap = new THREE.InstancedBufferAttribute(new Float32Array(BEES), 1).setUsage(THREE.DynamicDrawUsage);
const WING_POSE = `
        float side = aWing.z;
        float phi = mix(1.25, 0.16, aFold);                         // wing angle from the tail axis: spread .. folded
        vec3 dir = vec3(side * sin(phi), 0.0, -cos(phi));
        vec3 perp = vec3(dir.z, 0.0, -dir.x) * side;
        float fa = side * aFlap, wc = cos(fa), ws = sin(fa);`;
function wingMaterial(base, key) {
  base.side = THREE.DoubleSide;
  base.onBeforeCompile = (sh) => {
    sh.vertexShader = sh.vertexShader
      .replace('#include <common>', '#include <common>\nattribute vec3 aWing; attribute float aFold; attribute float aFlap;')
      .replace('void main() {', 'void main() {' + WING_POSE)
      .replace('#include <beginnormal_vertex>', 'vec3 objectNormal = vec3(-ws, wc, 0.0);')   // the wing plane's normal after the stroke
      .replace('#include <begin_vertex>', `
        vec3 w = dir * aWing.x + perp * aWing.y;
        w = vec3(wc * w.x - ws * w.y, ws * w.x + wc * w.y, w.z);    // stroke: rotate about the body axis
        vec3 transformed = vec3(side * 0.06, 0.155, 0.2) + w + vec3(0.0, 0.03 * aFold, 0.0);`);
  };
  base.customProgramCacheKey = () => 'ct39wing' + key;
  return base;
}
// crystal: clear, glossy, with a thin-film iridescence; ~25 % opaque so the body shows through
const wingCrystalMat = wingMaterial(new THREE.MeshPhysicalMaterial({ color: 0xeef4ff, metalness: 0, roughness: 0.04, transparent: true, opacity: 0.26,
  depthWrite: false, iridescence: 0.9, iridescenceIOR: 1.35, iridescenceThicknessRange: [200, 600], specularIntensity: 1, envMapIntensity: 1.4 }), 'c');
METALS.push(wingCrystalMat);
const wingWireMat = wingMaterial(new THREE.MeshBasicMaterial({ color: 0xbfd2e8, transparent: true, opacity: 0.18, depthWrite: false, fog: true }), 'w');
const wingRimMat = wingMaterial(new THREE.MeshBasicMaterial({ color: 0xd6e6f5, transparent: true, opacity: 0.55, depthWrite: false, fog: true }), 'r');
const beeBody = new THREE.InstancedMesh(beeBodyGeo, shaded ? shadedBodyMat : wireBodyMat, BEES);
const beeEyes = new THREE.InstancedMesh(beeEyeGeo, eyeMat, BEES);
const beeOutline = new THREE.InstancedMesh(beeBodyGeo, outlineMat, BEES);
const wFillGeo = wingGeo(false), wRimGeo = wingGeo(true);
for (const g of [wFillGeo, wRimGeo]) { g.setAttribute('aFold', aFold); g.setAttribute('aFlap', aFlap); }
const beeWingFill = new THREE.InstancedMesh(wFillGeo, wingCrystalMat, BEES);
const beeWingRim = new THREE.InstancedMesh(wRimGeo, wingRimMat, BEES);
const beeMeshes = [beeBody, beeEyes, beeWingRim, beeWingFill, beeOutline];
beeBody.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
for (const m of beeMeshes) { m.instanceMatrix = beeBody.instanceMatrix; m.frustumCulled = false; scene.add(m); }
beeWingFill.renderOrder = 5; beeWingRim.renderOrder = 6;
beeBody.castShadow = true; beeBody.receiveShadow = true;
beeBody.setColorAt(0, grey(1)); beeEyes.setColorAt(0, grey(1));
const WR = P.widthRatio, WR0 = WR[0];
// switch the look. Shaded (default): lit metal, soft dawn shadows (if on), sky reflections (if on), outlined bees,
// crystal wings. Wireframe: edges only, unlit, no shadows.
let crystalOn = qs.get('crystal') !== '0';
function applyLook() {
  for (const o of SHADED_ONLY) o.visible = shaded;
  for (const o of WIRE_ONLY) o.visible = !shaded;
  for (const g of GROUNDS) g.material = shaded ? g.userData.solid : g.userData.wire;
  renderer.toneMapping = shaded ? THREE.ACESFilmicToneMapping : THREE.NoToneMapping;
  renderer.toneMappingExposure = 1.45;
  sun.castShadow = shaded && shadowsOn;
  beeBody.material = shaded ? shadedBodyMat : wireBodyMat;
  beeOutline.visible = shaded && outlineOn;
  beeWingFill.material = shaded && crystalOn ? wingCrystalMat : wingWireMat;
}
applyLook();
// per-bee orientation (3 x 3, columns X Y Z) and position, computed once per frame, then written as matrices for
// each view at that view's scale
const basis = new Float32Array(BEES * 9), bpos = new Float32Array(BEES * 3), prevPos = new Float32Array(BEES * 3);
let havePrev = false;

// A7 grip links (G): one line from each settled bee to each bee it holds (or to the conductor). Live state only.
const links = (() => {
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(BEES * 3 * 2 * 3), 3).setUsage(THREE.DynamicDrawUsage));
  geo.setAttribute('color', new THREE.BufferAttribute(new Float32Array(BEES * 3 * 2 * 3), 3).setUsage(THREE.DynamicDrawUsage));
  const l = new THREE.LineSegments(geo, new THREE.LineBasicMaterial({ vertexColors: true, fog: true, toneMapped: false }));
  l.frustumCulled = false; l.visible = false; l.renderOrder = 2;
  scene.add(l);
  return l;
})();
const _c = new THREE.Color();
function updateLinks(pos) {
  links.visible = showLinks && !pos;
  if (!links.visible) return;
  const st = sim.state, a = links.geometry.attributes.position.array, ca = links.geometry.attributes.color.array;
  let n = 0;
  for (let i = 0; i < BEES; i++) {
    const o = i * STRIDE; if (st[o + 16] !== 2) continue;
    const v0 = strandMode === 'off' || strand.root[i] < 0 ? 0.6 : Math.min(1, 0.25 + 0.75 * strandLevel(strand.root[i]) / 1.3);
    for (let gi = 0; gi < 3; gi++) {
      const v = st[o + 18 + gi]; if (v === -1) continue;
      for (let e = 0; e < 6; e++) ca[n + e] = v0;
      a[n++] = st[o]; a[n++] = st[o + 1]; a[n++] = st[o + 2];
      if (v === -2) {                                   // to the conductor, straight toward its axis
        a[n++] = st[o]; a[n++] = sim._soffitY(st[o]); a[n++] = st[o + 2];      // B1/C1: straight up to the timber
      } else { const q = v * STRIDE; a[n++] = st[q]; a[n++] = st[q + 1]; a[n++] = st[q + 2]; }
    }
  }
  links.geometry.setDrawRange(0, n / 3);
  links.geometry.attributes.position.needsUpdate = true;
  links.geometry.attributes.color.needsUpdate = true;
}

// ---------------------------------------------------------------- strands, shown by CONTRAST (A10; A9 used colour)
// A strand = all the bees that hang, grip by grip, from one bee holding the conductor (sim.strands()).
// 'contrast' (default): every strand gets its own brightness - dark iron, bright iron, and steps between - from a
//   golden-ratio sequence of its top bee's index, so neighbouring curtains differ in intensity; the bees' self-lit
//   eyes follow the same level, so the strands read as lines of light and dark through the cluster.
// 'chains': the 16 longest single chains (tip -> conductor) are lit bright with a bright line along each; every
//   other hanging bee goes dark and shrinks to a small speck so the chains stand out.
// 'off': plain iron.
const strand = { root: new Int32Array(BEES).fill(-1), parent: new Int32Array(BEES).fill(-1), depth: new Int32Array(BEES).fill(-1),
                 chain: new Int16Array(BEES), n: 0, strands: 0, chains: [] };
const NCHAINS = 16;
const LEVELS = [0.12, 0.38, 0.75, 1.2, 1.8];
function strandLevel(root) {                         // 5 brightness steps, neighbours far apart
  if (root === 0) return 1.6;                        // the queen's own strand: brightest
  return LEVELS[Math.floor(((root * 0.6180339887498949) % 1) * LEVELS.length)];
}
function computeStrands(pos) {
  if (!pos) strand.n = sim.strands(strand.root, strand.parent, strand.depth);
  else { const f = Math.round((displayStep - rewind.block) / GRAN);
    strand.root.set(rewind.root[f]); strand.parent.set(rewind.parent[f]); strand.depth.set(rewind.depth[f]); }
  const roots = new Set(); for (let i = 0; i < BEES; i++) if (strand.root[i] >= 0) roots.add(strand.root[i]);
  strand.strands = roots.size;
  strand.chain.fill(0); strand.chains.length = 0;
  if (strandMode !== 'chains') return;
  const tips = [];
  for (let i = 0; i < BEES; i++) if (strand.depth[i] > 2) tips.push(i);
  tips.sort((a, b) => strand.depth[b] - strand.depth[a] || a - b);
  const used = new Set();
  for (const t of tips) {
    if (strand.chains.length >= NCHAINS) break;
    const r = strand.root[t]; if (r < 0 || used.has(r) || strand.chain[t]) continue;
    used.add(r);
    const k = strand.chains.length + 1, path = [];
    for (let j = t, guard = 0; j >= 0 && guard < 200; j = strand.parent[j], guard++) { strand.chain[j] = k; path.push(j); }
    strand.chains.push(path);
  }
}
const chainLines = (() => {
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(NCHAINS * 220 * 6), 3).setUsage(THREE.DynamicDrawUsage));
  const l = new THREE.LineSegments(geo, new THREE.LineBasicMaterial({ color: 0xffffff, fog: true, toneMapped: false }));
  l.frustumCulled = false; l.visible = false; l.renderOrder = 3; scene.add(l); return l;
})();
function updateChainLines(pos) {
  chainLines.visible = strandMode === 'chains' && strand.chains.length > 0;
  if (!chainLines.visible) return;
  const a = chainLines.geometry.attributes.position.array, st = sim.state;
  const P3 = (i, k) => pos ? pos[i * 3 + k] : st[i * STRIDE + k];
  let n = 0;
  for (const path of strand.chains) for (let m = 0; m < path.length && n < a.length - 6; m++) {
    const i = path[m], j = m + 1 < path.length ? path[m + 1] : -1;
    a[n] = P3(i, 0); a[n + 1] = P3(i, 1); a[n + 2] = P3(i, 2);
    if (j >= 0) { a[n + 3] = P3(j, 0); a[n + 4] = P3(j, 1); a[n + 5] = P3(j, 2); }
    else { a[n + 3] = a[n]; a[n + 4] = sim._soffitY(a[n]); a[n + 5] = a[n + 2]; }
    n += 6;
  }
  chainLines.geometry.setDrawRange(0, n / 3);
  chainLines.geometry.attributes.position.needsUpdate = true;
}
// brightness of each bee's iron (instance colour) and of its eyes
function applyColours(pos) {
  const st = sim.state;
  for (let i = 0; i < BEES; i++) {
    const o = i * STRIDE, caste = st[o + 17], settled = st[o + 16] === 2;
    let body = 1, eye = settled ? 0.55 : 0.8;
    if (casteColours) body *= caste === 2 ? 1.9 : caste === 1 ? 1.35 : 0.8;
    else if (caste === 2) { body *= 1.5; eye = 1.2; }                   // the queen is always a little brighter
    if (showLoad) {
      const held = settled ? st[o + 21] / st[o + 22] : -1;
      body = held < 0 ? 0.25 : 0.2 + 1.5 * Math.min(1, Math.sqrt(held)); eye = body * 0.6;
    } else if (strandMode === 'contrast' && strand.root[i] >= 0) {
      const L = strandLevel(strand.root[i]); body *= L; eye = 0.15 + 0.55 * L;
    } else if (strandMode === 'chains' && strand.root[i] >= 0) {
      if (strand.chain[i]) { body *= 2.0; eye = 1.4; } else { body *= 0.18; eye = 0.05; }
    }
    beeBody.setColorAt(i, _c.setRGB(body, body, body));
    beeEyes.setColorAt(i, _c.setRGB(eye, eye, eye));
  }
  beeBody.instanceColor.needsUpdate = true; beeEyes.instanceColor.needsUpdate = true;
}

// ---------------------------------------------------------------- rewind cache
// Running backwards: positions for one checkpoint block are simulated once and kept (Float32) so each
// backward frame is instant. Resuming forward does an exact sim.seek(), so determinism is untouched.
const GRAN = 2;                      // keep every 2nd step of the block (~36 MB for 10,000 bees)
const rewind = { block: -1, pos: null, census: null, root: null, parent: null, depth: null };
function ensureRewindBlock(step) {
  const block = Math.floor(step / CHECKPOINT_EVERY) * CHECKPOINT_EVERY;
  if (rewind.block === block) return;
  note('Rewinding… (computing this 5-second block once)');
  const n = CHECKPOINT_EVERY / GRAN + 1;
  if (!rewind.pos) { rewind.pos = []; rewind.census = []; rewind.root = []; rewind.parent = []; rewind.depth = []; }
  rewind.pos.length = 0; rewind.census.length = 0; rewind.root.length = 0; rewind.parent.length = 0; rewind.depth.length = 0;
  sim.seek(block);
  for (let k = 0; k < n; k++) {
    const f = new Float32Array(BEES * 3), st = sim.state;
    for (let i = 0; i < BEES; i++) { const o = i * STRIDE; f[i * 3] = st[o]; f[i * 3 + 1] = st[o + 1]; f[i * 3 + 2] = st[o + 2]; }
    rewind.pos.push(f); rewind.census.push(sim.census());
    sim.strands(strand.root, strand.parent, strand.depth);                 // A9: strands for the colours (derived only)
    rewind.root.push(Int32Array.from(strand.root)); rewind.parent.push(Int32Array.from(strand.parent)); rewind.depth.push(Int16Array.from(strand.depth));
    if (k < n - 1) sim.seek(sim.step + GRAN);
  }
  rewind.block = block;
}
function viewPositions() {
  if (displayStep === sim.step) return null;          // read straight from sim.state
  ensureRewindBlock(displayStep);
  return rewind.pos[Math.round((displayStep - rewind.block) / GRAN)];
}

// ---------------------------------------------------------------- camera (A8)
// Two modes (A key / Camera button):
//  * AUTO  - the A7 point of view (fixed, 6 ft above the ground) but aimed at the QUEEN, not at the median of
//            the bees. Aim and zoom follow critically-damped springs, and the zoom only moves when the framing
//            it wants differs by more than a dead band, so the picture no longer jiggles with the milling cloud.
//  * ORBIT - the camera circles the queen / swarm: drag to orbit, mouse wheel or the Distance slider (or [ ])
//            to change the distance, O for a slow automatic orbit. Dragging or touching the slider in AUTO
//            switches to ORBIT, starting from where the auto camera was.
// Springs run per film frame (1/30 s), so a recorded movie looks the same whatever the PC's speed.
const FRAME_DT = 1 / 30;
const AIM_OMEGA = 1.1, FOV_OMEGA = 0.7, DIST_OMEGA = 7;   // rad/s; ~1 s settle for the aim, ~1.5 s for the zoom
const FOV_DEADBAND = 0.10;                                  // zoom retargets only when the framing is >10 % off
const ORBIT_FOV = 50, DIST_MIN = 1.0, DIST_MAX = 250;
function spring(s, target, omega, dt) {                     // critically damped, implicit (stable at any dt)
  const f = 1 + 2 * dt * omega, oo = omega * omega, hoo = dt * oo, hhoo = dt * hoo, det = 1 / (f + hhoo);
  const x = (f * s.x + dt * s.v + hhoo * target) * det;
  s.v = (s.v + hoo * (target - s.x)) * det; s.x = x;
}
const sp = () => ({ x: 0, v: 0 });
const aimS = [sp(), sp(), sp()], fovS = sp(), distS = sp();
let camMode = qs.get('cam') === 'orbit' ? 'orbit' : 'auto';
let orbitAz = 0, orbitEl = 0.05, orbitDist = parseFloat(qs.get('dist') ?? '20'), orbitSpin = false;
let fovTarget = 60, fov = 60, exag = 1, cloudWidth = 0;
const aim = SITE.clone();
// C5: what the camera looks at - T cycles the queen (top of the cluster) / the cluster's centre / its lowest tip;
// right-drag or shift-drag PANS the view (an offset added to that point), double-click clears the pan.
const AIMS = HOVER ? ['queen', 'centre'] : ['queen', 'centre', 'tip'];
const AIM_NAME = HOVER ? { queen: 'the queen', centre: 'the ball centre' } : { queen: 'the queen', centre: 'the cluster centre', tip: 'the cluster tip' };
let aimMode = AIMS.includes(qs.get('aim')) ? qs.get('aim') : 'queen';
const panOff = new THREE.Vector3();
// C5: box around the settled, hanging bees as displayed (for the aim and the close-up framing)
const SB = { n: 0, x0: 0, x1: 0, y0: 0, y1: 0, z0: 0, z1: 0, r50: 0, r90: 0 };
// CT52 (option 5): the box around the FLYING BALL, each axis 2nd-98th percentile; radii holding half / 90 %
const _bx = HOVER ? new Float32Array(BEES) : null, _by = HOVER ? new Float32Array(BEES) : null, _bz = HOVER ? new Float32Array(BEES) : null, _br = HOVER ? new Float32Array(BEES) : null, _bc = HOVER ? new Float32Array(BEES) : null;
function ballBox(pos) {
  const st = sim.state, qx = pos ? pos[0] : st[0], qy = pos ? pos[1] : st[1], qz = pos ? pos[2] : st[2];
  const lim2 = P.ballLeave * P.ballLeave, queenOn = pos ? displayStep * DT > P.queenSettle : st[16] === 3;
  let n = 0;
  if (queenOn) for (let i = 1; i < BEES; i++) {
    const x = pos ? pos[i * 3] : st[i * STRIDE], y = pos ? pos[i * 3 + 1] : st[i * STRIDE + 1], z = pos ? pos[i * 3 + 2] : st[i * STRIDE + 2];
    const ex = x - qx, ey = y - qy, ez = z - qz, d2 = ex * ex + ey * ey + ez * ez;
    if (pos ? d2 > lim2 : st[i * STRIDE + 16] !== 3) continue;
    _bx[n] = x; _by[n] = y; _bz[n] = z; _br[n] = Math.sqrt(d2); n++;
  }
  if (n < 30) { Object.assign(SB, { n, x0: qx, x1: qx, y0: qy, y1: qy, z0: qz, z1: qz, r50: 0, r90: 0, c90: 0, cx: qx, cy: qy, cz: qz }); return; }
  let mx = 0, my = 0, mz = 0; for (let k = 0; k < n; k++) { mx += _bx[k]; my += _by[k]; mz += _bz[k]; } mx /= n; my /= n; mz /= n;
  for (let k = 0; k < n; k++) _bc[k] = Math.hypot(_bx[k] - mx, _by[k] - my, _bz[k] - mz);
  const q = (a, f) => a[Math.floor(f * (n - 1))];
  SB.c90 = q(_bc.subarray(0, n).sort(), 0.9); SB.cx = mx; SB.cy = my; SB.cz = mz;
  const xs = _bx.subarray(0, n).sort(), ys = _by.subarray(0, n).sort(), zs = _bz.subarray(0, n).sort(), rs = _br.subarray(0, n).sort();
  Object.assign(SB, { n, x0: q(xs, 0.02), x1: q(xs, 0.98), y0: q(ys, 0.02), y1: q(ys, 0.98), z0: q(zs, 0.02), z1: q(zs, 0.98), r50: q(rs, 0.5), r90: q(rs, 0.9) });
}
function settledBox(pos) {
  if (HOVER) return ballBox(pos);
  const st = sim.state, yTop = ATTACH_Y + P.beamSag + 0.3, yBot = ATTACH_Y - 8;
  let n = 0, x0 = 1e9, x1 = -1e9, y0 = 1e9, y1 = -1e9, z0 = 1e9, z1 = -1e9;
  for (let i = 0; i < BEES; i++) {
    if (st[i * STRIDE + 16] !== 2) continue;
    const x = pos ? pos[i * 3] : st[i * STRIDE], y = pos ? pos[i * 3 + 1] : st[i * STRIDE + 1], z = pos ? pos[i * 3 + 2] : st[i * STRIDE + 2];
    if (y > yTop || y < yBot || Math.abs(x - P.siteX) > P.arborHalf || Math.abs(z - P.siteZ) > 3) continue;   // (while rewinding: not yet there)
    n++; if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; if (z < z0) z0 = z; if (z > z1) z1 = z;
  }
  Object.assign(SB, { n, x0, x1, y0, y1, z0, z1 });
}
function aimBase(pos, out) {
  if (aimMode !== 'queen' && SB.n >= 30)
    return out.set((SB.x0 + SB.x1) / 2, aimMode === 'centre' || HOVER ? (SB.y0 + SB.y1) / 2 : SB.y0, (SB.z0 + SB.z1) / 2);
  return queenPos(pos, out);
}
const _v = new THREE.Vector3(), _f = new THREE.Vector3(), _r = new THREE.Vector3(), _u = new THREE.Vector3();
const SAMPLE = Math.max(1, Math.floor(BEES / 700));
function queenPos(pos, out) {                               // the queen is bee 0
  return pos ? out.set(pos[0], pos[1], pos[2]) : out.set(sim.state[0], sim.state[1], sim.state[2]);
}
function setCamMode(m) {
  if (m === camMode) return;
  if (m === 'orbit') {                                      // start the orbit where the camera is now
    _v.copy(camera.position).sub(aim);
    orbitDist = Math.min(DIST_MAX, Math.max(DIST_MIN, _v.length()));
    orbitAz = Math.atan2(_v.x, _v.z);
    orbitEl = Math.asin(Math.max(-1, Math.min(1, _v.y / orbitDist)));
    distS.x = orbitDist; distS.v = 0;
  }
  camMode = m; syncDistSlider(); refreshButtons(); poke();
}
function frameCamera(pos, snap) {
  const st = sim.state, dt = FRAME_DT;
  const get = (i, out) => pos ? out.set(pos[i * 3], pos[i * 3 + 1], pos[i * 3 + 2])
                              : out.set(st[i * STRIDE], st[i * STRIDE + 1], st[i * STRIDE + 2]);
  // 1) aim: the queen (C5: or the cluster's centre / tip), smoothed; plus the user's pan, applied directly
  aimBase(pos, _v);
  const tgt = [_v.x, _v.y, _v.z];
  for (let k = 0; k < 3; k++) { if (snap) { aimS[k].x = tgt[k]; aimS[k].v = 0; } else spring(aimS[k], tgt[k], AIM_OMEGA, dt); }
  aim.set(aimS[0].x, aimS[1].x, aimS[2].x).add(panOff);
  // 2) where the camera stands
  if (camMode === 'auto') camera.position.copy(CAM_POS);
  else {
    if (orbitSpin && direction !== 0) orbitAz += 0.06 * dt;                   // slow automatic orbit (~1.7 min per turn)
    if (snap) { distS.x = orbitDist; distS.v = 0; } else spring(distS, orbitDist, DIST_OMEGA, dt);
    const d = distS.x, ce = Math.cos(orbitEl);
    camera.position.set(aim.x + d * ce * Math.sin(orbitAz), aim.y + d * Math.sin(orbitEl), aim.z + d * ce * Math.cos(orbitAz));
    if (camera.position.y < 0.4) camera.position.y = 0.4;                       // never below the ground
  }
  camera.lookAt(aim);
  const camDist = aim.distanceTo(camera.position);
  camera.near = Math.max(0.02, Math.min(0.3, camDist * 0.05));
  // 3) how wide the swarm is (HUD) and, in AUTO, the zoom that frames 90 % of it around the queen
  _f.copy(aim).sub(camera.position).normalize();
  _r.crossVectors(_f, camera.up).normalize();
  _u.crossVectors(_r, _f);
  const xs = [], zs = [], tx = [], ty = [];
  for (let i = 0; i < BEES; i += SAMPLE) {
    get(i, _v); xs.push(_v.x); zs.push(_v.z);
    _v.sub(camera.position);
    const z = _v.dot(_f); if (z < 1) continue;
    tx.push(Math.abs(_v.dot(_r) / z)); ty.push(Math.abs(_v.dot(_u) / z));
  }
  const med = a => { const b = a.slice().sort((p, q) => p - q); return b[b.length >> 1]; };
  const p90 = a => { a.sort((p, q) => p - q); return a[Math.floor(0.9 * (a.length - 1))] || 0; };
  const mx = med(xs), mz = med(zs);
  cloudWidth = 2 * p90(xs.map((x, k) => Math.hypot(x - mx, zs[k] - mz)));
  let want;
  if (camMode === 'orbit') want = ORBIT_FOV;
  else if (autoZoom) {
    const need = Math.max(p90(ty), p90(tx) / camera.aspect) * 1.3;
    const minHalf = (Math.max(CL.length, CL.width, 0.4) / 2) / camDist / 0.07;   // A10 wide shot: the cluster fills at most ~7 % of the height
    want = Math.min(70, 2 * Math.atan(Math.max(need, minHalf)) * 180 / Math.PI);
  } else want = 60;
  // dead band: hold the zoom until the framing it wants is clearly different (stops the breathing / jiggle)
  if (snap || camMode === 'orbit' || !autoZoom || Math.abs(want - fovTarget) > FOV_DEADBAND * fovTarget) fovTarget = want;
  if (snap) { fovS.x = fovTarget; fovS.v = 0; } else spring(fovS, fovTarget, FOV_OMEGA, dt);
  fov = Math.max(1, fovS.x);
  camera.fov = fov;
  camera.updateProjectionMatrix();
  // how many pixels a typical worker covers at the queen's distance
  const pxPerFt = H / (2 * camDist * Math.tan(fov * Math.PI / 360));
  const workerPx = P.workerMean * FT_PER_MM * pxPerFt;
  exag = exaggerate ? Math.max(1, MIN_BEE_PX / workerPx) : 1;
}

// ---- orbit input: drag = orbit, wheel = distance, Distance slider, [ ] keys
const distSlider = document.getElementById('dist');
const D2S = d => Math.round(1000 * Math.log(d / DIST_MIN) / Math.log(DIST_MAX / DIST_MIN));
const S2D = v => DIST_MIN * Math.pow(DIST_MAX / DIST_MIN, v / 1000);
function syncDistSlider() {
  const d = camMode === 'orbit' ? orbitDist : aim.distanceTo(CAM_POS);
  distSlider.value = D2S(d);
  document.getElementById('distVal').textContent = d.toFixed(d < 10 ? 1 : 0) + ' ft';
}
function setDist(d) { setCamMode('orbit'); orbitDist = Math.min(DIST_MAX, Math.max(DIST_MIN, d)); syncDistSlider(); poke(); }
distSlider.addEventListener('input', () => setDist(S2D(+distSlider.value)));
let drag = null;
canvas.addEventListener('pointerdown', (e) => {
  if (e.button !== 0 && e.button !== 2) return;
  const pan = e.button === 2 || e.shiftKey;                 // C5: right-drag / shift-drag pans
  if (!pan) setCamMode('orbit');
  drag = { x: e.clientX, y: e.clientY, id: e.pointerId, pan }; canvas.setPointerCapture(e.pointerId);
  canvas.style.cursor = pan ? 'move' : 'grabbing';
});
canvas.addEventListener('pointermove', (e) => {
  if (!drag || e.pointerId !== drag.id) return;
  const dx = e.clientX - drag.x, dy = e.clientY - drag.y; drag.x = e.clientX; drag.y = e.clientY;
  if (drag.pan) {                                           // move the look-at point across the screen, at its depth
    const ftPerPx = 2 * aim.distanceTo(camera.position) * Math.tan(camera.fov * Math.PI / 360) / Math.max(1, Math.min(canvas.clientHeight, canvas.clientWidth * H / W));
    _r.setFromMatrixColumn(camera.matrixWorld, 0); _u.setFromMatrixColumn(camera.matrixWorld, 1);
    panOff.addScaledVector(_r, -dx * ftPerPx).addScaledVector(_u, dy * ftPerPx);
    if (panOff.length() > 40) panOff.setLength(40);
  } else {
    orbitAz -= dx * 0.006;
    orbitEl = Math.max(-1.2, Math.min(1.5, orbitEl + dy * 0.006));   // C5: down to ~70 deg below (look up into the chains)
  }
  poke();
});
canvas.addEventListener('contextmenu', (e) => e.preventDefault());
canvas.addEventListener('dblclick', () => { panOff.set(0, 0, 0); poke(); });
const endDrag = () => { drag = null; canvas.style.cursor = ''; };
canvas.addEventListener('pointerup', endDrag); canvas.addEventListener('pointercancel', endDrag);
canvas.addEventListener('wheel', (e) => { e.preventDefault(); setDist((camMode === 'orbit' ? orbitDist : aim.distanceTo(CAM_POS)) * Math.exp(e.deltaY * 0.0012)); }, { passive: false });

// ---------------------------------------------------------------- A10: bee orientation, wings, matrices
// Flying bees point along their heading (back up). Hanging bees point their head at the hold they follow up their
// strand (the bee above, or the conductor), back turned out from the cluster's axis. Wings: spread and beating in
// flight (the stroke is sampled at a different phase every frame - the eye sees a blur of positions, as with real
// 230 Hz wings filmed at 30 fps), folded over the abdomen when hanging, spread and fanning on Nasonov fanners.
function orientBees(pos) {
  const st = sim.state, B = basis;
  const fold = aFold.array, flap = aFlap.array, ph = displayStep * 2.39996;
  for (let i = 0; i < BEES; i++) {
    const o = i * STRIDE;
    const x = pos ? pos[i * 3] : st[o], y = pos ? pos[i * 3 + 1] : st[o + 1], z = pos ? pos[i * 3 + 2] : st[o + 2];
    const hanging = pos ? strand.root[i] >= 0 : st[o + 16] === 2;
    let zx, zy, zz, ux, uy, uz;
    if (hanging) {
      const par = strand.parent[i];
      ux = x - CL.cx; uy = 0; uz = z - CL.cz;
      if (ux * ux + uz * uz < 1e-8) { ux = 0; uz = 1; }
      if (sim.shell && sim.shell[i]) {                       // C7: shell bees face up, like shingles, leaning a little out
        const hn = Math.hypot(ux, uz); zx = 0.3 * ux / hn; zy = 1; zz = 0.3 * uz / hn;
      } else if (par >= 0) { zx = (pos ? pos[par * 3] : st[par * STRIDE]) - x; zy = (pos ? pos[par * 3 + 1] : st[par * STRIDE + 1]) - y; zz = (pos ? pos[par * 3 + 2] : st[par * STRIDE + 2]) - z; }
      else { zx = 0; zy = 1; zz = 0; }
      const fan = !pos && st[o + 13] === 1;
      fold[i] = fan ? 0.45 : 1; flap[i] = fan ? 0.35 + 0.35 * Math.sin(ph * 1.3 + i * 1.7) : 0.06;
    } else {
      if (!pos) { zx = st[o + 3]; zy = st[o + 4]; zz = st[o + 5]; }
      else if (havePrev) { zx = x - prevPos[i * 3]; zy = y - prevPos[i * 3 + 1]; zz = z - prevPos[i * 3 + 2]; }
      else { zx = 1; zy = 0; zz = 0; }
      ux = 0; uy = 1; uz = 0;
      fold[i] = 0.06; flap[i] = 0.75 * Math.sin(ph + i * 2.3999);
    }
    let n = Math.hypot(zx, zy, zz); if (n < 1e-9) { zx = 0; zy = 1; zz = 0; n = 1; }
    zx /= n; zy /= n; zz /= n;
    let d = ux * zx + uy * zy + uz * zz; ux -= d * zx; uy -= d * zy; uz -= d * zz;
    n = Math.hypot(ux, uy, uz);
    if (n < 1e-6) { ux = 1 - zx * zx; uy = -zx * zy; uz = -zx * zz; n = Math.hypot(ux, uy, uz) || 1; }
    ux /= n; uy /= n; uz /= n;
    const k = i * 9;
    B[k] = uy * zz - uz * zy; B[k + 1] = uz * zx - ux * zz; B[k + 2] = ux * zy - uy * zx;   // X = Y x Z
    B[k + 3] = ux; B[k + 4] = uy; B[k + 5] = uz; B[k + 6] = zx; B[k + 7] = zy; B[k + 8] = zz;
    bpos[i * 3] = x; bpos[i * 3 + 1] = y; bpos[i * 3 + 2] = z;
  }
  if (pos) { prevPos.set(pos); havePrev = true; } else havePrev = false;
  aFold.needsUpdate = true; aFlap.needsUpdate = true;
}
function writeMatrices(ex) {
  const a = beeBody.instanceMatrix.array, st = sim.state, B = basis;
  for (let i = 0; i < BEES; i++) {
    const o = i * STRIDE, L = st[o + 7], c = st[o + 17], k = i * 9, m = i * 16;
    let f = ex;
    if (strandMode === 'chains' && strand.root[i] >= 0 && !strand.chain[i]) f *= 0.4;   // chains view: the rest shrink
    const sz = L * f, sxy = sz * WR[c] / WR0;
    a[m] = B[k] * sxy; a[m + 1] = B[k + 1] * sxy; a[m + 2] = B[k + 2] * sxy; a[m + 3] = 0;
    a[m + 4] = B[k + 3] * sxy; a[m + 5] = B[k + 4] * sxy; a[m + 6] = B[k + 5] * sxy; a[m + 7] = 0;
    a[m + 8] = B[k + 6] * sz; a[m + 9] = B[k + 7] * sz; a[m + 10] = B[k + 8] * sz; a[m + 11] = 0;
    a[m + 12] = bpos[i * 3]; a[m + 13] = bpos[i * 3 + 1]; a[m + 14] = bpos[i * 3 + 2]; a[m + 15] = 1;
  }
  beeBody.instanceMatrix.needsUpdate = true;
}

// ---------------------------------------------------------------- A10: the close-up window (picture in picture)
// A second, smaller view in the lower right of the same picture (so it is in recorded movies too): it looks at the
// forming cluster (before there is one, at the queen) from about twice the cluster's size away, circling it slowly,
// with bees at their true size. P hides / shows it.
const pipCam = new THREE.PerspectiveCamera(32, 16 / 9, 0.02, 3000);
const PIP = { w: Math.round(W * 0.31) };
PIP.h = Math.round(PIP.w * 9 / 16); PIP.x = W - PIP.w - 16; PIP.y = 16;
pipCam.aspect = PIP.w / PIP.h; pipCam.updateProjectionMatrix();
const pipAimS = [sp(), sp(), sp()], pipDistS = sp();
let pipAz = 0.35, pipExag = 1, pipDist = 1;
function framePip(pos, snap) {
  // C5: as close as it can be while the WHOLE settled, hanging swarm stays in the window: it looks at the centre of
  // the box around the settled bees (grown by a bee's length) and stands at the distance where all eight corners of
  // that box, seen from the close-up's current direction, fall inside 92 % of the window. (A11-C4: 5 x the size.)
  let tx, ty, tz, hx, hy, hz;
  if (SB.n >= 30) { tx = (SB.x0 + SB.x1) / 2; ty = (SB.y0 + SB.y1) / 2; tz = (SB.z0 + SB.z1) / 2;
    hx = (SB.x1 - SB.x0) / 2 + 0.05; hy = (SB.y1 - SB.y0) / 2 + 0.05; hz = (SB.z1 - SB.z0) / 2 + 0.05; }
  else { queenPos(pos, _v); tx = _v.x; ty = _v.y; tz = _v.z; hx = hy = hz = 0.25; }
  const el0 = HOVER ? -0.18 : -0.55, ox = Math.cos(el0) * Math.sin(pipAz), oy = Math.sin(el0), oz = Math.cos(el0) * Math.cos(pipAz);
  _f.set(-ox, -oy, -oz); _r.crossVectors(_f, pipCam.up).normalize(); _u.crossVectors(_r, _f);
  const tv = 0.92 * Math.tan(pipCam.fov * Math.PI / 360), th = tv * pipCam.aspect;
  let need = 0.5;
  for (let c = 0; c < 8; c++) {
    _v.set(c & 1 ? hx : -hx, c & 2 ? hy : -hy, c & 4 ? hz : -hz);
    const cf = _v.dot(_f);
    need = Math.max(need, cf + Math.abs(_v.dot(_r)) / th, cf + Math.abs(_v.dot(_u)) / tv);
  }
  const tgt = [tx, ty, tz], want = Math.min(18, need);
  for (let k = 0; k < 3; k++) { if (snap) { pipAimS[k].x = tgt[k]; pipAimS[k].v = 0; } else spring(pipAimS[k], tgt[k], 1.4, FRAME_DT); }
  if (snap) { pipDistS.x = want; pipDistS.v = 0; } else spring(pipDistS, want, 0.8, FRAME_DT);
  if (direction !== 0) pipAz += 0.11 * FRAME_DT;                       // one turn every ~57 s
  const d = pipDist = pipDistS.x, el = HOVER ? -0.18 : -0.55;   // CT52: option 5 sees the ball against the sea                         // B2: from below, looking up (A10-B1: +7 deg)
  pipCam.position.set(pipAimS[0].x + d * Math.cos(el) * Math.sin(pipAz), Math.max(0.6, pipAimS[1].x + d * Math.sin(el)), pipAimS[2].x + d * Math.cos(el) * Math.cos(pipAz));
  pipCam.lookAt(pipAimS[0].x, pipAimS[1].x, pipAimS[2].x);
  pipCam.near = Math.max(0.01, d * 0.04); pipCam.updateProjectionMatrix();
  const pxPerFt = PIP.h / (2 * d * Math.tan(pipCam.fov * Math.PI / 360));
  pipExag = exaggerate ? Math.max(1, 2.5 / (P.workerMean * FT_PER_MM * pxPerFt)) : 1;
}
const PIP_EDGE = new THREE.Color(0x777a80), BLACK_C = new THREE.Color(0x000000);
function renderViews() {
  renderer.setScissorTest(false); renderer.setViewport(0, 0, W, H);
  renderer.setClearColor(BLACK_C); renderer.clear();
  writeMatrices(exag);
  renderer.shadowMap.needsUpdate = shaded && shadowsOn;
  if (beesHidden) {                                         // C6: the empty scene behind the captions
    const vis = beeMeshes.map(m => m.visible), lines = chainLines.visible;
    for (const m of beeMeshes) m.visible = false; chainLines.visible = false;
    renderer.render(scene, camera);
    beeMeshes.forEach((m, k) => { m.visible = vis[k]; }); chainLines.visible = lines;
    return;
  }
  renderer.render(scene, camera);
  if (!showPip) return;
  writeMatrices(pipExag);
  renderer.shadowMap.needsUpdate = shaded && shadowsOn;
  renderer.setScissorTest(true);
  renderer.setScissor(PIP.x - 3, PIP.y - 3, PIP.w + 6, PIP.h + 6); renderer.setClearColor(PIP_EDGE); renderer.clear();
  renderer.setScissor(PIP.x, PIP.y, PIP.w, PIP.h); renderer.setViewport(PIP.x, PIP.y, PIP.w, PIP.h);
  renderer.setClearColor(BLACK_C); renderer.clear();
  renderer.render(scene, pipCam);
  renderer.setScissorTest(false); renderer.setViewport(0, 0, W, H);
}

// ---------------------------------------------------------------- sound of the bees (A8)
// Synthesised live with the Web Audio API (no sound files, nothing from the internet). See SCIENCE.md section 7b.
//  * The CLOUD: a chorus of detuned buzzing tones (wingbeat ~190-250 Hz plus harmonics) and band-passed noise.
//    N bees buzzing independently add up in POWER, so the level goes as sqrt(N) / distance: it is loud while the
//    swarm is airborne and drops to a quieter hum of the fanning cluster once the bees have settled.
//  * NEAR BEES: the 16 flying bees closest to the camera each get their own voice - pitch from the bee's caste
//    and size, loudness 1/distance, left/right from where it is on screen, and a Doppler shift from its speed
//    toward or away from the camera (so orbit in close and they whizz past).
// Browsers only allow sound after a click or a key press: the first click/key anywhere switches it on.
const Sound = (() => {
  const NEAR = 16, BED = 10, C_SOUND = 1125;                // voices; speed of sound, ft/s
  let ctx = null, master, bedGain, noiseGain, hissGain, near = [], on = qs.get('sound') !== '0', vol = 0.7, frameNo = 0;
  const nearest = new Int32Array(NEAR), nearD = new Float64Array(NEAR);
  function beeWave(c) {                                     // a buzz: strong fundamental, falling harmonics
    const n = 14, re = new Float32Array(n), im = new Float32Array(n);
    for (let h = 1; h < n; h++) im[h] = Math.pow(h, -1.15) * (h % 2 ? 1 : 0.8);
    return c.createPeriodicWave(re, im);
  }
  function start() {
    if (ctx) { if (ctx.state !== 'running') ctx.resume(); return; }
    const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return;
    ctx = new AC();
    const wave = beeWave(ctx);
    master = ctx.createGain(); master.gain.value = 0;
    const comp = ctx.createDynamicsCompressor(); comp.threshold.value = -14; comp.ratio.value = 4;
    master.connect(comp).connect(ctx.destination);
    // the cloud chorus
    bedGain = ctx.createGain(); bedGain.gain.value = 0;
    const bedLP = ctx.createBiquadFilter(); bedLP.type = 'lowpass'; bedLP.frequency.value = 1400; bedLP.Q.value = 0.4;
    bedGain.connect(bedLP).connect(master);
    for (let k = 0; k < BED; k++) {
      const o = ctx.createOscillator(); o.setPeriodicWave(wave);
      o.frequency.value = 196 + 60 * (k + 0.5) / BED;          // spread over the worker/drone wingbeat range
      const lfo = ctx.createOscillator(), lg = ctx.createGain();   // slow wander of each tone (+-25 cents)
      lfo.frequency.value = 0.13 + 0.17 * Math.random(); lg.gain.value = 25;
      lfo.connect(lg).connect(o.detune);
      const g = ctx.createGain(); g.gain.value = 1 / BED;
      const pan = ctx.createStereoPanner(); pan.pan.value = (k / (BED - 1)) * 1.4 - 0.7;
      o.connect(g).connect(pan).connect(bedGain);
      o.start(); lfo.start();
    }
    // rushing noise of thousands of wings: band-passed around the wingbeat band, plus a faint 5 kHz hiss
    const nb = ctx.createBuffer(2, ctx.sampleRate * 4, ctx.sampleRate);
    for (let ch = 0; ch < 2; ch++) { const d = nb.getChannelData(ch); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1; }
    const noise = ctx.createBufferSource(); noise.buffer = nb; noise.loop = true;
    const bp = ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 260; bp.Q.value = 0.9;
    noiseGain = ctx.createGain(); noiseGain.gain.value = 0;
    noise.connect(bp).connect(noiseGain).connect(master);
    const hp = ctx.createBiquadFilter(); hp.type = 'bandpass'; hp.frequency.value = 5000; hp.Q.value = 1.2;
    hissGain = ctx.createGain(); hissGain.gain.value = 0;
    noise.connect(hp).connect(hissGain).connect(master);
    noise.start();
    // individual near bees
    for (let k = 0; k < NEAR; k++) {
      const o = ctx.createOscillator(); o.setPeriodicWave(wave); o.frequency.value = 230;
      const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 3000;
      const g = ctx.createGain(); g.gain.value = 0;
      const pan = ctx.createStereoPanner();
      o.connect(lp).connect(g).connect(pan).connect(master); o.start();
      near.push({ o, g, pan, bee: -1 });
    }
  }
  const baseHz = (i) => {                                   // wingbeat of bee i: caste and size (smaller = higher)
    const o = i * STRIDE, c = sim.state[o + 17], L = sim.state[o + 7] / FT_PER_MM;
    if (c === 1) return 200 * (16 / L);                      // drones: lower, ~190-210 Hz
    if (c === 2) return 215;                                  // queen
    return 235 * Math.pow(12.8 / L, 1.5);                     // workers ~ 200-270 Hz around 235
  };
  const _w = new THREE.Vector3(), _cr = new THREE.Vector3();
  function update(pos) {
    if (!ctx) return;
    const now = ctx.currentTime, st = sim.state, cam = camera.position;
    const running = on && direction !== 0 && !finished;
    master.gain.setTargetAtTime(running ? vol : 0, now, running ? 0.8 : 0.12);
    if (!running) return;
    // census of who is flying and how far away the swarm is
    let fly = 0, setl = 0;
    for (let i = 0; i < BEES; i++) st[i * STRIDE + 16] === 2 ? setl++ : fly++;
    const dSwarm = Math.max(2, aim.distanceTo(cam));
    const ref = Math.sqrt(12000) / 40;                       // 12,000 flying bees 40 ft away = level 1
    const lvl = (Math.sqrt(fly) + 0.35 * Math.sqrt(setl)) / dSwarm / ref;   // settled bees: fanning hum, quieter
    const L = Math.min(1.6, lvl);
    bedGain.gain.setTargetAtTime(0.32 * L, now, 0.3);
    noiseGain.gain.setTargetAtTime(0.55 * L * (0.4 + 0.6 * fly / BEES), now, 0.3);
    hissGain.gain.setTargetAtTime(0.025 * L, now, 0.3);
    // nearest flying bees -> voices (search every 2nd frame)
    if ((frameNo++ & 1) === 0) {
      nearD.fill(Infinity); nearest.fill(-1);
      for (let i = 0; i < BEES; i++) {
        const o = i * STRIDE; if (st[o + 16] === 2) continue;
        const x = (pos ? pos[i * 3] : st[o]) - cam.x, y = (pos ? pos[i * 3 + 1] : st[o + 1]) - cam.y, z = (pos ? pos[i * 3 + 2] : st[o + 2]) - cam.z;
        const d2 = x * x + y * y + z * z;
        if (d2 >= nearD[NEAR - 1]) continue;
        let k = NEAR - 1; while (k > 0 && nearD[k - 1] > d2) { nearD[k] = nearD[k - 1]; nearest[k] = nearest[k - 1]; k--; }
        nearD[k] = d2; nearest[k] = i;
      }
      // keep voices on bees that are still near; give freed voices to the new ones
      const taken = new Set();
      for (const v of near) if (v.bee >= 0 && nearest.includes(v.bee)) taken.add(v.bee); else v.bee = -1;
      for (const v of near) if (v.bee < 0) for (const b of nearest) if (b >= 0 && !taken.has(b)) { v.bee = b; taken.add(b); v.o.frequency.setValueAtTime(baseHz(b), now); break; }
    }
    const tmult = (SPEEDS[speedIdx] / STEPS_PER_FRAME_1X) * direction;    // sim seconds per real second (signed)
    _cr.crossVectors(camera.getWorldDirection(_w), camera.up).normalize();
    for (const v of near) {
      if (v.bee < 0) { v.g.gain.setTargetAtTime(0, now, 0.08); continue; }
      const o = v.bee * STRIDE;
      const x = (pos ? pos[v.bee * 3] : st[o]) - cam.x, y = (pos ? pos[v.bee * 3 + 1] : st[o + 1]) - cam.y, z = (pos ? pos[v.bee * 3 + 2] : st[o + 2]) - cam.z;
      const d = Math.max(0.15, Math.hypot(x, y, z));
      const vr = (st[o + 3] * x + st[o + 4] * y + st[o + 5] * z) / d * st[o + 6] * tmult;   // + = flying away
      const dop = Math.max(0.75, Math.min(1.3, C_SOUND / (C_SOUND + vr)));
      v.o.frequency.setTargetAtTime(baseHz(v.bee) * dop, now, 0.05);
      v.g.gain.setTargetAtTime(Math.min(0.5, 0.11 / d), now, 0.06);           // 1/distance; a bee 1 ft away ~0.11
      v.pan.pan.setTargetAtTime(Math.max(-1, Math.min(1, (x * _cr.x + y * _cr.y + z * _cr.z) / d * 1.3)), now, 0.06);
    }
  }
  return {
    start, update,
    get on() { return on; }, get started() { return !!ctx && ctx.state === 'running'; },
    toggle() { on = !on; start(); },
    setVolume(v) { vol = v; },
  };
})();
addEventListener('pointerdown', () => Sound.start(), true);
addEventListener('keydown', () => Sound.start(), true);

// ---------------------------------------------------------------- server I/O (from A1)
async function api(path, body, type = 'application/json') {
  const r = await fetch(path, { method: 'POST', body, headers: { 'Content-Type': type } });
  return r.json();
}
async function checkServer() {
  if (location.protocol === 'file:') {
    serverOk = false; recording = false;
    note('Viewing from disk: everything works except recording. To record a movie, start CT54.A1.CombinedSwarms_start.bat (Windows) or _start.sh.');
    return;
  }
  try {
    const r = await fetch('/api/status'); const j = await r.json();
    serverOk = !!j.ok;
    if (serverOk) await api('/api/new_take', '{}');
    if (serverOk && !j.ffmpeg) note('ffmpeg not found — frames will be saved, but the movie step needs ffmpeg (see README).');
  } catch { serverOk = false; }
  if (!serverOk) { recording = false; note('Frame server not reachable — start CT54.A1.CombinedSwarms_start (.bat / .sh) to record. Viewing works.'); }
}
function captureFrame() {
  const idx = filmFrame++;
  inflight++;
  canvas.toBlob(async (blob) => {
    try { const j = await api(`/api/frame?i=${idx}`, blob, 'image/png'); if (!j.ok) uploadErrors++; }
    catch { uploadErrors++; }
    inflight--;
  }, 'image/png');
}
const waitUploads = () => new Promise(res => { const t = () => inflight === 0 ? res() : setTimeout(t, 30); t(); });

// ---------------------------------------------------------------- UI
const $ = (id) => document.getElementById(id);
const hud = $('hud');
function note(t) { $('note').textContent = t; }
function setDir(d) {
  if (d !== -1 && displayStep !== sim.step) sim.seek(displayStep);   // leave rewind: exact state again
  if (d !== -1 && /^(Running backwards|Rewinding)/.test($('note').textContent)) note(d === 1 ? 'Running forwards' : 'Paused');
  direction = d; refreshButtons(); poke();
}
function refreshButtons() {
  poke();
  $('btnFwd').classList.toggle('on', direction === 1);
  $('btnBack').classList.toggle('on', direction === -1);
  $('btnPause').classList.toggle('on', direction === 0);
  $('btnRec').classList.toggle('on', recording);
  $('btnRec').textContent = recording ? '● Recording' : '○ Not recording';
  $('btnZoom').classList.toggle('on', autoZoom);
  $('btnCam').textContent = camMode === 'auto' ? 'Camera: auto' : 'Camera: orbit';
  $('btnAim').textContent = 'Aim: ' + aimMode;
  $('btnCam').classList.toggle('on', camMode === 'orbit');
  $('btnSpin').classList.toggle('on', orbitSpin);
  $('btnSound').textContent = Sound.on ? (Sound.started ? '🔊 Sound' : '🔊 Sound (click page)') : '🔇 Sound off';
  $('btnSound').classList.toggle('on', Sound.on);
  $('btnExag').classList.toggle('on', exaggerate);
  $('btnCaste').classList.toggle('on', casteColours);
  $('btnPip').classList.toggle('on', showPip);
  $('btnLook').textContent = 'Look: ' + (shaded ? 'shaded' : 'wire'); $('btnLook').classList.toggle('on', shaded);
  $('btnShadow').classList.toggle('on', shadowsOn); $('btnShadow').style.opacity = shaded ? '' : '.55';
  $('btnOutline').classList.toggle('on', outlineOn); $('btnOutline').style.opacity = shaded ? '' : '.55';
  $('btnReflect').classList.toggle('on', reflectOn); $('btnReflect').style.opacity = shaded ? '' : '.55';
  $('btnCrystal').classList.toggle('on', crystalOn); $('btnCrystal').style.opacity = shaded ? '' : '.55';
  $('btnStrand').textContent = 'Chains: ' + ({ off: 'hidden', chains: 'shown', contrast: 'contrast' })[strandMode];
  $('btnStrand').classList.toggle('on', strandMode !== 'off');
  $('btnScent').classList.toggle('on', showScent);
  $('btnLoad').classList.toggle('on', showLoad);
  $('btnLinks').classList.toggle('on', showLinks);
  if (HOVER) { const toB = (sim.moves.length & 1) === 0; $('btnMove').textContent = toB ? 'Move queen ▶' : '◀ Move queen back';
    $('btnFollow').textContent = 'Follow: ' + (P.follow === 'scent' ? 'scent' : 'sight'); }
}
$('btnReset').onclick = () => { sim.clearMoves(); sim.reset(); displayStep = 0; rewind.block = -1; poke(); };
// CT52.A2 (option 5): MOVE QUEEN - she flies slowly to the other station (A -> B beside the pole, or back). Only once
// she holds a station. If the view is rewound, the move is made from the moment shown and the old future is forgotten.
$('btnMove').onclick = () => {
  if (!HOVER) return;
  if (displayStep !== sim.step) sim.seek(displayStep);
  if (sim.requestMove()) { rewind.block = -1; note(`The queen is moving ${(sim.moves.length & 1) ? 'to the pole' : 'back'} (${P.moveSpeed} ft/s)`); }
  else note('The queen has not taken up her place yet — try again once she hovers (after ~30 s)');
  refreshButtons(); poke();
};
$('btnFollow').onclick = () => { if (HOVER) reloadWith('follow', P.follow === 'scent' ? 'sight' : 'scent'); };
$('btnFwd').onclick = () => setDir(1);
$('btnBack').onclick = () => setDir(-1);
$('btnPause').onclick = () => setDir(0);
$('btnFaster').onclick = () => { speedIdx = Math.min(SPEEDS.length - 1, speedIdx + 1); };
$('btnSlower').onclick = () => { speedIdx = Math.max(0, speedIdx - 1); };
$('btnZoom').onclick = () => { autoZoom = !autoZoom; refreshButtons(); };
$('btnExag').onclick = () => { exaggerate = !exaggerate; refreshButtons(); };
$('btnCaste').onclick = () => { casteColours = !casteColours; applyColours(); refreshButtons(); };
$('btnScent').onclick = () => { showScent = !showScent; refreshButtons(); };
$('btnLoad').onclick = () => { showLoad = !showLoad; refreshButtons(); };
$('btnLinks').onclick = () => { showLinks = !showLinks; refreshButtons(); };
$('btnPip').onclick = () => { showPip = !showPip; refreshButtons(); };
$('btnLook').onclick = () => { shaded = !shaded; applyLook(); refreshButtons(); };
$('btnShadow').onclick = () => { shadowsOn = !shadowsOn; applyLook(); refreshButtons(); };
$('btnOutline').onclick = () => { outlineOn = !outlineOn; applyLook(); refreshButtons(); };
$('btnReflect').onclick = () => { reflectOn = !reflectOn; applyReflections(); refreshButtons(); };
$('btnCrystal').onclick = () => { crystalOn = !crystalOn; applyLook(); refreshButtons(); };
// A12: bee count - reloads the page with ?bees=N (skipping the opening; other settings kept)
{ const sel = $('beeSel');
  for (const n of [500, 1000, 2000, 4000, 5000, 7500, 10000, 12000, 15000, 20000]) { const o = document.createElement('option'); o.value = n; o.textContent = n.toLocaleString('en-US'); sel.appendChild(o); }
  if (![...sel.options].some(o => +o.value === BEES)) { const o = document.createElement('option'); o.value = BEES; o.textContent = BEES.toLocaleString('en-US'); sel.appendChild(o); }
  sel.value = BEES;
  sel.addEventListener('change', () => { const q = new URLSearchParams(location.search); q.set('bees', sel.value); q.set('intro', '0');
    q.set('look', shaded ? 'shaded' : 'wire'); q.set('shadows', shadowsOn ? '1' : '0'); q.set('outline', outlineOn ? '1' : '0'); q.set('reflect', reflectOn ? '1' : '0'); q.set('crystal', crystalOn ? '1' : '0');
    location.search = q.toString(); }); }
// C7: Weather and what the cluster hangs from - each reloads the page (skipping the opening; other settings kept)
function reloadWith(key, val) {
  const q = new URLSearchParams(location.search); q.set(key, val); q.set('intro', '0');
  q.set('look', shaded ? 'shaded' : 'wire'); q.set('shadows', shadowsOn ? '1' : '0'); q.set('outline', outlineOn ? '1' : '0'); q.set('reflect', reflectOn ? '1' : '0'); q.set('crystal', crystalOn ? '1' : '0');
  location.search = q.toString();
}
// CT54: switching option reloads the page (each option builds its own swarm). The bee count goes back to that
// option's default unless ?bees was set by hand; the old ?weather is dropped.
function chooseOption(n) {
  n = optionOf(n);
  const q = new URLSearchParams(location.search); q.set('option', n); q.delete('weather'); q.delete('follow'); q.set('intro', '0');
  q.set('look', shaded ? 'shaded' : 'wire'); q.set('shadows', shadowsOn ? '1' : '0'); q.set('outline', outlineOn ? '1' : '0'); q.set('reflect', reflectOn ? '1' : '0'); q.set('crystal', crystalOn ? '1' : '0');
  if (OPTIONS[n].hover !== HOVER) q.delete('bees');   // (5,000 for the ball, 7,500 for 1-4)
  location.search = q.toString();
}
{ const os = $('optionSel'), ss = $('supportSel'), SU = window.CT54Sim.SUPPORTS;
  for (const k of Object.keys(OPTIONS)) { const o = document.createElement('option'); o.value = k; o.textContent = OPTIONS[k].label; os.appendChild(o); }
  for (const k of Object.keys(SU)) { const o = document.createElement('option'); o.value = k; o.textContent = SU[k]; ss.appendChild(o); }
  if (HOVER) { const o = document.createElement('option'); o.value = 'none'; o.textContent = 'nothing — the queen hovers'; ss.appendChild(o); }
  os.value = OPTION; ss.value = HOVER ? 'none' : P.support; ss.disabled = HOVER;
  if (HOVER) $('camHelp').innerHTML = $('camHelp').innerHTML.replace('queen &middot; centre &middot; tip', 'queen &middot; ball centre').replace('queen · centre · tip', 'queen · ball centre');
  if (HOVER) ss.parentElement.title = 'Option 5 hangs from nothing: the queen hovers in the open';
  os.addEventListener('change', () => chooseOption(os.value));
  ss.addEventListener('change', () => reloadWith('support', ss.value)); }
// CT54: what does not apply to the option in use is hidden
for (const id of (HOVER ? ['btnStrand', 'btnLinks', 'btnLoad'] : ['btnMove', 'btnFollow'])) $(id).style.display = 'none';
$('btnStrand').onclick = () => { strandMode = strandMode === 'off' ? 'chains' : strandMode === 'chains' ? 'contrast' : 'off'; refreshButtons(); };   // C7: off -> chains -> contrast
$('btnRec').onclick = () => { if (serverOk) { recording = !recording; refreshButtons(); } };
$('btnFinish').onclick = finish;
$('btnCam').onclick = () => setCamMode(camMode === 'auto' ? 'orbit' : 'auto');
$('btnAim').onclick = () => { aimMode = AIMS[(AIMS.indexOf(aimMode) + 1) % AIMS.length]; panOff.set(0, 0, 0); refreshButtons(); poke(); };
// C5: the camera help sits in the lower-left corner of the picture itself (the canvas is letterboxed in the window)
function placeHelp() {
  const el = $('camHelp'), cw = canvas.clientWidth, ch = canvas.clientHeight, k = Math.min(cw / W, ch / H);
  el.style.left = Math.round((cw - W * k) / 2 + 12) + 'px'; el.style.bottom = Math.round((ch - H * k) / 2 + 12) + 'px';
}
addEventListener('resize', placeHelp); placeHelp();
$('btnSpin').onclick = () => { orbitSpin = !orbitSpin; if (orbitSpin) setCamMode('orbit'); refreshButtons(); };
$('btnSound').onclick = () => { Sound.toggle(); refreshButtons(); poke(); };
$('vol').addEventListener('input', () => Sound.setVolume($('vol').value / 100));
addEventListener('pointerdown', () => setTimeout(refreshButtons, 50));
addEventListener('keydown', (e) => {
  if (finished || introActive) return;
  if (e.target && e.target.tagName === 'INPUT') return;
  const k = e.key;
  if (k >= '1' && k <= '5') { if (+k !== OPTION) chooseOption(+k); }                   // CT54: pick an option
  else if (k === 'r' || k === 'R') $('btnReset').click();
  else if (k === 'f' || k === 'ArrowRight') setDir(1);
  else if (k === 'b' || k === 'ArrowLeft') setDir(-1);
  else if (k === ' ') { e.preventDefault(); setDir(direction === 0 ? 1 : 0); }
  else if (k === '+' || k === '=' || k === 'ArrowUp') $('btnFaster').click();
  else if (k === '-' || k === 'ArrowDown') $('btnSlower').click();
  else if (k === 'z' || k === 'Z') $('btnZoom').click();
  else if (k === 'a' || k === 'A') $('btnCam').click();
  else if (k === 'o' || k === 'O') $('btnSpin').click();
  else if (k === 't' || k === 'T') $('btnAim').click();
  else if (k === '[') setDist((camMode === 'orbit' ? orbitDist : aim.distanceTo(CAM_POS)) / 1.15);
  else if (k === ']') setDist((camMode === 'orbit' ? orbitDist : aim.distanceTo(CAM_POS)) * 1.15);
  else if (k === 'm' || k === 'M') $('btnSound').click();
  else if (k === 'e' || k === 'E') $('btnExag').click();
  else if (k === 'c' || k === 'C') $('btnCaste').click();
  else if (k === 'p' || k === 'P') $('btnPip').click();
  else if (k === 'w' || k === 'W') $('btnLook').click();
  else if (k === 'q' || k === 'Q') $('btnShadow').click();
  else if (k === 'u' || k === 'U') $('btnOutline').click();
  else if (k === 'x' || k === 'X') $('btnReflect').click();
  else if (k === 'v' || k === 'V') $('btnCrystal').click();
  else if (k === 'n' || k === 'N') $('btnStrand').click();
  else if (k === 's' || k === 'S') $('btnScent').click();
  else if (k === 'k' || k === 'K') $('btnLoad').click();
  else if (k === 'g' || k === 'G') $(HOVER ? 'btnMove' : 'btnLinks').click();   // option 5: move the queen (CT52.A2)
  else if (HOVER && (k === 'l' || k === 'L')) $('btnFollow').click();
  else if (k === 'h' || k === 'H') { showHud = !showHud; $('hudPlate').style.display = showHud ? '' : 'none'; $('camHelp').style.display = showHud ? '' : 'none'; }
});

// census c = [milling, attracted (following the scent), settled, settled bees fanning]
// C7: the conditions, for the HUD
const SUPPORT_WORD = P.support === 'branch' ? 'stem' : 'beam';
const SHAPE_WORD = !P.shell ? 'no shell (C6 hanging)' : P.envAspect > 1.3 ? 'a long beard' : P.envAspect >= 0.85 ? 'compact' : 'short and broad';
const CONDS = `${window.CT54Sim.CONDITIONS[P.weather].label}, ${P.support === 'branch' ? 'thin stem' : 'flat beam'} → ${SHAPE_WORD}`;
// CT52 (option 5): census c = [milling, attracted, in the ball (the queen included), scenting in the ball]
function phaseTextHover(c, t) {
  const n = BEES, inBall = c[2] / n;
  if (t < P.queenSettle) return `Phase 1 · milling cloud — the queen flies among them; ${c[1]} bees near her already follow her scent`;
  if (c[2] === 0) return `Phase 2 · the queen is flying to her place in the open; ${c[1]} bees follow her scent`;
  if (inBall < 0.9) return `Phase 3 · gathering — the queen hovers; ${(inBall * 100).toFixed(0)} % in the ball around her, ${c[3]} scenting, ${c[1]} on the way, ${c[0]} still milling`;
  { const ST = sim.stationNow(), q = sim.state, d = Math.hypot(q[0] - ST[0], q[1] - ST[1], q[2] - ST[2]);
    if (sim.moves.some(m => m <= displayStep) && d > 0.6) return `Phase 5 · the queen is moving — ${d.toFixed(1)} ft to go; ${(inBall * 100).toFixed(0)} % still count as in the ball, ${c[1]} following, ${c[0]} milling`; }
  return `Phase 4 · the close-in ball — ${(inBall * 100).toFixed(1)} % fly around the hovering queen, ${c[3]} scenting, ${c[0] + c[1]} outside`;
}
function phaseText(c, t) {
  if (HOVER) return phaseTextHover(c, t);
  const n = BEES, settled = c[2] / n;
  if (c[2] === 0) return t < P.queenSettle
    ? `Phase 1 · milling cloud — only the queen's scent so far; ${c[1]} bees near her already follow it`
    : `Phase 2 · the queen is making for the arbor; ${c[1]} bees follow her scent`;
  if (settled < 0.9) return `Phase 3 · condensing — ${(settled * 100).toFixed(0)} % settled, ${c[3]} fanning scent, ${c[1]} following it, ${c[0]} still milling`;
  return `Phase 4 · clustered${P.shell ? ' — chains inside a dense shell' : ', hanging in chains'} — ${(settled * 100).toFixed(1)} % settled, ${c[3]} fanning, ${c[0] + c[1]} bees still flying`;
}
// A9: mechanical odometer drums (brass wheels that roll to each new digit)
function makeOdo(el, digits, decimals) {
  const wheels = [];
  for (let k = 0; k < digits + decimals; k++) {
    if (k === digits && decimals) { const d = document.createElement('span'); d.className = 'wheel dot'; d.textContent = '.'; el.appendChild(d); }
    const w = document.createElement('span'); w.className = 'wheel';
    const strip = document.createElement('div'); strip.className = 'strip';
    for (let n = 0; n <= 9; n++) { const c = document.createElement('div'); c.textContent = n; strip.appendChild(c); }
    w.appendChild(strip); el.appendChild(w); wheels.push(strip);
  }
  let last = '';
  return (v) => {
    const str = Math.max(0, Math.min(Math.pow(10, digits) - 1e-9, v)).toFixed(decimals).replace('.', '').padStart(digits + decimals, '0');
    if (str === last) return; last = str;
    for (let k = 0; k < wheels.length; k++) wheels[k].style.transform = `translateY(${-1.25 * +str[k]}em)`;
  };
}
const odoR = makeOdo($('odoR'), 2, 0), odoT = makeOdo($('odoT'), 3, 1), odoS = makeOdo($('odoS'), 5, 0), odoF = makeOdo($('odoF'), 5, 0), odoN = makeOdo($('odoN'), HOVER ? 4 : 3, 0);
if (HOVER) { $('odoS').previousElementSibling.textContent = 'In ball'; $('odoF').previousElementSibling.textContent = 'Milling'; $('odoN').previousElementSibling.textContent = 'Scenting'; }
function updateHud(cen) {
  odoT(displayStep * DT); odoR(perf.fps); odoS(cen[2]); odoF(cen[0] + cen[1]); odoN(HOVER ? cen[3] : strandMode === 'off' ? 0 : strand.strands);
  const mult = SPEEDS[speedIdx] / STEPS_PER_FRAME_1X;
  const dirTxt = direction > 0 ? 'FORWARD' : direction < 0 ? 'BACKWARD' : 'PAUSED';
  const t = displayStep * DT;
  const focal = 12 / Math.tan(fov * Math.PI / 360);                  // 35 mm-equivalent (24 mm frame height)
  // B2: half the lines of B1 - six short lines; the odometers above carry time / settled / aloft / strands / fps
  const L = CL.n && CL.load ? CL.load : null;
  hud.textContent =
    `${LABEL} · seed ${SEED} · ${BEES} bees · t ${t.toFixed(1)} s ${dirTxt} ×${mult} · dawn ${(dawn * 100).toFixed(0)} % · ${perf.fps.toFixed(0)} fps, ${perf.ms.toFixed(0)} ms\n` +
    `OPTION ${OPTION} of 5 · ${OPT.name}${OPT.documented ? ' (documented)' : ' — observed in the wild, NOT documented in the literature'}\n` +
    `${phaseText(cen, t)}\n` +
    (HOVER ? (SB.n >= 30 ? `ball ≈ ${(2 * SB.c90 * 12).toFixed(1)} in across (90 % of its bees within ${(SB.c90 * 12).toFixed(1)} in of its centre) · its centre ${(Math.hypot(SB.cx - sim.state[0], SB.cy - sim.state[1], SB.cz - sim.state[2]) * 12).toFixed(0)} in from the queen · queen ${sim.state[1].toFixed(1)} ft up · follow by ${P.follow === 'scent' ? 'scent' : 'sight'}`
      : `no ball yet · the queen ${sim.state[16] === 3 ? 'hovers' : 'flies'} ${sim.state[1].toFixed(1)} ft up · cloud ≈ ${cloudWidth.toFixed(0)} ft`) + '\n' :
    (CL.n ? `${CONDS} · cluster ${(CL.length * 12).toFixed(1)} × ${(CL.width * 12).toFixed(1)} in under the ${SUPPORT_WORD}` +
      (L ? ` · ${L.onBranch} grip the ${SUPPORT_WORD}, ${L.meanHeldTop.toFixed(1)} bee-wts each · longest chain ${L.maxDepth}` : '')
      : `no cluster yet · the arbor's beam ${ATTACH_Y.toFixed(1)} ft up, ${(-P.siteZ).toFixed(0)} ft away · cloud ≈ ${cloudWidth.toFixed(0)} ft`) + '\n') +
    `${camMode === 'auto' ? 'camera auto' : `orbit ${((orbitAz * 180 / Math.PI) % 360 + 360).toFixed(0) % 360}°/${(orbitEl * 180 / Math.PI).toFixed(0)}°`} ${aim.distanceTo(camera.position).toFixed(1)} ft from ${AIM_NAME[aimMode]}${panOff.lengthSq() > 1e-4 ? ' (panned)' : ''} · ${fov.toFixed(0)}° lens${exag > 1.01 ? ' · bees ×' + exag.toFixed(1) : ''}${showPip ? ` · close-up ${pipDist.toFixed(1)} ft` : ''}\n` +
    `${shaded ? 'shaded' + (shadowsOn ? '·shadows' : '') + (reflectOn ? '·reflect' : '') + (outlineOn ? '·outline' : '') + (crystalOn ? '·crystal' : '') : 'wireframe'}${strandMode !== 'off' ? ' · strands ' + strandMode : ''}${showLoad ? ' · load' : ''}${showScent ? ' · scent' : ''} · hash ${displayStep === sim.step ? sim.hash() : '(on resume)'}\n` +
    (serverOk ? `frames saved ${filmFrame - inflight}/${filmFrame} (${(filmFrame / FPS).toFixed(1)} s of film)` + (uploadErrors ? `  upload errors ${uploadErrors}` : '') : 'recording off (no frame server)');
}

// ---------------------------------------------------------------- main loop
let lastTick = 0, firstFrame = true, settle = 0;   // settle: frames to keep rendering while paused (camera easing)
function poke() { settle = 90; }
// scent field (S): a vertical slice of the air grid through the branch, one grey dot per 1-ft cell,
// brightness ~ (concentration / slice maximum)^(1/4); cells under 1 % of the maximum are not drawn
const SLICE_Z = HOVER ? Math.floor((P.gridZ * P.cell / 2 + P.stationDZ) / P.cell) : P.gridZ >> 1;   // CT52: option 5 slices through the queen's station
const scentPts = (() => {
  const X = P.gridX, Y = P.gridY, pos = new Float32Array(X * Y * 3), col = new Float32Array(X * Y * 3);
  for (let ix = 0; ix < X; ix++) for (let iy = 0; iy < Y; iy++) {
    const k = (ix * Y + iy) * 3;
    pos[k] = P.siteX - X * P.cell / 2 + (ix + 0.5) * P.cell; pos[k + 1] = (iy + 0.5) * P.cell; pos[k + 2] = HOVER ? P.siteZ - P.gridZ * P.cell / 2 + (SLICE_Z + 0.5) * P.cell : P.siteZ;
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  g.setAttribute('color', new THREE.BufferAttribute(col, 3));
  const pts = new THREE.Points(g, new THREE.PointsMaterial({ size: 4, sizeAttenuation: false, vertexColors: true, fog: false }));
  pts.visible = false; pts.frustumCulled = false;
  scene.add(pts);
  return pts;
})();
function updateScent() {
  scentPts.visible = showScent;
  if (!showScent) return;
  const X = P.gridX, Y = P.gridY, Z = P.gridZ, iz = SLICE_Z, f = sim.field, col = scentPts.geometry.attributes.color.array;
  let mx = 1e-9;
  for (let ix = 0; ix < X; ix++) for (let iy = 0; iy < Y; iy++) { const c = f[(ix * Y + iy) * Z + iz]; if (c > mx) mx = c; }
  for (let ix = 0; ix < X; ix++) for (let iy = 0; iy < Y; iy++) {
    const r = f[(ix * Y + iy) * Z + iz] / mx;                       // relative to the strongest point on the slice
    const v = r > 0.01 ? Math.sqrt(Math.sqrt(r)) : 0;              // 4th root: shows the faint edge of the plume too
    const k = (ix * Y + iy) * 3; col[k] = col[k + 1] = col[k + 2] = v;
  }
  scentPts.geometry.attributes.color.needsUpdate = true;
}

// A12: frame-rate meter - pictures actually drawn per second (the loop is capped at 30 = the film rate) and how long
// the last frames took to prepare and draw (ms, averaged)
const perf = { n: 0, t0: performance.now(), fps: 0, ms: 0 };
function renderNow() {
  const tStart = performance.now();
  updateDawn(displayStep * DT);
  if (HOVER) { const b = sim.ballShape(), d = SB.n >= 30 ? 2 * SB.c90 : b.diameter;   // CT52: the ball stands in for the cluster
    CL = { n: b.n, length: d, width: d, cx: b.cx, cy: b.cy, cz: b.cz, load: null }; }
  else CL = sim.clusterShape();
  updateScent();
  const pos = viewPositions();
  settledBox(pos);
  frameCamera(pos, firstFrame);
  if (camMode === 'auto' && !drag) syncDistSlider();
  Sound.update(pos);
  computeStrands(pos);
  orientBees(pos);
  framePip(pos, firstFrame || !showPip);
  applyColours(pos);
  updateLinks(pos);
  updateChainLines(pos);
  renderViews();
  firstFrame = false;
  { const now = performance.now(); perf.ms = perf.ms * 0.9 + (now - tStart) * 0.1; perf.n++;
    if (now - perf.t0 >= 1000) { perf.fps = perf.n * 1000 / (now - perf.t0); perf.n = 0; perf.t0 = now; } }
  const cen = pos ? rewind.census[Math.round((displayStep - rewind.block) / GRAN)] : sim.census();
  updateHud(cen);
}
function tick(now) {
  if (finished) return;
  requestAnimationFrame(tick);
  if (now - lastTick < 1000 / FPS - 2) return;           // at most FPS film frames per real second
  if (recording && inflight >= MAX_INFLIGHT) return;     // don't outrun the disk
  lastTick = now;
  if (direction === 0) { if (settle <= 0) return; settle--; }   // paused: idle once the camera has settled
  if (direction > 0) { sim.seek(sim.step + SPEEDS[speedIdx]); displayStep = sim.step; }
  else if (direction < 0) {
    displayStep = Math.max(0, displayStep - SPEEDS[speedIdx]);
    if (displayStep === 0) { sim.seek(0); setDir(0); }
  }
  renderNow();
  if (recording && direction !== 0) captureFrame();
  if (direction < 0 && $('note').textContent.startsWith('Rewinding')) note('Running backwards');
}

async function finish() {
  if (finished) return;
  finished = true;
  Sound.update(null);
  document.body.classList.add('finishing');
  note('Terminating simulation, flushing frames…');
  await waitUploads();
  if (!serverOk || filmFrame === 0) {
    note(serverOk ? 'No frames were recorded, so there is no movie.' : 'Server offline — no movie could be made.');
    finished = false; document.body.classList.remove('finishing'); requestAnimationFrame(tick);
    return;
  }
  note(`Encoding ${filmFrame} frames into a movie…`);
  let j;
  try {
    const r = await fetch('/api/finish', { method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ fps: FPS, seed: SEED, bees: BEES, width: W, height: H, final_step: sim.step }) });
    j = await r.json();
  } catch (e) { j = { ok: false, error: String(e) }; }
  if (!j.ok) { note('Movie failed: ' + j.error); finished = false; document.body.classList.remove('finishing'); requestAnimationFrame(tick); return; }
  note(`Movie saved: ${j.movie}  (${j.frames} frames; ${j.deleted} frame files deleted)`);
  const v = $('movie');
  v.src = j.movie; $('player').hidden = false; $('movieName').textContent = j.movie;
  v.play().catch(() => {});
}
$('btnNewTake').onclick = () => location.reload();

// ---------------------------------------------------------------- start
window.CT54 = { get beesHidden() { return beesHidden; }, setAim(m) { aimMode = m; refreshButtons(); }, pan(x, y, z) { panOff.set(x, y, z); }, sim, setDir, finish, renderNow, skyObjects: () => SKY_OBJ, look(px, py, pz, tx, ty, tz, fovDeg = 40) { camera.position.set(px, py, pz); camera.lookAt(tx, ty, tz); camera.fov = fovDeg; camera.updateProjectionMatrix(); renderer.setScissorTest(false); renderer.setViewport(0, 0, W, H); renderer.clear(); renderer.shadowMap.needsUpdate = true; renderer.render(scene, camera); }, setOrbit(az, el, d) { setCamMode('orbit'); orbitAz = az; orbitEl = el; orbitDist = d; }, snap() { firstFrame = true; renderNow(); }, idle() { settle = 0; }, scentPts: () => scentPts,                                // handle for automated testing
  get displayStep() { return displayStep; }, set displayStep(v) { displayStep = v; },
  get filmFrame() { return filmFrame; }, get inflight() { return inflight; }, get finished() { return finished; },
  get fov() { return fov; }, get exag() { return exag; }, get cloudWidth() { return cloudWidth; },
  toggle: (id) => $(id).click() };
// (C6: four captions over the empty scene; A10-C5: a Zoltar-style card.) ?intro=0 skips the opening;
// ?title=<s> sets how long the title holds.
// C7: the opening is the title art alone (the C6 captions are gone). Under it, one line points to the file that
// explains what is being shown (CT54: CT54.A1.CombinedSwarms_AUDIT.html / .md). Then the dawn scene fades up with the bees, and
// the sound rises as the sim starts. The first click wakes the sound; a second click, or Space / Enter / Esc,
// begins at once.
// C8: after the title, a 'how to use' card (what to look at, what the results should be) waits over the dawn scene
// until Start / Space / Enter. The ? Help button (or the ? key) brings it back at any time.
function openHelp(open) { $('card').classList.toggle('open', open); }
// CT54: the five options on the card - one big key each, the running one outlined; the banner over the picture
{ const list = $('optList');
  for (const k of Object.keys(OPTIONS)) {
    const o = OPTIONS[k], b = document.createElement('button');
    b.className = 'opt' + (+k === OPTION ? ' cur' : '') + (o.hover ? ' five' : '');
    b.innerHTML = `<span class="n">${k}</span><span class="t">${o.name}${+k === OPTION ? ' · selected' : ''}</span>` +
      `<span class="tag ${o.documented ? 'doc' : 'obs'}">${o.documented ? 'documented' : 'observed · not in the literature'}</span>` +
      `<span class="d">${{ 1: 'Mild, calm air. The swarm hangs from a thin vine stem under the arbor as a long, pointed beard.',
        2: 'Cool air. The bees pack tight: a compact, rounder cluster under the stem.',
        3: 'Hot air. The cluster loosens: short, broad and about twice the volume.',
        4: 'Wind. The cluster hangs short and broad and sways in the gusts.',
        5: 'Still air. The queen hovers in the open, attached to nothing, and the bees keep flying in a dense ball around her.' }[k]}</span>`;
    b.title = +k === OPTION ? 'Start this option' : `Switch to option ${k} (the page reloads and starts it)`;
    b.onclick = () => { if (+k === OPTION) $('btnStart').click(); else chooseOption(+k); };
    list.appendChild(b);
  }
  const ban = $('optBanner');
  ban.innerHTML = `<span class="num">${OPTION}</span><span>OPTION ${OPTION} OF 5 · ${OPT.name.toUpperCase()}</span>` +
    `<span class="tag ${OPT.documented ? 'doc' : 'obs'}">${OPT.documented ? 'documented' : 'observed in the wild — NOT documented in the literature'}</span>`;
  ban.classList.toggle('obs', !OPT.documented);
  ban.onclick = () => openHelp(true);
  document.title = `${LABEL} · option ${OPTION}: ${OPT.name}`;
}
$('btnHelp').onclick = () => openHelp(!$('card').classList.contains('open'));
$('btnStart').onclick = () => openHelp(false);
addEventListener('keydown', (e) => { if (e.key === '?' || e.key === '/') { e.preventDefault(); $('btnHelp').click(); } });
function runIntro() {
  const t = $('title'), bg = $('introBg'), cap = $('caption'), txt = $('capText');
  return new Promise((done) => {
    if (qs.get('intro') === '0') { t.remove(); cap.remove(); bg.remove(); done(); return; }
    introActive = true; beesHidden = true; document.body.classList.add('intro'); renderNow();
    const TITLE_S = parseFloat(qs.get('title') ?? '15');
    let timer, clicks = 0, stage = 0;            // 0 title, 1 the help card, 2 running
    const showCard = () => {
      if (stage !== 0) return; stage = 1; clearTimeout(timer);
      t.classList.remove('shown'); t.classList.add('out'); bg.classList.add('gone'); txt.classList.remove('on'); cap.classList.remove('live');
      openHelp(true);
    };
    const finish = () => {
      if (stage === 2) return; stage = 2; clearTimeout(timer);
      removeEventListener('keydown', onKey, true); removeEventListener('click', onClick, true);
      openHelp(false); bg.classList.add('gone'); t.classList.add('out');
      introActive = false; beesHidden = false; document.body.classList.remove('intro');
      done(); setTimeout(() => { bg.remove(); t.remove(); cap.remove(); }, 3500);
    };
    const onKey = (e) => { if (e.key === ' ' || e.key === 'Enter' || e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); stage === 0 ? showCard() : finish(); } };
    const onClick = (e) => {
      if (e.target && e.target.closest && e.target.closest('#btnStart')) { e.stopPropagation(); finish(); return; }
      if (e.target && e.target.closest && e.target.closest('a, #card')) return;
      if (stage === 0 && ++clicks > 1) showCard();
    };
    addEventListener('keydown', onKey, true); addEventListener('click', onClick, true);
    const go = () => { t.classList.add('shown'); cap.classList.add('live'); setTimeout(() => txt.classList.add('on'), 1500); timer = setTimeout(showCard, TITLE_S * 1000); };
    if (t.complete) go(); else { t.onload = go; t.onerror = () => { t.remove(); go(); }; }
  });
}
direction = 0;
syncDistSlider();
refreshButtons();
await checkServer();
refreshButtons();
renderNow();
requestAnimationFrame(tick);
await runIntro();
setDir(1);
})();
